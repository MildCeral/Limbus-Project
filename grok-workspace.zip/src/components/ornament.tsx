import { useState } from "react";
import { sinMeta } from "@/lib/ledger/constants";
import type { SinId } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

export function WaxSeal({
  letter = "L",
  className,
  pulse,
}: {
  letter?: string;
  className?: string;
  pulse?: boolean;
}) {
  return (
    <div
      className={cn(
        "relative grid size-14 place-items-center rounded-full bg-seal text-ink shadow-seal",
        pulse && "animate-[pulse-seal_2.4s_ease-in-out_infinite]",
        className,
      )}
      aria-hidden
    >
      <div className="absolute inset-1 rounded-full border border-gold/30" />
      <div className="absolute inset-2.5 rounded-full border border-gold/20" />
      <span className="font-display text-lg tracking-display">{letter}</span>
    </div>
  );
}

export function Portrait({
  src,
  name,
  sin,
  className,
}: {
  src?: string;
  name: string;
  sin: SinId;
  className?: string;
}) {
  const [ok, setOk] = useState(Boolean(src));
  const meta = sinMeta(sin);
  const initial = name.trim().charAt(0).toUpperCase() || "—";
  return (
    <div
      className={cn(
        "relative overflow-hidden border border-edge bg-void",
        className,
      )}
    >
      {ok && src ? (
        <img
          src={src}
          alt=""
          className="size-full object-cover object-top"
          onError={() => setOk(false)}
        />
      ) : (
        <div
          className="grid size-full place-items-center font-display text-3xl"
          style={{ color: meta.hue, background: "var(--color-raised)" }}
        >
          {initial}
        </div>
      )}
      <span
        className="absolute right-1 bottom-1 size-2.5 rounded-full border border-void"
        style={{ background: meta.hue }}
        title={meta.name}
      />
    </div>
  );
}

export function SectionKicker({ children }: { children: string }) {
  return (
    <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
      {children}
    </p>
  );
}

export function FileRule({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="rule flex-1" />
      {label ? (
        <span className="font-display text-2xs uppercase tracking-stamp text-faint">
          {label}
        </span>
      ) : null}
      <div className="rule flex-1" />
    </div>
  );
}

export function VitalBar({
  current,
  max,
  kind = "hp",
}: {
  current: number;
  max: number;
  kind?: "hp" | "sp";
}) {
  const pct = max <= 0 ? 0 : Math.max(0, Math.min(100, (current / max) * 100));
  return (
    <div className={cn("hp-track", kind === "sp" && "sp-track")}>
      <span style={{ width: `${pct}%` }} />
    </div>
  );
}
