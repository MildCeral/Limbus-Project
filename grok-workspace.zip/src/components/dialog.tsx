import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;

export function DialogContent({
  className,
  title,
  children,
  wide,
}: {
  className?: string;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <DialogPrimitive.Portal>
      <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-void/80" />
      <DialogPrimitive.Content
        className={cn(
          "fixed top-1/2 left-1/2 z-50 max-h-[min(90dvh,720px)] w-[min(calc(100%-1.5rem),32rem)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto border border-edge bg-surface p-5 shadow-paper",
          wide && "w-[min(calc(100%-1.5rem),40rem)]",
          className,
        )}
      >
        <DialogPrimitive.Description className="sr-only">
          Formulário interno da Companhia.
        </DialogPrimitive.Description>
        <div className="mb-4 flex items-start justify-between gap-3">
          <DialogPrimitive.Title className="font-display text-lg tracking-display text-gold">
            {title}
          </DialogPrimitive.Title>
          <DialogPrimitive.Close
            className="flex size-11 items-center justify-center text-muted transition-colors hover:text-ink"
            aria-label="Fechar"
          >
            <X className="size-4" />
          </DialogPrimitive.Close>
        </div>
        {children}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}
