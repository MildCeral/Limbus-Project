import { useRef } from "react";
import { Portrait } from "@/components/ornament";
import { sinMeta } from "@/lib/ledger/constants";
import { ENEMY_PORTRAITS } from "@/lib/ledger/seed";
import { currentActor, useLedgerStore } from "@/lib/ledger/store";
import type { Token } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

const CELL = 44;

export function MapBoard() {
  const combat = useLedgerStore((s) => s.combat);
  const characters = useLedgerStore((s) => s.characters);
  const selectToken = useLedgerStore((s) => s.selectToken);
  const moveToken = useLedgerStore((s) => s.moveToken);
  const actor = currentActor(combat);
  const boardRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ id: string; moved: boolean } | null>(null);

  const width =
    combat.grid === "hex"
      ? combat.cols * CELL + CELL / 2
      : combat.cols * CELL;
  const height =
    combat.grid === "hex" ? combat.rows * CELL * 0.86 + CELL * 0.14 : combat.rows * CELL;

  function cellOrigin(x: number, y: number) {
    if (combat.grid === "hex") {
      const ox = y % 2 === 1 ? CELL / 2 : 0;
      return { left: x * CELL + ox, top: y * CELL * 0.86 };
    }
    return { left: x * CELL, top: y * CELL };
  }

  function pointToCell(clientX: number, clientY: number) {
    const rect = boardRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const px = clientX - rect.left;
    const py = clientY - rect.top;
    if (combat.grid === "hex") {
      const y = Math.max(0, Math.min(combat.rows - 1, Math.floor(py / (CELL * 0.86))));
      const ox = y % 2 === 1 ? CELL / 2 : 0;
      const x = Math.max(0, Math.min(combat.cols - 1, Math.floor((px - ox) / CELL)));
      return { x, y };
    }
    return {
      x: Math.max(0, Math.min(combat.cols - 1, Math.floor(px / CELL))),
      y: Math.max(0, Math.min(combat.rows - 1, Math.floor(py / CELL))),
    };
  }

  function portraitFor(t: Token) {
    if (t.characterId) {
      return characters.find((c) => c.id === t.characterId)?.portrait;
    }
    return ENEMY_PORTRAITS[t.id];
  }

  return (
    <div className="overflow-auto border border-edge bg-void">
      <div
        ref={boardRef}
        className="relative touch-none select-none"
        style={{ width, height, minWidth: width, minHeight: height }}
        onPointerUp={(e) => {
          if (!drag.current) return;
          const cell = pointToCell(e.clientX, e.clientY);
          if (cell && drag.current.moved) moveToken(drag.current.id, cell.x, cell.y);
          drag.current = null;
        }}
      >
        {Array.from({ length: combat.rows * combat.cols }, (_, i) => {
          const x = i % combat.cols;
          const y = Math.floor(i / combat.cols);
          const origin = cellOrigin(x, y);
          const occupied = combat.tokens.some((t) => t.x === x && t.y === y);
          return (
            <button
              key={`${x}-${y}`}
              type="button"
              aria-label={`Casa ${String.fromCharCode(65 + x)}${y + 1}`}
              className={cn(
                "absolute border border-gold/12 bg-paper/30 hover:bg-gold/10",
                combat.grid === "hex" && "clip-hex",
                occupied && "bg-transparent",
              )}
              style={{
                left: origin.left,
                top: origin.top,
                width: CELL,
                height: CELL,
              }}
              onClick={() => {
                if (combat.selectedId) {
                  moveToken(combat.selectedId, x, y);
                }
              }}
            />
          );
        })}

        {combat.tokens.map((t) => {
          const origin = cellOrigin(t.x, t.y);
          const src = portraitFor(t);
          const active = actor?.id === t.id;
          const selected = combat.selectedId === t.id;
          const sin = t.sin ? sinMeta(t.sin) : null;
          return (
            <button
              key={t.id}
              type="button"
              className={cn(
                "absolute z-10 flex size-11 items-center justify-center overflow-hidden border-2 bg-raised",
                selected ? "border-gold" : "border-edge",
                active && "ring-2 ring-blood",
                t.kind === "hazard" && "border-dashed",
              )}
              style={{
                left: origin.left + 1,
                top: origin.top + 1,
                boxShadow: sin ? `0 0 0 1px ${sin.hue}` : undefined,
              }}
              onPointerDown={(e) => {
                e.currentTarget.setPointerCapture(e.pointerId);
                drag.current = { id: t.id, moved: false };
                selectToken(t.id);
              }}
              onPointerMove={() => {
                if (drag.current?.id === t.id) drag.current.moved = true;
              }}
            >
              {src ? (
                <Portrait src={src} name={t.name} sin={t.sin ?? "gloom"} className="size-full" />
              ) : (
                <span className="font-display text-2xs text-gold">
                  {t.name.slice(0, 2).toUpperCase()}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
