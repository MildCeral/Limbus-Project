import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { FileRule, WaxSeal } from "@/components/ornament";
import { Button, Field, Input } from "@/components/ui";
import { APP_COMPANY, APP_NAME, APP_SLOGAN } from "@/lib/ledger/constants";
import { useLedgerStore } from "@/lib/ledger/store";
import type { Role } from "@/lib/ledger/types";

export function Gate() {
  const seal = useLedgerStore((s) => s.sealDesignation);
  const [name, setName] = useState("");
  const [role, setRole] = useState<Role>("gerente");

  function submit(e: FormEvent) {
    e.preventDefault();
    const trimmed = name.trim();
    if (trimmed.length < 2) {
      toast.error("A Companhia recusa anônimos. Assine o livro.");
      return;
    }
    seal(trimmed, role);
    toast.success(
      role === "gerente"
        ? "Designação selada. Os pecadores aguardam suas ordens."
        : "Designação selada. Seu dossiê já estava à sua espera.",
    );
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-void px-4 py-10">
      <form onSubmit={submit} className="dossier w-full max-w-md p-6 sm:p-8">
        <div className="flex items-center justify-between">
          <WaxSeal letter="L" pulse />
          <span className="stamp">Acesso interno</span>
        </div>
        <p className="mt-6 font-display text-2xs uppercase tracking-stamp text-gold-dim">
          {APP_COMPANY}
        </p>
        <h1 className="mt-2 font-display text-2xl tracking-display text-ink">
          {APP_NAME}
        </h1>
        <p className="mt-2 text-sm italic text-muted">{APP_SLOGAN}</p>
        <FileRule label="identifique-se" />
        <div className="mt-5 flex flex-col gap-4">
          <Field label="Nome no livro">
            <Input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Como o arquivo deve chamá-lo"
              maxLength={40}
            />
          </Field>
          <fieldset>
            <legend className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
              Função
            </legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <RoleCard
                selected={role === "gerente"}
                onSelect={() => setRole("gerente")}
                title="Gerente"
                body="Mestre da expedição. Vê o que os pecadores não devem."
              />
              <RoleCard
                selected={role === "pecador"}
                onSelect={() => setRole("pecador")}
                title="Pecador"
                body="Contratado. Carrega o dossiê e a dívida."
              />
            </div>
          </fieldset>
          <Button type="submit" className="mt-2 w-full">
            Selar designação
          </Button>
          <p className="text-center text-xs text-faint">
            A tinta, uma vez seca, ainda pode ser raspada no Protocolo.
          </p>
        </div>
      </form>
    </div>
  );
}

function RoleCard({
  selected,
  onSelect,
  title,
  body,
}: {
  selected: boolean;
  onSelect: () => void;
  title: string;
  body: string;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={
        selected
          ? "border border-gold bg-paper p-3 text-left"
          : "border border-edge bg-void p-3 text-left hover:border-gold-dim"
      }
    >
      <p className="font-display text-sm text-gold">{title}</p>
      <p className="mt-1 text-xs text-muted">{body}</p>
    </button>
  );
}
