import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookMarked,
  Dices,
  FileSignature,
  Landmark,
  Menu,
  Scale,
  ScrollText,
  Swords,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Toaster } from "sonner";
import { Gate } from "@/components/shell/gate";
import { WaxSeal } from "@/components/ornament";
import {
  APP_COMPANY,
  APP_FILE,
  APP_NAME,
  APP_SLOGAN,
} from "@/lib/ledger/constants";
import { useLedgerStore } from "@/lib/ledger/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Arquivo", icon: Landmark },
  { to: "/dossiers", label: "Dossiês", icon: BookMarked },
  { to: "/dice", label: "Dados", icon: Dices },
  { to: "/theatre", label: "Teatro", icon: Swords },
  { to: "/archive", label: "Campanha", icon: ScrollText },
  { to: "/contracts", label: "Contratos", icon: FileSignature },
  { to: "/protocol", label: "Protocolo", icon: Scale },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [more, setMore] = useState(false);
  const designation = useLedgerStore((s) => s.designation);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    let cancelled = false;
    const fallback = window.setTimeout(() => {
      if (!cancelled) setReady(true);
    }, 250);
    void Promise.resolve(useLedgerStore.persist.rehydrate())
      .catch(() => undefined)
      .finally(() => {
        if (cancelled) return;
        window.clearTimeout(fallback);
        setReady(true);
      });
    return () => {
      cancelled = true;
      window.clearTimeout(fallback);
    };
  }, []);

  if (!ready) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-5 bg-void text-ink">
        <WaxSeal letter="L" pulse className="size-16" />
        <p className="font-display text-xs uppercase tracking-stamp text-gold">
          Deslacrando arquivos
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-void text-ink">
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          className:
            "!bg-surface !text-ink !border-edge !font-sans !rounded-none",
        }}
      />
      {!designation.sealed ? <Gate /> : null}

      <div className="lg:grid lg:grid-cols-[16.5rem_minmax(0,1fr)]">
        <aside className="sticky top-0 hidden h-dvh flex-col border-r border-line bg-surface/80 px-5 py-6 lg:flex">
          <Link to="/" className="flex items-center gap-3">
            <WaxSeal letter="L" className="size-12 shrink-0" />
            <div>
              <p className="font-display text-2xs uppercase tracking-stamp text-gold">
                {APP_COMPANY}
              </p>
              <p className="font-display text-sm leading-tight tracking-wide text-ink">
                {APP_NAME}
              </p>
            </div>
          </Link>
          <p className="mt-4 text-xs leading-relaxed text-muted">{APP_SLOGAN}</p>
          <div className="rule my-5" />
          <nav className="flex flex-1 flex-col gap-1">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                {...item}
                active={isActive(pathname, item.to)}
              />
            ))}
          </nav>
          <div className="mt-4 border-t border-line pt-4">
            <p className="font-display text-2xs uppercase tracking-stamp text-faint">
              {APP_FILE}
            </p>
            {designation.sealed ? (
              <p className="mt-2 text-sm text-ink">
                {designation.role === "gerente" ? "Gerente" : "Pecador"}{" "}
                <span className="text-gold">{designation.name}</span>
              </p>
            ) : null}
          </div>
        </aside>

        <div className="flex min-h-dvh flex-col">
          <header className="flex items-center justify-between gap-3 border-b border-line bg-surface/70 px-4 py-3 lg:hidden">
            <Link to="/" className="flex items-center gap-2">
              <WaxSeal letter="L" className="size-10" />
              <span className="font-display text-xs tracking-wide">LEDGER</span>
            </Link>
            <button
              type="button"
              className="flex size-11 items-center justify-center text-ink"
              aria-label={more ? "Fechar menu" : "Abrir menu"}
              onClick={() => setMore((v) => !v)}
            >
              {more ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </header>

          {more ? (
            <div className="border-b border-line bg-surface px-3 py-3 lg:hidden">
              <nav className="grid grid-cols-2 gap-1">
                {NAV.map((item) => (
                  <NavLink
                    key={item.to}
                    {...item}
                    active={isActive(pathname, item.to)}
                    onClick={() => setMore(false)}
                  />
                ))}
              </nav>
            </div>
          ) : null}

          <main className="relative flex-1 px-4 py-5 pb-24 sm:px-6 lg:px-10 lg:py-8 lg:pb-10">
            {children}
          </main>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] lg:hidden">
        <ul className="grid grid-cols-5">
          {NAV.slice(0, 4).map((item) => {
            const Icon = item.icon;
            const active = isActive(pathname, item.to);
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex h-16 flex-col items-center justify-center gap-1 text-2xs uppercase tracking-wide",
                    active ? "text-gold" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={1.5} />
                  {item.label}
                </Link>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={() => setMore((v) => !v)}
              className={cn(
                "flex h-16 w-full flex-col items-center justify-center gap-1 text-2xs uppercase tracking-wide",
                more ? "text-gold" : "text-muted",
              )}
            >
              <Menu className="size-5" strokeWidth={1.5} />
              Mais
            </button>
          </li>
        </ul>
      </nav>
    </div>
  );
}

function isActive(path: string, to: string) {
  if (to === "/") return path === "/";
  return path === to || path.startsWith(`${to}/`);
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
  onClick,
}: {
  to: string;
  label: string;
  icon: typeof Landmark;
  active: boolean;
  onClick?: () => void;
}) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className={cn(
        "flex h-11 items-center gap-3 px-3 text-sm transition-colors duration-150",
        active
          ? "bg-paper text-gold"
          : "text-muted hover:bg-raised hover:text-ink",
      )}
    >
      <Icon className="size-4 shrink-0" strokeWidth={1.5} />
      {label}
    </Link>
  );
}

export function PageHeader({
  kicker,
  title,
  action,
  children,
}: {
  kicker: string;
  title: string;
  action?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <header className="enter mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
          {kicker}
        </p>
        <h1 className="mt-1 font-display text-2xl tracking-display text-ink sm:text-3xl">
          {title}
        </h1>
        {children ? (
          <div className="mt-2 max-w-2xl text-sm text-muted">{children}</div>
        ) : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </header>
  );
}

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="border border-dashed border-edge bg-raised/40 px-5 py-10 text-center">
      <p className="font-display text-lg text-gold">{title}</p>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted">{body}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  );
}
