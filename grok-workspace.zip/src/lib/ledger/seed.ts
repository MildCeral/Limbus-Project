import type {
  Campaign,
  Character,
  CombatState,
  LedgerData,
} from "./types";

const now = Date.UTC(2026, 8, 12, 21, 40);

function attr(
  id: string,
  name: string,
  abbr: string,
  value: number,
) {
  return { id, name, abbr, value };
}

function skill(id: string, name: string, attrId: string, value: number) {
  return { id, name, attr: attrId, value };
}

export const HELENA: Character = {
  id: "helena-voss",
  name: "Helena Voss",
  designation: "Pecadora nº 01",
  epithet: "A que leu o arquivo até o fim",
  system: "ledger",
  sin: "pride",
  sinRank: 4,
  classification: "CONFIDENCIAL / EX-I",
  hp: 22,
  hpMax: 28,
  sp: 16,
  spMax: 24,
  portrait: "/portraits/helena.jpg",
  attributes: [
    attr("body", "Corpo", "COR", 9),
    attr("reason", "Razão", "RAZ", 17),
    attr("will", "Vontade", "VON", 15),
    attr("instinct", "Instinto", "INS", 11),
    attr("presence", "Presença", "PRE", 12),
    attr("fortune", "Fortuna", "FOR", 8),
  ],
  skills: [
    skill("s1", "Arquivo", "reason", 6),
    skill("s2", "Ocultismo", "will", 5),
    skill("s3", "Observação", "instinct", 3),
    skill("s4", "Persuasão", "presence", 2),
    skill("s5", "Medicina", "reason", 3),
  ],
  talents: [
    {
      id: "t1",
      name: "Memória de Cartório",
      desc: "Uma vez por sessão, declare como verdadeiro um detalhe já escrito em qualquer dossiê aberto. O mundo hesita, depois concorda.",
    },
    {
      id: "t2",
      name: "Margem Anotada",
      desc: "Quando falha um teste de Razão, pode gastar 2 SP para reler o resultado como um 10 natural.",
    },
  ],
  spells: [
    {
      id: "sp1",
      name: "Redigir o Nome Verdadeiro",
      circle: 2,
      desc: "Escreve o nome oculto de um alvo. O próximo ataque contra ele ignora cobertura e orgulho.",
    },
  ],
  traumas: [
    {
      id: "tr1",
      name: "A Última Página em Branco",
      desc: "Helena não consegue encerrar um relato. Deixar um mistério sem nota a faz perder 1 SP por hora.",
    },
  ],
  sins: [
    {
      id: "si1",
      sin: "pride",
      rank: 4,
      desc: "Acredita que o arquivo é mais verdadeiro do que as pessoas que ele descreve.",
    },
  ],
  inventory: [
    { id: "i1", name: "Caneta-faca de osso", qty: 1, equipped: true, notes: "Escreve e corta com a mesma tinta." },
    { id: "i2", name: "Dossiê selado LCD-XII", qty: 1, notes: "Ainda não autorizado. Ela já leu." },
    { id: "i3", name: "Pó de arquivo", qty: 3, notes: "Cega distorções feitas de papel." },
  ],
  journal: [
    {
      id: "j1",
      title: "Sobre o Ramo",
      at: now - 86400000 * 3,
      sin: "pride",
      body: "O artefato não é uma planta. É uma correção. O Distrito 12 está sendo reescrito à mão, e a caligrafia não é humana. Solicitei autorização para anotar à margem. O Gerente recusou. Anotei mesmo assim.",
    },
    {
      id: "j2",
      title: "A pecadora nº 03",
      at: now - 86400000,
      sin: "gloom",
      body: "Inês ainda fala como se o contrato fosse uma cruzada. Eu invejo a clareza. Invejo, e catalogo a inveja, e sigo.",
    },
  ],
  notes:
    "Não dorme. Recita cláusulas para adormecer. Recusa ser chamada de heroína — prefere 'funcionária'.",
};

export const INES: Character = {
  id: "ines-quixote",
  name: "Inês Quixote",
  designation: "Pecadora nº 03",
  epithet: "A cavaleira de um sonho já falido",
  system: "ledger",
  sin: "lust",
  sinRank: 3,
  classification: "INTERNO / EX-III",
  hp: 31,
  hpMax: 34,
  sp: 18,
  spMax: 20,
  portrait: "/portraits/ines.jpg",
  attributes: [
    attr("body", "Corpo", "COR", 13),
    attr("reason", "Razão", "RAZ", 10),
    attr("will", "Vontade", "VON", 14),
    attr("instinct", "Instinto", "INS", 11),
    attr("presence", "Presença", "PRE", 16),
    attr("fortune", "Fortuna", "FOR", 12),
  ],
  skills: [
    skill("s1", "Persuasão", "presence", 5),
    skill("s2", "Atletismo", "body", 3),
    skill("s3", "Violência", "body", 3),
    skill("s4", "Intuição", "will", 4),
    skill("s5", "Ofício", "reason", 1),
  ],
  talents: [
    {
      id: "t1",
      name: "Juramento Recitado",
      desc: "Quando declara um ideal em voz alta, aliados a 6m ganham +2 no próximo teste. Se o ideal for mentira, ela perde 3 SP.",
    },
  ],
  spells: [
    {
      id: "sp1",
      name: "Lança do Capítulo Perdido",
      circle: 1,
      desc: "Uma lança de luz desbotada. Causa 1d8 + Presença, e brilha como se ainda houvesse honra no mundo.",
    },
  ],
  traumas: [
    {
      id: "tr1",
      name: "Aventura Obrigatória",
      desc: "Recusar um pedido de ajuda visível exige um teste de Vontade. Falha: ela vai mesmo assim.",
    },
  ],
  sins: [
    {
      id: "si1",
      sin: "lust",
      rank: 3,
      desc: "Fome de glória. Não de corpos — de um final em que alguém ainda a aplaude.",
    },
  ],
  inventory: [
    { id: "i1", name: "Lança quebrada (remendada)", qty: 1, equipped: true, notes: "O conserto é um laço amarelo." },
    { id: "i2", name: "Manual de cavalaria, 3ª edição", qty: 1, notes: "Todas as páginas de 'retirada' foram rasgadas." },
    { id: "i3", name: "Rações de teatro", qty: 4 },
  ],
  journal: [
    {
      id: "j1",
      title: "Ao meu senhor inexistente",
      at: now - 86400000 * 2,
      sin: "lust",
      body: "Hoje a chuva no beco parecia uma ovação. Helena diz que é só água. Eu sei. Ainda assim curvei a cabeça, como se o público invisível merecesse o gesto.",
    },
  ],
  notes: "Sorriso honesto demais para o Setor. O Gerente a considera 'utilizável'.",
};

export const CAIO: Character = {
  id: "caio-thorn",
  name: "Caio Thorn",
  designation: "Pecador nº 07",
  epithet: "O cão que ainda late contra a chuva",
  system: "dnd5e",
  sin: "wrath",
  sinRank: 5,
  classification: "RESTRITO / EX-VII",
  hp: 38,
  hpMax: 44,
  sp: 10,
  spMax: 16,
  portrait: "/portraits/caio.jpg",
  attributes: [
    attr("str", "Força", "FOR", 16),
    attr("dex", "Destreza", "DES", 14),
    attr("con", "Constituição", "CON", 15),
    attr("int", "Inteligência", "INT", 8),
    attr("wis", "Sabedoria", "SAB", 12),
    attr("cha", "Carisma", "CAR", 10),
  ],
  skills: [
    skill("s1", "Atletismo", "str", 5),
    skill("s2", "Intimidação", "cha", 4),
    skill("s3", "Percepção", "wis", 3),
    skill("s4", "Sobrevivência", "wis", 2),
    skill("s5", "Furtividade", "dex", 2),
  ],
  talents: [
    {
      id: "t1",
      name: "Tempestade Contida",
      desc: "Quando reduz um inimigo a 0, pode imediatamente se mover metade do deslocamento sem provocar.",
    },
    {
      id: "t2",
      name: "Ferida que Lembra",
      desc: "Vantagem em testes contra o mesmo tipo de criatura que o marcou na sessão anterior.",
    },
  ],
  spells: [],
  traumas: [
    {
      id: "tr1",
      name: "A Casa na Colina",
      desc: "Trovão e portas batendo o obrigam a um teste de Sabedoria ou ele ataca o ruído.",
    },
  ],
  sins: [
    {
      id: "si1",
      sin: "wrath",
      rank: 5,
      desc: "A raiva não é explosão — é clima. Uma estação que se recusa a passar.",
    },
  ],
  inventory: [
    { id: "i1", name: "Machado curto 'Cathy'", qty: 1, equipped: true, notes: "O nome não é explicado. Não pergunte." },
    { id: "i2", name: "Casaco pesado, rasgado", qty: 1, equipped: true },
    { id: "i3", name: "Frasco de uísque barato", qty: 2, notes: "Serve como combustível e como desculpa." },
  ],
  journal: [
    {
      id: "j1",
      title: "Não é um diário",
      at: now - 3600000 * 6,
      sin: "wrath",
      body: "A Companhia quer que eu escreva. Então está escrito: a chuva deste distrito tem gosto de ferrugem. O Rei de Papel cheira a biblioteca molhada. Vou quebrá-lo.",
    },
  ],
  notes: "Ficha em D&D 5e a pedido do próprio pecador. 'Não falo o dialeto da Companhia.'",
};

export const MIRA: Character = {
  id: "mira-k",
  name: "Mira K.",
  designation: "Pecadora nº 12",
  epithet: "A que só retrata o fim",
  system: "ledger",
  sin: "gloom",
  sinRank: 4,
  classification: "CONFIDENCIAL / EX-XII",
  hp: 24,
  hpMax: 26,
  sp: 22,
  spMax: 26,
  portrait: "/portraits/mira.jpg",
  attributes: [
    attr("body", "Corpo", "COR", 10),
    attr("reason", "Razão", "RAZ", 13),
    attr("will", "Vontade", "VON", 16),
    attr("instinct", "Instinto", "INS", 14),
    attr("presence", "Presença", "PRE", 8),
    attr("fortune", "Fortuna", "FOR", 11),
  ],
  skills: [
    skill("s1", "Ofício", "reason", 6),
    skill("s2", "Ocultismo", "will", 4),
    skill("s3", "Observação", "instinct", 5),
    skill("s4", "Furtividade", "instinct", 3),
    skill("s5", "Intuição", "will", 3),
  ],
  talents: [
    {
      id: "t1",
      name: "Retrato Antecipado",
      desc: "Gasta um turno pintando o destino de um alvo. No próximo acerto contra ele, causa dano extra igual ao círculo da obra (1d6 por rank de pecado).",
    },
  ],
  spells: [
    {
      id: "sp1",
      name: "Verniz de Ausência",
      circle: 2,
      desc: "Uma figura pintada desaparece do olhar casual por 10 minutos. Magia e cães ainda a veem.",
    },
    {
      id: "sp2",
      name: "Tinta que Lembra Sangue",
      circle: 1,
      desc: "Conjurar exige um corte raso. Cura 1d4 ou marca um inimigo como 'já morto no quadro'.",
    },
  ],
  traumas: [
    {
      id: "tr1",
      name: "Nada Terminado",
      desc: "Obras inacabadas a puxam. Sair de uma cena sem 'fechar a composição' custa 2 SP.",
    },
  ],
  sins: [
    {
      id: "si1",
      sin: "gloom",
      rank: 4,
      desc: "A beleza, para Mira, só existe no instante em que algo deixa de poder ser salvo.",
    },
  ],
  inventory: [
    { id: "i1", name: "Estojo de pigmentos proibidos", qty: 1, equipped: true, notes: "Um tubo está lacrado com cera da Companhia." },
    { id: "i2", name: "Tela dobrável, 40cm", qty: 1 },
    { id: "i3", name: "Lâmina de espátula", qty: 1, equipped: true },
  ],
  journal: [
    {
      id: "j1",
      title: "Estudo em vermelho desbotado",
      at: now - 86400000 * 4,
      sin: "gloom",
      body: "Pintei o Gerente sem o rosto. Ele aprovou o quadro. Disse que estava 'preciso'. Não sei se foi elogio ou confissão.",
    },
    {
      id: "j2",
      title: "O Rei",
      at: now - 7200000,
      sin: "gloom",
      body: "Ele é feito de índices. Se eu pintar o sumário errado, talvez o corpo dele se perca entre os capítulos.",
    },
  ],
  notes: "Fala pouco. Quando fala, parece estar legendando um quadro que só ela vê.",
};

export function seedCampaign(): Campaign {
  return {
    id: "ramo-dourado",
    code: "LCD-XII-441",
    name: "Expedição do Ramo Dourado",
    premise:
      "A Companhia despachou quatro pecadores ao Distrito 12 para recuperar um artefato literário — o Ramo Dourado — que passou a reescrever ruas, nomes e dívidas. A chuva local tem gosto de tinta. Os habitantes começam a falar em versos que não escolheram.",
    notes:
      "Tom da mesa: gótico burocrático. Recompense anotações no diário. Punir a omissão, não o fracasso. O Rei de Papel não pode ser morto até que alguém o catalogue corretamente.",
    npcs: [
      {
        id: "npc-faustian",
        name: "Gerente Faustian",
        role: "Handler da expedição",
        attitude: "Cortês, inumano, pontual.",
        secrets:
          "Já esteve no Distrito 12. Parte de seu nome foi reescrita; o sorriso é o que restou.",
        notes: "Comunica-se por carimbos e telefonemas que cheiram a ozônio.",
        locationId: "loc-sede",
      },
      {
        id: "npc-biblio",
        name: "O Bibliotecário Cego",
        role: "Guardião da Biblioteca de Cinzas",
        attitude: "Hospitalar com quem sussurra.",
        secrets:
          "Não é cego. Recusa-se a ver para não ser indexado pelo Rei.",
        notes: "Aceita pagamentos em histórias verdadeiras, nunca em ouro.",
        locationId: "loc-biblio",
      },
      {
        id: "npc-glass",
        name: "Madame Glass",
        role: "Proprietária do cabaré O Último Ato",
        attitude: "Encantadora, venenosa, útil.",
        secrets:
          "Seu verdadeiro contrato é com o próprio Ramo. Cada número no palco é uma cláusula.",
        notes: "Conhece o nome de batismo de Caio. Não usa.",
        locationId: "loc-cabare",
      },
      {
        id: "npc-rei",
        name: "O Rei de Papel",
        role: "Distorção maior / antagonista",
        attitude: "Majestoso, entediado, faminto por índices.",
        secrets:
          "Foi um arquivista da Companhia. Pediu para ser esquecido. O pedido foi protocolado tarde demais.",
        notes: "Fraco contra catalogação correta e fogo. Forte contra omissão e metáforas vagas.",
        locationId: "loc-biblio",
      },
    ],
    places: [
      {
        id: "loc-sede",
        name: "Sede Subterrânea",
        kind: "Q.G. da Companhia",
        danger: 1,
        desc: "Corredores de concreto úmido, selos de cera nas portas, um relógio que atrasa só para pecadores. O cheiro é de papel-carbono e sangue seco.",
      },
      {
        id: "loc-biblio",
        name: "Biblioteca de Cinzas",
        kind: "Ruína literária",
        danger: 4,
        desc: "Prateleiras até o teto negro. Livros que se abrem sozinhos. Cinza fina cobre o chão como neve. O Rei anda entre os corredores como um sumário.",
      },
      {
        id: "loc-cabare",
        name: "Cabaré O Último Ato",
        kind: "Estabelecimento noturno",
        danger: 2,
        desc: "Palco vermelho desbotado, espelhos que recusam certos rostos, orquestra de três músicos que nunca piscam. Madame Glass serve absinto com cláusulas no fundo da taça.",
      },
      {
        id: "loc-beco",
        name: "Beco da Chuva Eterna",
        kind: "Via pública distorcida",
        danger: 3,
        desc: "A água não encharca — anota. Quem atravessa depressa demais deixa um parágrafo para trás.",
      },
    ],
    sessions: [
      {
        id: "ses-1",
        number: 1,
        title: "A Abertura do Dossiê",
        date: "04.09.2026",
        summary:
          "Os quatro pecadores foram apresentados, selados e despachados. Helena violou o lacre do dossiê no trem. Inês saudou o condutor como se ele fosse um rei. Caio dormiu. Mira desenhou a janela até ela deixar de ser uma janela.",
        notes: "Gancho: o bilhete do trem estava escrito na caligrafia do Rei.",
      },
      {
        id: "ses-2",
        number: 2,
        title: "Chuva no Beco",
        date: "11.09.2026",
        summary:
          "Primeiro contato com uma distorção menor (Escriba Rasgado). Combate na chuva. O Bibliotecário Cego ofereceu abrigo em troca de uma história verdadeira — Caio recusou; Mira pagou com um retrato.",
        notes: "Iniciativa longa. Teatro da mente no começo, mapa no beco.",
      },
    ],
    contracts: [
      {
        id: "c-ramo",
        code: "CT-441-A",
        title: "Recuperar o Ramo Dourado",
        status: "andamento",
        rank: "Carmesim",
        hook: "O artefato está 'enraizado' na Biblioteca de Cinzas. Cortá-lo exige um nome verdadeiro.",
        terms: "Trazer o Ramo intacto. Não publicar versos obtidos no Distrito. Sobrevivência: opcional.",
        reward: "Remissão parcial de um pecado (rank −1) e 400 cinzas de arquivo.",
        relatedIds: ["helena-voss", "ines-quixote", "caio-thorn", "mira-k"],
      },
      {
        id: "c-cat",
        code: "CT-441-B",
        title: "Catalogar três distorções",
        status: "aberto",
        rank: "Âmbar",
        hook: "O Setor de Arquivo recusa combate sem formulário. Cada distorção nomeada enfraquece o Rei.",
        terms: "Nome, origem provável e um retrato ou amostra. Mentir no formulário alimenta o Rei.",
        reward: "Acesso ao Anexo Proibido por uma sessão.",
        relatedIds: ["helena-voss", "mira-k"],
      },
      {
        id: "c-livro",
        code: "CT-441-C",
        title: "Extrair o Livro-Vivo",
        status: "aberto",
        rank: "Íris",
        hook: "Uma testemunha no cabaré está se tornando texto. Madame Glass finge não notar.",
        terms: "Extrair com vida. Se virar capítulo, arquivar mesmo assim.",
        reward: "Um favor de Madame Glass — e ela cobra juros em memórias.",
        relatedIds: ["ines-quixote"],
      },
      {
        id: "c-selado",
        code: "CT-118-Z",
        title: "Não mencionar o Gerente anterior",
        status: "selado",
        rank: "Obsidiana",
        hook: "Cláusula herdada. O dossiê existe, mas a capa está em branco.",
        terms: "Silêncio. Qualquer pecador que ler este contrato já o violou.",
        reward: "Nenhuma. A recompensa é continuar existindo no índice.",
        relatedIds: [],
      },
    ],
    timeline: [
      {
        id: "tl1",
        at: "Há 40 anos",
        title: "Fundação oficiosa da Companhia",
        body: "Um cartório que passou a aceitar dívidas que o Estado recusava. O primeiro pecador assinou com sangue porque a tinta havia acabado.",
      },
      {
        id: "tl2",
        at: "Há 11 anos",
        title: "Incidente do Arquivista",
        body: "Um funcionário pediu para ser apagado. O pedido entrou na fila. Quando foi processado, ele já era o Rei de Papel.",
        secret: true,
      },
      {
        id: "tl3",
        at: "04.09.2026",
        title: "Expedição XII despachada",
        body: "Quatro pecadores, um dossiê, nenhum regresso garantido.",
      },
      {
        id: "tl4",
        at: "11.09.2026",
        title: "Primeira distorção catalogada",
        body: "Escriba Rasgado — origem: formulários não assinados. Destino: cinzas.",
      },
      {
        id: "tl5",
        at: "Próxima sessão",
        title: "O Último Ato",
        body: "Madame Glass convidou a expedição para um número especial. O convite está escrito no verso de um atestado de óbito em branco.",
      },
    ],
  };
}

export function seedCombat(): CombatState {
  return {
    name: "Biblioteca de Cinzas — Corredor do Índice",
    grid: "square",
    theatre: false,
    cols: 12,
    rows: 9,
    turnIndex: 0,
    round: 1,
    selectedId: null,
    log: [
      {
        id: "l1",
        at: now,
        text: "O Rei de Papel abre o próprio peito como um livro. 'Estão atrasados para o empréstimo.'",
      },
    ],
    tokens: [
      {
        id: "tok-helena",
        name: "Helena",
        kind: "sinner",
        x: 1,
        y: 4,
        hp: 22,
        hpMax: 28,
        initiative: 14,
        characterId: "helena-voss",
        conditions: [],
        notes: "",
        sin: "pride",
      },
      {
        id: "tok-ines",
        name: "Inês",
        kind: "sinner",
        x: 2,
        y: 6,
        hp: 31,
        hpMax: 34,
        initiative: 16,
        characterId: "ines-quixote",
        conditions: [],
        notes: "",
        sin: "lust",
      },
      {
        id: "tok-caio",
        name: "Caio",
        kind: "sinner",
        x: 2,
        y: 2,
        hp: 38,
        hpMax: 44,
        initiative: 12,
        characterId: "caio-thorn",
        conditions: ["Sangrando"],
        notes: "Corte raso no ombro — tinta, não sangue.",
        sin: "wrath",
      },
      {
        id: "tok-mira",
        name: "Mira",
        kind: "sinner",
        x: 0,
        y: 3,
        hp: 24,
        hpMax: 26,
        initiative: 15,
        characterId: "mira-k",
        conditions: ["Concentrando"],
        notes: "Pinta o Rei no verso de um formulário.",
        sin: "gloom",
      },
      {
        id: "tok-rei",
        name: "Rei de Papel",
        kind: "enemy",
        x: 9,
        y: 4,
        hp: 72,
        hpMax: 72,
        initiative: 13,
        conditions: [],
        notes: "Distorção maior. Fraco a catalogação e fogo.",
        sin: "pride",
      },
      {
        id: "tok-esc1",
        name: "Escriba Rasgado",
        kind: "enemy",
        x: 7,
        y: 2,
        hp: 18,
        hpMax: 22,
        initiative: 11,
        conditions: [],
        notes: "Minion. Tenta indexar pecadores.",
      },
      {
        id: "tok-esc2",
        name: "Escriba Rasgado",
        kind: "enemy",
        x: 8,
        y: 6,
        hp: 14,
        hpMax: 22,
        initiative: 9,
        conditions: ["Amedrontado"],
        notes: "Recua se um dossiê for aberto contra ele.",
      },
      {
        id: "tok-haz",
        name: "Prateleira Instável",
        kind: "hazard",
        x: 5,
        y: 4,
        hp: 8,
        hpMax: 8,
        initiative: 0,
        conditions: [],
        notes: "Quem termina o turno adjacente: 1d6 de impacto (livros).",
      },
    ],
  };
}

export function seedLedger(): LedgerData {
  return {
    version: 1,
    designation: { name: "", role: "gerente", sealed: false },
    characters: [HELENA, INES, CAIO, MIRA],
    campaign: seedCampaign(),
    combat: seedCombat(),
    rolls: [
      {
        id: "r1",
        formula: "1d20+6",
        dice: [14],
        sides: 20,
        modifier: 6,
        total: 20,
        label: "Helena · Arquivo (catalogar distorção)",
        secret: false,
        at: now - 3600000,
        characterId: "helena-voss",
      },
      {
        id: "r2",
        formula: "1d20+5 [vantagem]",
        dice: [9, 17],
        sides: 20,
        modifier: 5,
        total: 22,
        label: "Inês · Persuasão (convencer o Bibliotecário)",
        secret: false,
        at: now - 2400000,
        characterId: "ines-quixote",
      },
      {
        id: "r3",
        formula: "2d6+4",
        dice: [6, 3],
        sides: 6,
        modifier: 4,
        total: 13,
        label: "Caio · Machado 'Cathy'",
        secret: false,
        at: now - 1800000,
        characterId: "caio-thorn",
      },
      {
        id: "r4",
        formula: "1d20",
        dice: [3],
        sides: 20,
        modifier: 0,
        total: 3,
        label: "Olhos do Gerente · intenção do Rei",
        secret: true,
        at: now - 600000,
      },
    ],
  };
}

export const ENEMY_PORTRAITS: Record<string, string> = {
  "tok-rei": "/portraits/rei-papel.jpg",
  "tok-esc1": "/portraits/escriba.jpg",
  "tok-esc2": "/portraits/escriba.jpg",
};
