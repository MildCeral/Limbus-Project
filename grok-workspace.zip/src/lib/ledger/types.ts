export type SystemId = "ledger" | "dnd5e" | "generic";
export type Role = "gerente" | "pecador";
export type SinId =
  | "wrath"
  | "lust"
  | "sloth"
  | "gluttony"
  | "gloom"
  | "pride"
  | "envy";

export type ContractStatus =
  | "aberto"
  | "andamento"
  | "cumprido"
  | "falhou"
  | "selado";

export type TokenKind = "sinner" | "ally" | "enemy" | "hazard";
export type GridType = "square" | "hex";

export interface Attr {
  id: string;
  name: string;
  abbr: string;
  value: number;
}

export interface Skill {
  id: string;
  name: string;
  attr: string;
  value: number;
}

export interface Talent {
  id: string;
  name: string;
  desc: string;
}

export interface Spell {
  id: string;
  name: string;
  circle: number;
  desc: string;
}

export interface Trauma {
  id: string;
  name: string;
  desc: string;
}

export interface SinRecord {
  id: string;
  sin: SinId;
  rank: number;
  desc: string;
}

export interface Item {
  id: string;
  name: string;
  qty: number;
  equipped?: boolean;
  notes?: string;
}

export interface JournalEntry {
  id: string;
  title: string;
  body: string;
  at: number;
  sin?: SinId;
}

export interface Character {
  id: string;
  name: string;
  designation: string;
  epithet: string;
  system: SystemId;
  sin: SinId;
  sinRank: number;
  classification: string;
  hp: number;
  hpMax: number;
  sp: number;
  spMax: number;
  attributes: Attr[];
  skills: Skill[];
  talents: Talent[];
  spells: Spell[];
  traumas: Trauma[];
  sins: SinRecord[];
  inventory: Item[];
  journal: JournalEntry[];
  notes: string;
  portrait: string;
}

export interface Npc {
  id: string;
  name: string;
  role: string;
  attitude: string;
  secrets: string;
  notes: string;
  locationId?: string;
}

export interface Place {
  id: string;
  name: string;
  kind: string;
  desc: string;
  danger: number;
}

export interface SessionLog {
  id: string;
  number: number;
  title: string;
  date: string;
  summary: string;
  notes: string;
}

export interface Contract {
  id: string;
  code: string;
  title: string;
  status: ContractStatus;
  rank: string;
  hook: string;
  terms: string;
  reward: string;
  relatedIds: string[];
}

export interface TimelineEvent {
  id: string;
  at: string;
  title: string;
  body: string;
  secret?: boolean;
}

export interface Token {
  id: string;
  name: string;
  kind: TokenKind;
  x: number;
  y: number;
  hp: number;
  hpMax: number;
  conditions: string[];
  characterId?: string;
  initiative: number;
  notes: string;
  sin?: SinId;
}

export interface CombatLog {
  id: string;
  text: string;
  at: number;
}

export interface CombatState {
  name: string;
  grid: GridType;
  theatre: boolean;
  cols: number;
  rows: number;
  tokens: Token[];
  turnIndex: number;
  round: number;
  log: CombatLog[];
  selectedId: string | null;
}

export interface DiceRoll {
  id: string;
  formula: string;
  dice: number[];
  sides: number;
  modifier: number;
  total: number;
  label: string;
  secret: boolean;
  at: number;
  characterId?: string;
}

export interface Designation {
  name: string;
  role: Role;
  sealed: boolean;
}

export interface Campaign {
  id: string;
  code: string;
  name: string;
  premise: string;
  npcs: Npc[];
  places: Place[];
  sessions: SessionLog[];
  contracts: Contract[];
  timeline: TimelineEvent[];
  notes: string;
}

export interface LedgerData {
  version: number;
  designation: Designation;
  characters: Character[];
  campaign: Campaign;
  rolls: DiceRoll[];
  combat: CombatState;
}
