import { create } from "zustand";
import { persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import { executeRoll, type Advantage } from "@/lib/ledger/dice";
import { attrsFor, DND_SKILLS, LEDGER_SKILLS } from "@/lib/ledger/constants";
import { seedCombat, seedLedger } from "@/lib/ledger/seed";
import type {
  Campaign,
  Character,
  CombatState,
  Contract,
  DiceRoll,
  GridType,
  JournalEntry,
  LedgerData,
  Npc,
  Place,
  Role,
  SessionLog,
  TimelineEvent,
  Token,
} from "@/lib/ledger/types";

export type { Advantage };

interface LedgerStore extends LedgerData {
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  sealDesignation: (name: string, role: Role) => void;
  addCharacter: (c: Character) => void;
  updateCharacter: (id: string, patch: Partial<Character>) => void;
  deleteCharacter: (id: string) => void;
  patchCharacter: (id: string, fn: (c: Character) => Character) => void;
  addJournal: (characterId: string, entry: Omit<JournalEntry, "id">) => void;
  updateCampaign: (patch: Partial<Campaign>) => void;
  addNpc: (n: Npc) => void;
  updateNpc: (id: string, patch: Partial<Npc>) => void;
  deleteNpc: (id: string) => void;
  addPlace: (p: Place) => void;
  updatePlace: (id: string, patch: Partial<Place>) => void;
  deletePlace: (id: string) => void;
  addSession: (s: SessionLog) => void;
  updateSession: (id: string, patch: Partial<SessionLog>) => void;
  deleteSession: (id: string) => void;
  addContract: (c: Contract) => void;
  updateContract: (id: string, patch: Partial<Contract>) => void;
  deleteContract: (id: string) => void;
  addEvent: (e: TimelineEvent) => void;
  deleteEvent: (id: string) => void;
  recordRoll: (
    input: string,
    opts?: {
      label?: string;
      secret?: boolean;
      characterId?: string;
      advantage?: Advantage;
    },
  ) => DiceRoll | null;
  clearRolls: () => void;
  selectToken: (id: string | null) => void;
  moveToken: (id: string, x: number, y: number) => void;
  updateToken: (id: string, patch: Partial<Token>) => void;
  addToken: (t: Omit<Token, "id">) => void;
  removeToken: (id: string) => void;
  nextTurn: () => void;
  setGrid: (grid: GridType) => void;
  setTheatre: (v: boolean) => void;
  addCombatLog: (text: string) => void;
  resetCombat: () => void;
  exportJson: () => string;
  importJson: (raw: string) => { ok: true } | { ok: false; error: string };
  resetDemo: () => void;
}

function sortedTokens(tokens: Token[]) {
  return [...tokens].sort(
    (a, b) => b.initiative - a.initiative || a.name.localeCompare(b.name, "pt"),
  );
}

function dataOf(s: LedgerData): LedgerData {
  return {
    version: 1,
    designation: s.designation,
    characters: s.characters,
    campaign: s.campaign,
    rolls: s.rolls,
    combat: s.combat,
  };
}

export const useLedgerStore = create<LedgerStore>()(
  persist(
    (set, get) => ({
      ...seedLedger(),
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),
      sealDesignation: (name, role) =>
        set({ designation: { name: name.trim(), role, sealed: true } }),
      addCharacter: (c) => set({ characters: [...get().characters, c] }),
      updateCharacter: (id, patch) =>
        set({
          characters: get().characters.map((c) =>
            c.id === id ? { ...c, ...patch } : c,
          ),
        }),
      deleteCharacter: (id) =>
        set({
          characters: get().characters.filter((c) => c.id !== id),
          combat: {
            ...get().combat,
            tokens: get().combat.tokens.filter((t) => t.characterId !== id),
          },
        }),
      patchCharacter: (id, fn) =>
        set({
          characters: get().characters.map((c) => (c.id === id ? fn(c) : c)),
        }),
      addJournal: (characterId, entry) =>
        set({
          characters: get().characters.map((c) =>
            c.id === characterId
              ? { ...c, journal: [{ ...entry, id: uid("j") }, ...c.journal] }
              : c,
          ),
        }),
      updateCampaign: (patch) =>
        set({ campaign: { ...get().campaign, ...patch } }),
      addNpc: (n) =>
        set({ campaign: { ...get().campaign, npcs: [n, ...get().campaign.npcs] } }),
      updateNpc: (id, patch) =>
        set({
          campaign: {
            ...get().campaign,
            npcs: get().campaign.npcs.map((n) =>
              n.id === id ? { ...n, ...patch } : n,
            ),
          },
        }),
      deleteNpc: (id) =>
        set({
          campaign: {
            ...get().campaign,
            npcs: get().campaign.npcs.filter((n) => n.id !== id),
          },
        }),
      addPlace: (p) =>
        set({
          campaign: { ...get().campaign, places: [p, ...get().campaign.places] },
        }),
      updatePlace: (id, patch) =>
        set({
          campaign: {
            ...get().campaign,
            places: get().campaign.places.map((p) =>
              p.id === id ? { ...p, ...patch } : p,
            ),
          },
        }),
      deletePlace: (id) =>
        set({
          campaign: {
            ...get().campaign,
            places: get().campaign.places.filter((p) => p.id !== id),
          },
        }),
      addSession: (s) =>
        set({
          campaign: {
            ...get().campaign,
            sessions: [s, ...get().campaign.sessions],
          },
        }),
      updateSession: (id, patch) =>
        set({
          campaign: {
            ...get().campaign,
            sessions: get().campaign.sessions.map((s) =>
              s.id === id ? { ...s, ...patch } : s,
            ),
          },
        }),
      deleteSession: (id) =>
        set({
          campaign: {
            ...get().campaign,
            sessions: get().campaign.sessions.filter((s) => s.id !== id),
          },
        }),
      addContract: (c) =>
        set({
          campaign: {
            ...get().campaign,
            contracts: [c, ...get().campaign.contracts],
          },
        }),
      updateContract: (id, patch) =>
        set({
          campaign: {
            ...get().campaign,
            contracts: get().campaign.contracts.map((c) =>
              c.id === id ? { ...c, ...patch } : c,
            ),
          },
        }),
      deleteContract: (id) =>
        set({
          campaign: {
            ...get().campaign,
            contracts: get().campaign.contracts.filter((c) => c.id !== id),
          },
        }),
      addEvent: (e) =>
        set({
          campaign: {
            ...get().campaign,
            timeline: [e, ...get().campaign.timeline],
          },
        }),
      deleteEvent: (id) =>
        set({
          campaign: {
            ...get().campaign,
            timeline: get().campaign.timeline.filter((e) => e.id !== id),
          },
        }),
      recordRoll: (input, opts) => {
        const result = executeRoll(input, opts?.advantage ?? "normal");
        if (!result) return null;
        const roll: DiceRoll = {
          id: uid("r"),
          formula: result.formula,
          dice: result.dice,
          sides: result.sides,
          modifier: result.modifier,
          total: result.total,
          label: opts?.label?.trim() || "Rolagem avulsa",
          secret: Boolean(opts?.secret),
          at: Date.now(),
          characterId: opts?.characterId,
        };
        set({ rolls: [roll, ...get().rolls].slice(0, 80) });
        return roll;
      },
      clearRolls: () => set({ rolls: [] }),
      selectToken: (id) =>
        set({ combat: { ...get().combat, selectedId: id } }),
      moveToken: (id, x, y) => {
        const combat = get().combat;
        const token = combat.tokens.find((t) => t.id === id);
        if (!token) return;
        const nx = Math.max(0, Math.min(combat.cols - 1, x));
        const ny = Math.max(0, Math.min(combat.rows - 1, y));
        if (nx === token.x && ny === token.y) return;
        set({
          combat: {
            ...combat,
            tokens: combat.tokens.map((t) =>
              t.id === id ? { ...t, x: nx, y: ny } : t,
            ),
            log: [
              {
                id: uid("l"),
                at: Date.now(),
                text: `${token.name} desloca-se para ${String.fromCharCode(65 + nx)}${ny + 1}.`,
              },
              ...combat.log,
            ].slice(0, 40),
          },
        });
      },
      updateToken: (id, patch) =>
        set({
          combat: {
            ...get().combat,
            tokens: get().combat.tokens.map((t) =>
              t.id === id ? { ...t, ...patch } : t,
            ),
          },
        }),
      addToken: (t) =>
        set({
          combat: {
            ...get().combat,
            tokens: [...get().combat.tokens, { ...t, id: uid("tok") }],
          },
        }),
      removeToken: (id) => {
        const combat = get().combat;
        const next = combat.tokens.filter((t) => t.id !== id);
        const sorted = sortedTokens(next.filter((t) => t.kind !== "hazard"));
        const turnIndex = Math.min(
          combat.turnIndex,
          Math.max(0, sorted.length - 1),
        );
        set({
          combat: {
            ...combat,
            tokens: next,
            selectedId: combat.selectedId === id ? null : combat.selectedId,
            turnIndex,
          },
        });
      },
      nextTurn: () => {
        const combat = get().combat;
        const order = sortedTokens(
          combat.tokens.filter((t) => t.kind !== "hazard"),
        );
        if (order.length === 0) return;
        const nextIndex = (combat.turnIndex + 1) % order.length;
        const round = nextIndex === 0 ? combat.round + 1 : combat.round;
        const current = order[nextIndex];
        set({
          combat: {
            ...combat,
            turnIndex: nextIndex,
            round,
            log: [
              {
                id: uid("l"),
                at: Date.now(),
                text: `Turno de ${current.name}. Relógio: rodada ${round}.`,
              },
              ...combat.log,
            ].slice(0, 40),
          },
        });
      },
      setGrid: (grid) => set({ combat: { ...get().combat, grid } }),
      setTheatre: (theatre) => set({ combat: { ...get().combat, theatre } }),
      addCombatLog: (text) =>
        set({
          combat: {
            ...get().combat,
            log: [
              { id: uid("l"), at: Date.now(), text },
              ...get().combat.log,
            ].slice(0, 40),
          },
        }),
      resetCombat: () => set({ combat: seedCombat() }),
      exportJson: () => JSON.stringify(dataOf(get()), null, 2),
      importJson: (raw) => {
        try {
          const parsed = JSON.parse(raw) as Partial<LedgerData>;
          if (!parsed || typeof parsed !== "object") {
            return { ok: false, error: "O lacre não reconhece este formato." };
          }
          const base = seedLedger();
          set({
            designation: parsed.designation ?? base.designation,
            characters: parsed.characters ?? base.characters,
            campaign: parsed.campaign ?? base.campaign,
            rolls: parsed.rolls ?? [],
            combat: parsed.combat ?? base.combat,
          });
          return { ok: true };
        } catch {
          return {
            ok: false,
            error:
              "O arquivo recusou-se a abrir. Talvez não fosse para você lê-lo.",
          };
        }
      },
      resetDemo: () => {
        const current = get().designation;
        const fresh = seedLedger();
        set({
          ...fresh,
          designation: current.sealed ? current : fresh.designation,
        });
      },
    }),
    {
      name: "infernal-ledger-v1",
      version: 1,
      skipHydration: true,
      partialize: (s) => ({
        version: s.version,
        designation: s.designation,
        characters: s.characters,
        campaign: s.campaign,
        rolls: s.rolls,
        combat: s.combat,
      }),
    },
  ),
);

export function combatOrder(combat: CombatState) {
  return sortedTokens(combat.tokens.filter((t) => t.kind !== "hazard"));
}

export function currentActor(combat: CombatState) {
  const order = combatOrder(combat);
  if (order.length === 0) return null;
  return order[combat.turnIndex % order.length] ?? null;
}

export function makeBlankCharacter(
  system: Character["system"] = "ledger",
): Character {
  const attributes = attrsFor(system);
  const skillSrc = system === "dnd5e" ? DND_SKILLS : LEDGER_SKILLS;
  return {
    id: uid("pc"),
    name: "",
    designation: "Pecador nº —",
    epithet: "",
    system,
    sin: "gloom",
    sinRank: 1,
    classification: "INTERNO",
    hp: 20,
    hpMax: 20,
    sp: 16,
    spMax: 16,
    portrait: "",
    attributes,
    skills: skillSrc.slice(0, 6).map((s, i) => ({
      id: uid("sk"),
      name: s.name,
      attr: s.attr,
      value: i === 0 ? 3 : 1,
    })),
    talents: [],
    spells: [],
    traumas: [],
    sins: [],
    inventory: [],
    journal: [],
    notes: "",
  };
}
