export interface ParsedFormula {
  count: number;
  sides: number;
  modifier: number;
}

export function parseFormula(input: string): ParsedFormula | null {
  const s = input.trim().toLowerCase().replace(/\s/g, "");
  const m = s.match(/^(\d*)d(\d+)([+-]\d+)?$/);
  if (!m) return null;
  const count = m[1] ? Number.parseInt(m[1], 10) : 1;
  const sides = Number.parseInt(m[2], 10);
  const modifier = m[3] ? Number.parseInt(m[3], 10) : 0;
  if (!Number.isFinite(count) || !Number.isFinite(sides)) return null;
  if (count < 1 || count > 40 || sides < 2 || sides > 1000) return null;
  if (Math.abs(modifier) > 999) return null;
  return { count, sides, modifier };
}

export function formulaString(p: ParsedFormula) {
  const base = `${p.count}d${p.sides}`;
  if (p.modifier === 0) return base;
  return p.modifier > 0 ? `${base}+${p.modifier}` : `${base}${p.modifier}`;
}

function rollDie(sides: number) {
  return 1 + Math.floor(Math.random() * sides);
}

export type Advantage = "normal" | "adv" | "dis";

export interface RollResult {
  formula: string;
  dice: number[];
  sides: number;
  modifier: number;
  total: number;
}

export function executeRoll(
  input: string,
  advantage: Advantage = "normal",
): RollResult | null {
  const parsed = parseFormula(input);
  if (!parsed) return null;

  if (advantage !== "normal" && parsed.count === 1) {
    const a = rollDie(parsed.sides);
    const b = rollDie(parsed.sides);
    const kept = advantage === "adv" ? Math.max(a, b) : Math.min(a, b);
    return {
      formula: `${formulaString(parsed)} [${advantage === "adv" ? "vantagem" : "desvantagem"}]`,
      dice: [a, b],
      sides: parsed.sides,
      modifier: parsed.modifier,
      total: kept + parsed.modifier,
    };
  }

  const dice = Array.from({ length: parsed.count }, () => rollDie(parsed.sides));
  const sum = dice.reduce((acc, n) => acc + n, 0);
  return {
    formula: formulaString(parsed),
    dice,
    sides: parsed.sides,
    modifier: parsed.modifier,
    total: sum + parsed.modifier,
  };
}

export function skillCheckFormula(mod: number) {
  return mod >= 0 ? `1d20+${mod}` : `1d20${mod}`;
}
