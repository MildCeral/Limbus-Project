import type { SinId, SystemId } from "./types";

export const APP_NAME = "THE INFERNAL LEDGER";
export const APP_COMPANY = "Companhia dos Esquecidos";
export const APP_SLOGAN = "Todo pecado é registrado. Toda dívida é cobrada.";
export const APP_FILE = "LEDGER-VII / SETOR DE ARQUIVO";

export const SINS: {
  id: SinId;
  name: string;
  latin: string;
  hue: string;
}[] = [
  { id: "wrath", name: "Ira", latin: "Ira", hue: "var(--color-sin-wrath)" },
  { id: "lust", name: "Luxúria", latin: "Luxuria", hue: "var(--color-sin-lust)" },
  { id: "sloth", name: "Preguiça", latin: "Acedia", hue: "var(--color-sin-sloth)" },
  {
    id: "gluttony",
    name: "Gula",
    latin: "Gula",
    hue: "var(--color-sin-gluttony)",
  },
  { id: "gloom", name: "Melancolia", latin: "Tristitia", hue: "var(--color-sin-gloom)" },
  { id: "pride", name: "Orgulho", latin: "Superbia", hue: "var(--color-sin-pride)" },
  { id: "envy", name: "Inveja", latin: "Invidia", hue: "var(--color-sin-envy)" },
];

export function sinMeta(id: SinId) {
  return SINS.find((s) => s.id === id) ?? SINS[0];
}

export const LEDGER_ATTRS = [
  { id: "body", name: "Corpo", abbr: "COR" },
  { id: "reason", name: "Razão", abbr: "RAZ" },
  { id: "will", name: "Vontade", abbr: "VON" },
  { id: "instinct", name: "Instinto", abbr: "INS" },
  { id: "presence", name: "Presença", abbr: "PRE" },
  { id: "fortune", name: "Fortuna", abbr: "FOR" },
] as const;

export const DND_ATTRS = [
  { id: "str", name: "Força", abbr: "FOR" },
  { id: "dex", name: "Destreza", abbr: "DES" },
  { id: "con", name: "Constituição", abbr: "CON" },
  { id: "int", name: "Inteligência", abbr: "INT" },
  { id: "wis", name: "Sabedoria", abbr: "SAB" },
  { id: "cha", name: "Carisma", abbr: "CAR" },
] as const;

export function attrsFor(system: SystemId) {
  if (system === "dnd5e") return DND_ATTRS.map((a) => ({ ...a, value: 10 }));
  return LEDGER_ATTRS.map((a) => ({ ...a, value: 10 }));
}

export const LEDGER_SKILLS = [
  { name: "Arquivo", attr: "reason" },
  { name: "Violência", attr: "body" },
  { name: "Persuasão", attr: "presence" },
  { name: "Observação", attr: "instinct" },
  { name: "Ocultismo", attr: "will" },
  { name: "Furtividade", attr: "instinct" },
  { name: "Medicina", attr: "reason" },
  { name: "Ofício", attr: "reason" },
  { name: "Atletismo", attr: "body" },
  { name: "Intuição", attr: "will" },
];

export const DND_SKILLS = [
  { name: "Acrobacia", attr: "dex" },
  { name: "Arcanismo", attr: "int" },
  { name: "Atletismo", attr: "str" },
  { name: "Atuação", attr: "cha" },
  { name: "Enganação", attr: "cha" },
  { name: "Furtividade", attr: "dex" },
  { name: "História", attr: "int" },
  { name: "Intimidação", attr: "cha" },
  { name: "Intuição", attr: "wis" },
  { name: "Investigação", attr: "int" },
  { name: "Lidar com Animais", attr: "wis" },
  { name: "Medicina", attr: "wis" },
  { name: "Natureza", attr: "int" },
  { name: "Percepção", attr: "wis" },
  { name: "Persuasão", attr: "cha" },
  { name: "Prestidigitação", attr: "dex" },
  { name: "Religião", attr: "int" },
  { name: "Sobrevivência", attr: "wis" },
];

export const CONDITIONS = [
  "Amedrontado",
  "Atordoado",
  "Caído",
  "Cego",
  "Concentrando",
  "Envenenado",
  "Exausto",
  "Agarrado",
  "Inconsciente",
  "Invisível",
  "Paralisado",
  "Petrificado",
  "Sangrando",
  "Surdo",
  "Imobilizado",
];

export const DICE_PRESETS = [4, 6, 8, 10, 12, 20, 100] as const;

export const SYSTEMS: { id: SystemId; name: string; note: string }[] = [
  {
    id: "ledger",
    name: "Protocolo Ledger",
    note: "Sistema nativo da Companhia — pecados, traumas e Fortuna.",
  },
  {
    id: "dnd5e",
    name: "D&D 5ª Edição",
    note: "Atributos clássicos. A Companhia tolera sistemas estrangeiros.",
  },
  {
    id: "generic",
    name: "Homebrew / Genérico",
    note: "Campos livres. O arquivo aceita o que você ousar escrever.",
  },
];

export const NAME_OPTIONS = [
  {
    name: "THE INFERNAL LEDGER",
    slogan: "Todo pecado é registrado. Toda dívida é cobrada.",
  },
  {
    name: "Companhia dos Esquecidos",
    slogan: "Processamos o que a Cidade preferiria enterrar.",
  },
  {
    name: "Protocolo Limbo",
    slogan: "Entre o julgamento e o esquecimento, há formulários.",
  },
  {
    name: "O Ramo Dourado",
    slogan: "Catalogar o amaldiçoado é ainda um ato de fé.",
  },
  {
    name: "Arquivo dos Pecadores",
    slogan: "Nenhum dossiê se fecha. Apenas se sela.",
  },
];
