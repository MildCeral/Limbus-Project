import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/shell/app-shell";

export const Route = createFileRoute("/_ledger")({
  component: LedgerLayout,
});

function LedgerLayout() {
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
