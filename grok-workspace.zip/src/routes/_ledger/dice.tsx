import { createFileRoute } from "@tanstack/react-router";
import { Eye, EyeOff, RotateCcw } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/shell/app-shell";
import { WaxSeal } from "@/components/ornament";
import { Badge, Button, Field, Input, NativeSelect } from "@/components/ui";
import { DICE_PRESETS } from "@/lib/ledger/constants";
import { parseFormula } from "@/lib/ledger/dice";
import { useLedgerStore, type Advantage } from "@/lib/ledger/store";
import { cn, formatStamp } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/dice")({
  component: DicePage,
});

function DicePage() {
  const rolls = useLedgerStore((s) => s.rolls);
  const characters = useLedgerStore((s) => s.characters);
  const designation = useLedgerStore((s) => s.designation);
  const recordRoll = useLedgerStore((s) => s.recordRoll);
  const clearRolls = useLedgerStore((s) => s.clearRolls);

  const [formula, setFormula] = useState("1d20");
  const [label, setLabel] = useState("");
  const [mod, setMod] = useState(0);
  const [secret, setSecret] = useState(false);
  const [adv, setAdv] = useState<Advantage>("normal");
  const [who, setWho] = useState("");
  const [spinning, setSpinning] = useState(false);
  const [face, setFace] = useState<number | null>(null);
  const lastId = useRef<string | null>(null);

  const latest = rolls[0];

  useEffect(() => {
    if (!latest || latest.id === lastId.current) return;
    lastId.current = latest.id;
  }, [latest]);

  function compose(): string {
    const parsed = parseFormula(formula);
    if (!parsed) return formula;
    const next = { ...parsed, modifier: parsed.modifier + mod };
    const base = `${next.count}d${next.sides}`;
    if (next.modifier === 0) return base;
    return next.modifier > 0 ? `${base}+${next.modifier}` : `${base}${next.modifier}`;
  }

  function invoke(raw?: string) {
    if (spinning) return;
    const input = raw ?? compose();
    if (!parseFormula(input.split("[")[0] ?? input)) {
      toast.error("O dado não reconhece essa liturgia. Use NdX+M.");
      return;
    }
    setSpinning(true);
    const sides = parseFormula(input)?.sides ?? 20;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      setFace(1 + Math.floor(Math.random() * sides));
      if (now - start < 720) {
        raf = requestAnimationFrame(tick);
      } else {
        const whoName = characters.find((c) => c.id === who)?.name;
        const roll = recordRoll(input, {
          label: label.trim() || (whoName ? `${whoName} · rolagem` : "Rolagem avulsa"),
          secret,
          characterId: who || undefined,
          advantage: adv,
        });
        setSpinning(false);
        if (roll) {
          setFace(roll.total);
          if (roll.secret) {
            toast.message("O carimbo secreto foi aplicado. Só o Gerente deveria ver.");
          } else if (roll.total === 1 && roll.sides === 20) {
            toast.error("Falha crítica. A Companhia anota. A Companhia não esquece.");
          } else if (roll.total >= 20 && roll.sides === 20 && roll.dice.includes(20)) {
            toast.success("Vinte. Até o arquivo hesita.");
          }
        }
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }

  return (
    <div>
      <PageHeader kicker="Tribunal de Fortuna" title="Mesa de dados">
        Os dados da Companhia não são justos. São apenas honestos — o que é pior.
      </PageHeader>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <section className="dossier p-5 sm:p-8">
          <div className="flex flex-col items-center">
            <div
              className={cn(
                "grid size-40 place-items-center border-2 border-gold/50 bg-void shadow-seal",
                spinning && "opacity-80",
              )}
            >
              {spinning ? (
                <WaxSeal letter="?" className="size-20" pulse />
              ) : face !== null ? (
                <p
                  key={latest?.id ?? "face"}
                  className="stamp-slam font-display text-6xl tabular-nums text-gold"
                >
                  {latest?.secret && designation.role !== "gerente" ? "—" : face}
                </p>
              ) : (
                <p className="font-display text-sm tracking-stamp text-faint">
                  AGUARDE O SELO
                </p>
              )}
            </div>
            {latest && !spinning ? (
              <p className="mt-4 text-center text-sm text-muted">
                {latest.formula} → [{latest.dice.join(", ")}]
                {latest.modifier ? ` ${latest.modifier > 0 ? "+" : ""}${latest.modifier}` : ""}
              </p>
            ) : null}
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-2">
            {DICE_PRESETS.map((n) => (
              <Button
                key={n}
                variant={formula === `1d${n}` ? "gold" : "ghost"}
                size="sm"
                onClick={() => {
                  setFormula(`1d${n}`);
                  setAdv("normal");
                }}
              >
                d{n}
              </Button>
            ))}
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <Field label="Fórmula">
              <Input
                value={formula}
                onChange={(e) => setFormula(e.target.value)}
                placeholder="2d6+3"
              />
            </Field>
            <Field label="Modificador extra">
              <Input
                type="number"
                value={mod}
                onChange={(e) => setMod(Number(e.target.value) || 0)}
              />
            </Field>
            <Field label="Rótulo / intenção">
              <Input
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Ataque, tesouro, mentira..."
              />
            </Field>
            <Field label="Pecador">
              <NativeSelect value={who} onChange={(e) => setWho(e.target.value)}>
                <option value="">— avulso —</option>
                {characters.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </NativeSelect>
            </Field>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {(["normal", "adv", "dis"] as const).map((a) => (
              <Button
                key={a}
                size="sm"
                variant={adv === a ? "gold" : "ghost"}
                onClick={() => setAdv(a)}
              >
                {a === "normal" ? "Normal" : a === "adv" ? "Vantagem" : "Desvantagem"}
              </Button>
            ))}
            <Button
              size="sm"
              variant={secret ? "danger" : "ghost"}
              onClick={() => setSecret((v) => !v)}
            >
              {secret ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              {secret ? "Olhos do Gerente" : "Rolagem aberta"}
            </Button>
          </div>

          <Button
            className="mt-6 w-full"
            size="lg"
            onClick={() => invoke()}
            disabled={spinning}
          >
            {spinning ? "O dado ainda gira..." : "Invocar o dado"}
          </Button>
        </section>

        <aside>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg text-gold">Carimbos</h2>
            <Button
              size="sm"
              variant="quiet"
              onClick={() => {
                clearRolls();
                toast.message("O histórico foi raspado. A memória, não.");
              }}
            >
              <RotateCcw className="size-3.5" />
              Raspar
            </Button>
          </div>
          <ul className="flex max-h-[32rem] flex-col gap-2 overflow-y-auto">
            {rolls.length === 0 ? (
              <p className="text-sm text-muted">
                Nenhuma rolagem. Fortuna ainda não foi insultada hoje.
              </p>
            ) : (
              rolls.map((r) => (
                <li key={r.id} className="border border-edge bg-paper px-3 py-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-ink">{r.label}</p>
                      <p className="text-2xs text-faint">
                        {formatStamp(r.at)} · {r.formula}
                      </p>
                    </div>
                    <p className="font-display text-xl tabular-nums text-gold">{r.total}</p>
                  </div>
                  {r.secret ? (
                    <Badge tone="blood" className="mt-1">
                      secreto
                    </Badge>
                  ) : null}
                </li>
              ))
            )}
          </ul>
        </aside>
      </div>
    </div>
  );
}
