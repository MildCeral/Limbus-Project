import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/shell/app-shell";
import { Badge, Button, Field, Input } from "@/components/ui";
import { APP_COMPANY, APP_NAME, APP_SLOGAN, NAME_OPTIONS } from "@/lib/ledger/constants";
import { useLedgerStore } from "@/lib/ledger/store";

export const Route = createFileRoute("/_ledger/protocol")({
  component: ProtocolPage,
});

const DESIGN_PROMPT = `Dark gothic tabletop RPG interface inspired by Limbus Company, official dystopian corporation documents, aged digital paper, blood-red wax seals, faded gold foil serif lettering, oxidized metal corners, torn ledger edges, subtle runes, deep blacks (#0c0908), blood red (#a32626), faded gold (#c4a46a), cold greys, cinematic lighting, character dossier UI mockup with stamps and classification bars, cinematic, literary horror, no cute cartoon, no bright neon --ar 16:9 --stylize 180`;

function ProtocolPage() {
  const designation = useLedgerStore((s) => s.designation);
  const seal = useLedgerStore((s) => s.sealDesignation);
  const exportJson = useLedgerStore((s) => s.exportJson);
  const importJson = useLedgerStore((s) => s.importJson);
  const resetDemo = useLedgerStore((s) => s.resetDemo);
  const fileRef = useRef<HTMLInputElement>(null);

  function download() {
    const blob = new Blob([exportJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "infernal-ledger.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("O arquivo foi extraído. Trate-o como confidencial.");
  }

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader kicker="Circular interna LEDGER-VII" title="Protocolo">
        Documento de identidade do produto. Destinado a Gerentes, pecadores e à posteridade
        que ainda souber ler.
      </PageHeader>

      <article className="dossier space-y-8 p-5 sm:p-8">
        <section className="relative z-10">
          <StampTitle n="01">Nome e slogan</StampTitle>
          <p className="font-display text-2xl text-gold">{APP_NAME}</p>
          <p className="text-sm text-muted">{APP_COMPANY}</p>
          <p className="mt-2 italic text-ink">{APP_SLOGAN}</p>
          <ul className="mt-4 space-y-2">
            {NAME_OPTIONS.map((n) => (
              <li key={n.name} className="border border-edge bg-void/40 px-3 py-2">
                <p className="font-display text-sm text-ink">{n.name}</p>
                <p className="text-xs text-muted">{n.slogan}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-faint">
            Adotado: a primeira opção. As demais permanecem como nomes de departamentos.
          </p>
        </section>

        <section className="relative z-10">
          <StampTitle n="02">Pitch</StampTitle>
          <p className="text-sm leading-relaxed text-muted">
            THE INFERNAL LEDGER é a mesa e o palco. Um aplicativo de RPG de mesa que se
            disfarça de sistema interno de uma companhia maldita: dossiês de pecadores,
            contratos selados a cera, dados que caem como carimbos, um teatro tático onde
            o mapa é um formulário e o combate, um processo. Serve ao iniciante que precisa
            de uma ficha que o ensine, e ao veterano que quer gerir uma campanha inteira
            sem sair da atmosfera. Offline por natureza. Compartilhável por arquivo. Feio
            de tão belo — como um cartório depois do incêndio.
          </p>
        </section>

        <section className="relative z-10">
          <StampTitle n="03">Funcionalidades</StampTitle>
          <h3 className="mt-3 font-display text-sm text-gold">MVP (nesta edição)</h3>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted">
            <li>Dossiês completos (atributos, perícias, talentos, magias, traumas, pecados, inventário, diário)</li>
            <li>Sistemas Ledger, D&D 5e e genérico/homebrew</li>
            <li>Rolagem d4–d100, vantagem, histórico carimbado, rolagens secretas</li>
            <li>Combate tático com grade quadrada ou hexagonal, tokens, iniciativa, condições</li>
            <li>Teatro da mente e modo mapa</li>
            <li>Campanha: NPCs, locais, sessões, linha do tempo, contratos</li>
            <li>Persistência local, exportação e importação do arquivo</li>
            <li>Instalável como PWA (Android, iOS, desktop)</li>
          </ul>
          <h3 className="mt-4 font-display text-sm text-gold">Futuro (anexos)</h3>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted">
            <li>Sincronização entre dispositivos com contas</li>
            <li>Mesa compartilhada em tempo real (voz + cursor do Gerente)</li>
            <li>Aplicativos nativos (Capacitor / React Native) sobre o mesmo núcleo</li>
            <li>Névoa de guerra, iluminação e mapas desenhados</li>
            <li>Compêndio pesquisável e importação de JSON de sistemas</li>
            <li>Assistente literário para ganchos e NPCs (opt-in)</li>
          </ul>
        </section>

        <section className="relative z-10">
          <StampTitle n="04">Estrutura de telas</StampTitle>
          <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm text-muted">
            <li>Portão — selar designação (Gerente / Pecador)</li>
            <li>Arquivo — painel da expedição</li>
            <li>Dossiês — estante e ficha-dossiê</li>
            <li>Dados — tribunal de Fortuna</li>
            <li>Teatro — mapa tático e relógio de turnos</li>
            <li>Campanha — NPCs, locais, sessões, tempo</li>
            <li>Contratos — obrigações e ganchos</li>
            <li>Protocolo — este documento, exportar, resetar</li>
          </ol>
        </section>

        <section className="relative z-10">
          <StampTitle n="05">Arquitetura</StampTitle>
          <p className="text-sm leading-relaxed text-muted">
            Núcleo web em React + TanStack Start, estado local com Zustand e persistência
            em localStorage (offline-first). A mesma base vira PWA instalável em Android e
            iOS. Expansão nativa: Capacitor envolve este webview; um futuro aplicativo
            nativo reutiliza o modelo de dados (JSON versionado). Sincronização: CRDT ou
            servidor de arquivos por mesa, nunca no caminho crítico da sessão. Combate e
            dados correm no cliente. Sem conta obrigatória nesta edição — o arquivo é o
            pecador.
          </p>
        </section>

        <section className="relative z-10">
          <StampTitle n="06">Prompt visual</StampTitle>
          <pre className="mt-2 overflow-x-auto border border-edge bg-void p-3 text-xs leading-relaxed text-muted whitespace-pre-wrap">
            {DESIGN_PROMPT}
          </pre>
          <Button
            variant="ghost"
            size="sm"
            className="mt-2"
            onClick={() => {
              void navigator.clipboard.writeText(DESIGN_PROMPT);
              toast.success("Prompt copiado. Que os geradores sofram com estilo.");
            }}
          >
            Copiar prompt
          </Button>
        </section>

        <section className="relative z-10">
          <StampTitle n="07">Microcopy</StampTitle>
          <dl className="mt-3 space-y-3 text-sm">
            <CopyRow k="Primário" v="Selar designação · Invocar o dado · Avançar o relógio · Protocolar obrigação" />
            <CopyRow k="Vazio" v="Nenhum pecador catalogado. A Companhia espera." />
            <CopyRow k="Erro" v="O arquivo recusou-se a abrir. Talvez não fosse para você lê-lo." />
            <CopyRow k="Crítico" v="Falha crítica. A Companhia anota. A Companhia não esquece." />
            <CopyRow k="Confirmação" v="Este ato não pode ser desfeito. A tinta já secou?" />
            <CopyRow k="Exportar" v="O arquivo foi extraído. Trate-o como confidencial." />
          </dl>
        </section>
      </article>

      <section className="mt-8 border border-edge bg-paper p-5">
        <h2 className="font-display text-lg text-gold">Custódia do arquivo</h2>
        <p className="mt-1 text-sm text-muted">
          Designação atual:{" "}
          <span className="text-ink">
            {designation.sealed
              ? `${designation.role === "gerente" ? "Gerente" : "Pecador"} ${designation.name}`
              : "não selada"}
          </span>
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field label="Reassinar o livro">
            <Input
              defaultValue={designation.name}
              onBlur={(e) => {
                const n = e.target.value.trim();
                if (n.length >= 2) seal(n, designation.role);
              }}
            />
          </Field>
          <div className="flex flex-col justify-end gap-2">
            <Button
              variant="ghost"
              onClick={() => seal(designation.name || "Anônimo", designation.role === "gerente" ? "pecador" : "gerente")}
            >
              Alternar Gerente / Pecador
            </Button>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button onClick={download}>Exportar arquivo</Button>
          <Button variant="ghost" onClick={() => fileRef.current?.click()}>
            Importar arquivo
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              resetDemo();
              toast.message("Os arquivos de demonstração foram restaurados. Suas anotações, não.");
            }}
          >
            Restaurar expedição-demo
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const text = await file.text();
              const res = importJson(text);
              if (res.ok) toast.success("Lacre reconhecido. O arquivo foi absorvido.");
              else toast.error(res.error);
              e.target.value = "";
            }}
          />
        </div>
        <p className="mt-4 text-xs text-faint">
          A Companhia não se responsabiliza por distorções resultantes da leitura.
        </p>
      </section>
    </div>
  );
}

function StampTitle({ n, children }: { n: string; children: string }) {
  return (
    <div className="mb-2 flex items-center gap-3">
      <Badge>{n}</Badge>
      <h2 className="font-display text-lg tracking-display text-ink">{children}</h2>
    </div>
  );
}

function CopyRow({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <dt className="font-display text-2xs uppercase tracking-stamp text-gold-dim">{k}</dt>
      <dd className="text-muted">{v}</dd>
    </div>
  );
}
