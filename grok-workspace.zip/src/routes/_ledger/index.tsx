import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Dices, Swords } from "lucide-react";
import { PageHeader } from "@/components/shell/app-shell";
import { Portrait, VitalBar } from "@/components/ornament";
import { Badge, buttonVariants } from "@/components/ui";
import { sinMeta } from "@/lib/ledger/constants";
import { useLedgerStore } from "@/lib/ledger/store";
import { cn, formatStamp } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/")({
  component: ArchiveHome,
});

const STATUS: Record<string, string> = {
  aberto: "Aberto",
  andamento: "Em curso",
  cumprido: "Cumprido",
  falhou: "Falhou",
  selado: "Selado",
};

function ArchiveHome() {
  const designation = useLedgerStore((s) => s.designation);
  const characters = useLedgerStore((s) => s.characters);
  const campaign = useLedgerStore((s) => s.campaign);
  const rolls = useLedgerStore((s) => s.rolls);
  const combat = useLedgerStore((s) => s.combat);

  const openContracts = campaign.contracts.filter(
    (c) => c.status === "aberto" || c.status === "andamento",
  );
  const greet =
    designation.role === "gerente"
      ? `Gerente ${designation.name || "sem nome"}`
      : `Pecador ${designation.name || "sem nome"}`;

  return (
    <div>
      <PageHeader kicker={campaign.code} title="Arquivo central">
        Bem-vindo de volta, {greet}. A expedição segue. A tinta ainda não secou.
      </PageHeader>

      <section className="enter enter-d1 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Pecadores" value={String(characters.length)} hint="dossiês abertos" />
        <Stat
          label="Contratos"
          value={String(openContracts.length)}
          hint="ainda não selados"
        />
        <Stat label="Sessões" value={String(campaign.sessions.length)} hint="no caderno" />
        <Stat label="Teatro" value={`R${combat.round}`} hint={combat.name} />
      </section>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <section className="enter enter-d2">
          <div className="mb-3 flex items-end justify-between">
            <h2 className="font-display text-lg tracking-display text-gold">
              Expedição ativa
            </h2>
            <Link
              to="/archive"
              className="text-xs uppercase tracking-wide text-muted hover:text-gold"
            >
              Abrir campanha
            </Link>
          </div>
          <article className="dossier p-5">
            <div className="relative z-10 flex items-start justify-between gap-3">
              <div>
                <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                  {campaign.code}
                </p>
                <h3 className="mt-1 font-display text-xl text-ink">{campaign.name}</h3>
              </div>
              <span className="stamp shrink-0">Em curso</span>
            </div>
            <p className="relative z-10 mt-4 text-sm leading-relaxed text-muted">
              {campaign.premise}
            </p>
            <div className="relative z-10 mt-5 flex flex-wrap gap-2">
              <Link to="/theatre" className={cn(buttonVariants())}>
                <Swords className="size-4" strokeWidth={1.5} />
                Entrar no teatro
              </Link>
              <Link to="/dice" className={cn(buttonVariants({ variant: "ghost" }))}>
                <Dices className="size-4" strokeWidth={1.5} />
                Invocar o dado
              </Link>
            </div>
          </article>

          <h2 className="mt-8 mb-3 font-display text-lg tracking-display text-gold">
            Pecadores catalogados
          </h2>
          <ul className="grid gap-3 sm:grid-cols-2">
            {characters.map((c) => {
              const sin = sinMeta(c.sin);
              return (
                <li key={c.id}>
                  <Link
                    to="/dossiers/$id"
                    params={{ id: c.id }}
                    className="flex gap-3 border border-edge bg-paper p-3 transition-colors hover:border-gold-dim"
                  >
                    <Portrait
                      src={c.portrait}
                      name={c.name}
                      sin={c.sin}
                      className="size-16 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-display text-sm text-ink">{c.name}</p>
                      <p className="truncate text-xs text-muted">{c.designation}</p>
                      <p
                        className="mt-1 text-2xs uppercase tracking-wide"
                        style={{ color: sin.hue }}
                      >
                        {sin.name} · rank {c.sinRank}
                      </p>
                      <div className="mt-2">
                        <VitalBar current={c.hp} max={c.hpMax} />
                      </div>
                    </div>
                    <ArrowUpRight className="size-4 shrink-0 text-faint" />
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>

        <aside className="enter enter-d3 flex flex-col gap-6">
          <div>
            <div className="mb-3 flex items-end justify-between">
              <h2 className="font-display text-lg tracking-display text-gold">Contratos</h2>
              <Link
                to="/contracts"
                className="text-xs uppercase tracking-wide text-muted hover:text-gold"
              >
                Ver todos
              </Link>
            </div>
            <ul className="flex flex-col gap-2">
              {openContracts.slice(0, 3).map((c) => (
                <li key={c.id} className="border border-edge bg-raised px-4 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-display text-2xs text-faint">{c.code}</p>
                    <Badge tone={c.status === "andamento" ? "blood" : "gold"}>
                      {STATUS[c.status]}
                    </Badge>
                  </div>
                  <p className="mt-1 text-sm text-ink">{c.title}</p>
                  <p className="mt-1 line-clamp-2 text-xs text-muted">{c.hook}</p>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="mb-3 flex items-end justify-between">
              <h2 className="font-display text-lg tracking-display text-gold">
                Últimas rolagens
              </h2>
              <Link
                to="/dice"
                className="text-xs uppercase tracking-wide text-muted hover:text-gold"
              >
                Mesa de dados
              </Link>
            </div>
            <ul className="flex flex-col gap-2">
              {rolls.slice(0, 5).map((r) => (
                <li
                  key={r.id}
                  className="flex items-center justify-between gap-3 border border-edge bg-raised px-3 py-2"
                >
                  <div className="min-w-0">
                    <p className="truncate text-xs text-ink">{r.label}</p>
                    <p className="text-2xs text-faint">
                      {r.secret ? "Olhos do Gerente · " : ""}
                      {formatStamp(r.at)}
                    </p>
                  </div>
                  <p className="font-display text-lg tabular-nums text-gold">{r.total}</p>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="border border-edge bg-paper px-4 py-4">
      <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
        {label}
      </p>
      <p className="mt-1 font-display text-2xl tabular-nums text-ink">{value}</p>
      <p className="text-xs text-faint">{hint}</p>
    </div>
  );
}
