import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/shell/app-shell";
import { Portrait, VitalBar } from "@/components/ornament";
import { Dialog, DialogContent } from "@/components/dialog";
import { Badge, Button, Field, Input, NativeSelect, Textarea } from "@/components/ui";
import { SINS, SYSTEMS, sinMeta } from "@/lib/ledger/constants";
import { makeBlankCharacter, useLedgerStore } from "@/lib/ledger/store";
import type { SinId, SystemId } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/dossiers/")({
  component: DossiersPage,
});

function DossiersPage() {
  const characters = useLedgerStore((s) => s.characters);
  const [open, setOpen] = useState(false);

  return (
    <div>
      <PageHeader
        kicker="Setor de pessoal"
        title="Dossiês"
        action={<Button onClick={() => setOpen(true)}>Abrir novo dossiê</Button>}
      >
        Cada pecador é um arquivo. Cada arquivo, uma dívida. Trate as margens com respeito.
      </PageHeader>

      <Dialog open={open} onOpenChange={setOpen}>
        <NewDossier onDone={() => setOpen(false)} />
      </Dialog>

      {characters.length === 0 ? (
        <p className="text-sm text-muted">
          Nenhum pecador catalogado. A Companhia espera.
        </p>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {characters.map((c) => {
            const sin = sinMeta(c.sin);
            return (
              <li key={c.id} className="enter">
                <Link
                  to="/dossiers/$id"
                  params={{ id: c.id }}
                  className="dossier block overflow-hidden"
                >
                  <Portrait
                    src={c.portrait}
                    name={c.name}
                    sin={c.sin}
                    className="h-48 w-full"
                  />
                  <div className="relative z-10 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                          {c.designation}
                        </p>
                        <h2 className="font-display text-xl text-ink">{c.name}</h2>
                      </div>
                      <Badge>{c.classification.split("/")[0]?.trim()}</Badge>
                    </div>
                    <p className="mt-1 text-sm italic text-muted">{c.epithet}</p>
                    <div className="mt-3 flex items-center justify-between text-xs">
                      <span style={{ color: sin.hue }}>
                        {sin.latin} · rank {c.sinRank}
                      </span>
                      <span className="tabular-nums text-faint">
                        PV {c.hp}/{c.hpMax}
                      </span>
                    </div>
                    <div className="mt-2">
                      <VitalBar current={c.hp} max={c.hpMax} />
                    </div>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function NewDossier({ onDone }: { onDone: () => void }) {
  const add = useLedgerStore((s) => s.addCharacter);
  const [system, setSystem] = useState<SystemId>("ledger");
  const [name, setName] = useState("");
  const [designation, setDesignation] = useState("Pecador nº ");
  const [epithet, setEpithet] = useState("");
  const [sin, setSin] = useState<SinId>("pride");
  const [notes, setNotes] = useState("");

  function submit() {
    if (name.trim().length < 2) {
      toast.error("Um dossiê sem nome é apenas papel. A Companhia recusa.");
      return;
    }
    const c = makeBlankCharacter(system);
    c.name = name.trim();
    c.designation = designation.trim() || "Pecador nº —";
    c.epithet = epithet.trim();
    c.sin = sin;
    c.notes = notes.trim();
    c.sins = [
      {
        id: `${c.id}-sin`,
        sin,
        rank: 1,
        desc: "O primeiro carimbo ainda está úmido.",
      },
    ];
    add(c);
    toast.success("Dossiê protocolado. Que o pecador mereça a tinta.");
    onDone();
  }

  return (
    <DialogContent title="Protocolar pecador" wide>
      <div className="flex flex-col gap-4">
        <Field label="Nome civil ou escolhido">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Helena Voss" />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Designação">
            <Input
              value={designation}
              onChange={(e) => setDesignation(e.target.value)}
            />
          </Field>
          <Field label="Epíteto">
            <Input
              value={epithet}
              onChange={(e) => setEpithet(e.target.value)}
              placeholder="A que leu demais"
            />
          </Field>
        </div>
        <Field label="Sistema de regras">
          <NativeSelect
            value={system}
            onChange={(e) => setSystem(e.target.value as SystemId)}
          >
            {SYSTEMS.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Pecado dominante">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {SINS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setSin(s.id)}
                className={cn(
                  "h-11 border text-xs",
                  sin === s.id ? "border-gold bg-paper text-gold" : "border-edge text-muted",
                )}
              >
                {s.name}
              </button>
            ))}
          </div>
        </Field>
        <Field label="Observação inicial">
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="O Gerente anota o que os pecadores omitem."
          />
        </Field>
        <Button onClick={submit} className="w-full">
          Selar dossiê
        </Button>
      </div>
    </DialogContent>
  );
}
