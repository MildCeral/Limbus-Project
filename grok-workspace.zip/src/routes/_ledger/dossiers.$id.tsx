import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Dices, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { FileRule, Portrait, VitalBar } from "@/components/ornament";
import { Badge, Button, Field, Input, Textarea } from "@/components/ui";
import { sinMeta } from "@/lib/ledger/constants";
import { skillCheckFormula } from "@/lib/ledger/dice";
import { useLedgerStore } from "@/lib/ledger/store";
import type { Character, Item, JournalEntry, Skill } from "@/lib/ledger/types";
import { clamp, fmtMod, formatStamp, modifier, uid } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/dossiers/$id")({
  component: DossierDetail,
});

const TABS = ["Identidade", "Corpo", "Arsenal", "Carga", "Diário"] as const;
type Tab = (typeof TABS)[number];

function DossierDetail() {
  const { id } = Route.useParams();
  const character = useLedgerStore((s) => s.characters.find((c) => c.id === id));
  const patch = useLedgerStore((s) => s.patchCharacter);
  const remove = useLedgerStore((s) => s.deleteCharacter);
  const addJournal = useLedgerStore((s) => s.addJournal);
  const recordRoll = useLedgerStore((s) => s.recordRoll);
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("Identidade");
  const [confirm, setConfirm] = useState(false);

  if (!character) {
    return (
      <div className="py-16 text-center">
        <p className="font-display text-xl text-gold">Dossiê extraviado</p>
        <p className="mt-2 text-sm text-muted">
          O arquivo não reconhece este número. Talvez nunca tenha existido.
        </p>
        <Link to="/dossiers" className="mt-6 inline-flex h-11 items-center text-gold">
          Voltar à estante
        </Link>
      </div>
    );
  }

  const sin = sinMeta(character.sin);

  function update(partial: Partial<Character>) {
    patch(character!.id, (c) => ({ ...c, ...partial }));
  }

  function rollSkill(sk: Skill) {
    const attr = character!.attributes.find((a) => a.id === sk.attr);
    const mod = (attr ? modifier(attr.value) : 0) + sk.value;
    const roll = recordRoll(skillCheckFormula(mod), {
      label: `${character!.name} · ${sk.name}`,
      characterId: character!.id,
    });
    if (roll) toast.success(`O dado caiu em ${roll.total}. A tinta registra.`);
  }

  function rollAttr(abbr: string, value: number) {
    const roll = recordRoll(skillCheckFormula(modifier(value)), {
      label: `${character!.name} · ${abbr}`,
      characterId: character!.id,
    });
    if (roll) toast.success(`${abbr}: ${roll.total}.`);
  }

  return (
    <div>
      <Link
        to="/dossiers"
        className="mb-4 inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-ink"
      >
        <ArrowLeft className="size-4" />
        Estante de dossiês
      </Link>

      <article className="dossier watermark overflow-hidden">
        <div className="relative z-10 grid gap-0 lg:grid-cols-[220px_minmax(0,1fr)]">
          <Portrait
            src={character.portrait}
            name={character.name}
            sin={character.sin}
            className="aspect-square w-full lg:min-h-full"
          />
          <div className="p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                  {character.designation} · {character.classification}
                </p>
                <h1 className="mt-1 font-display text-3xl tracking-display text-ink">
                  {character.name}
                </h1>
                <p className="mt-1 italic text-muted">{character.epithet}</p>
              </div>
              <span className="stamp">{sin.latin}</span>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <VitalEdit
                label="Pontos de vida"
                current={character.hp}
                max={character.hpMax}
                kind="hp"
                onChange={(hp, hpMax) => update({ hp, hpMax })}
              />
              <VitalEdit
                label="Sanidade / SP"
                current={character.sp}
                max={character.spMax}
                kind="sp"
                onChange={(sp, spMax) => update({ sp, spMax })}
              />
            </div>
            <p className="mt-3 text-xs uppercase tracking-wide" style={{ color: sin.hue }}>
              Pecado {sin.name} · nível {character.sinRank}
            </p>
          </div>
        </div>
      </article>

      <div className="mt-5 flex gap-1 overflow-x-auto border-b border-line">
        {TABS.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={
              tab === t
                ? "h-11 shrink-0 border-b-2 border-gold px-4 text-sm text-gold"
                : "h-11 shrink-0 px-4 text-sm text-muted hover:text-ink"
            }
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === "Identidade" ? (
          <IdentityForm character={character} onChange={update} />
        ) : null}
        {tab === "Corpo" ? (
          <BodyPanel
            character={character}
            onChange={update}
            onRollAttr={rollAttr}
            onRollSkill={rollSkill}
          />
        ) : null}
        {tab === "Arsenal" ? (
          <ArsenalPanel character={character} onChange={update} />
        ) : null}
        {tab === "Carga" ? (
          <InventoryPanel character={character} onChange={update} />
        ) : null}
        {tab === "Diário" ? (
          <JournalPanel
            character={character}
            onAdd={(e) => addJournal(character.id, e)}
          />
        ) : null}
      </div>

      <div className="mt-10 flex flex-wrap items-center gap-3 border-t border-line pt-6">
        <Link
          to="/dice"
          className="inline-flex h-11 items-center gap-2 border border-edge px-4 text-sm hover:border-gold-dim"
        >
          <Dices className="size-4" />
          Rolagens deste pecador
        </Link>
        {confirm ? (
          <>
            <Button
              variant="danger"
              onClick={() => {
                remove(character.id);
                toast.message("O dossiê foi reduzido a cinzas. A dívida permanece.");
                void navigate({ to: "/dossiers" });
              }}
            >
              Confirmar incineração
            </Button>
            <Button variant="quiet" onClick={() => setConfirm(false)}>
              A tinta ainda pode secar
            </Button>
          </>
        ) : (
          <Button variant="ghost" onClick={() => setConfirm(true)}>
            <Trash2 className="size-4" />
            Incinerar dossiê
          </Button>
        )}
      </div>
    </div>
  );
}

function VitalEdit({
  label,
  current,
  max,
  kind,
  onChange,
}: {
  label: string;
  current: number;
  max: number;
  kind: "hp" | "sp";
  onChange: (current: number, max: number) => void;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="text-muted">{label}</span>
        <span className="tabular-nums text-ink">
          {current}/{max}
        </span>
      </div>
      <VitalBar current={current} max={max} kind={kind} />
      <div className="mt-2 flex gap-2">
        <Button
          size="sm"
          variant="ghost"
          onClick={() => onChange(clamp(current - 1, 0, max), max)}
        >
          −1
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => onChange(clamp(current + 1, 0, max), max)}
        >
          +1
        </Button>
        <Input
          className="h-9 w-20"
          type="number"
          value={max}
          onChange={(e) => {
            const n = Number(e.target.value) || 0;
            onChange(clamp(current, 0, n), n);
          }}
          aria-label={`${label} máximo`}
        />
      </div>
    </div>
  );
}

function IdentityForm({
  character,
  onChange,
}: {
  character: Character;
  onChange: (p: Partial<Character>) => void;
}) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Field label="Nome">
        <Input value={character.name} onChange={(e) => onChange({ name: e.target.value })} />
      </Field>
      <Field label="Designação">
        <Input
          value={character.designation}
          onChange={(e) => onChange({ designation: e.target.value })}
        />
      </Field>
      <Field label="Epíteto">
        <Input
          value={character.epithet}
          onChange={(e) => onChange({ epithet: e.target.value })}
        />
      </Field>
      <Field label="Classificação">
        <Input
          value={character.classification}
          onChange={(e) => onChange({ classification: e.target.value })}
        />
      </Field>
      <Field label="Nível de pecado" className="lg:col-span-2">
        <Input
          type="number"
          min={1}
          max={7}
          value={character.sinRank}
          onChange={(e) =>
            onChange({ sinRank: clamp(Number(e.target.value) || 1, 1, 7) })
          }
        />
      </Field>
      <Field label="Notas do Gerente" className="lg:col-span-2">
        <Textarea
          value={character.notes}
          onChange={(e) => onChange({ notes: e.target.value })}
        />
      </Field>
      <div className="lg:col-span-2">
        <FileRule label="traumas" />
        <ul className="mt-3 flex flex-col gap-3">
          {character.traumas.map((t) => (
            <li key={t.id} className="border border-edge bg-paper px-4 py-3">
              <p className="font-display text-sm text-gold">{t.name}</p>
              <p className="mt-1 text-sm text-muted">{t.desc}</p>
            </li>
          ))}
        </ul>
        <ul className="mt-4 flex flex-col gap-3">
          {character.sins.map((s) => (
            <li key={s.id} className="border border-blood/40 bg-blood-dim/20 px-4 py-3">
              <p className="font-display text-sm text-blood">
                {sinMeta(s.sin).name} · rank {s.rank}
              </p>
              <p className="mt-1 text-sm text-muted">{s.desc}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function BodyPanel({
  character,
  onChange,
  onRollAttr,
  onRollSkill,
}: {
  character: Character;
  onChange: (p: Partial<Character>) => void;
  onRollAttr: (abbr: string, value: number) => void;
  onRollSkill: (sk: Skill) => void;
}) {
  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div>
        <h2 className="font-display text-lg text-gold">Atributos</h2>
        <ul className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {character.attributes.map((a) => (
            <li key={a.id} className="border border-edge bg-paper p-3 text-center">
              <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                {a.abbr}
              </p>
              <p className="font-display text-2xl tabular-nums">{a.value}</p>
              <p className="text-xs text-muted">{fmtMod(a.value)}</p>
              <p className="mt-1 text-xs text-faint">{a.name}</p>
              <div className="mt-2 flex justify-center gap-1">
                <Button
                  size="sm"
                  variant="quiet"
                  onClick={() =>
                    onChange({
                      attributes: character.attributes.map((x) =>
                        x.id === a.id
                          ? { ...x, value: clamp(x.value - 1, 1, 20) }
                          : x,
                      ),
                    })
                  }
                >
                  −
                </Button>
                <Button size="sm" variant="ghost" onClick={() => onRollAttr(a.abbr, a.value)}>
                  d20
                </Button>
                <Button
                  size="sm"
                  variant="quiet"
                  onClick={() =>
                    onChange({
                      attributes: character.attributes.map((x) =>
                        x.id === a.id
                          ? { ...x, value: clamp(x.value + 1, 1, 20) }
                          : x,
                      ),
                    })
                  }
                >
                  +
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h2 className="font-display text-lg text-gold">Perícias</h2>
        <ul className="mt-3 flex flex-col gap-1">
          {character.skills.map((sk) => {
            const attr = character.attributes.find((a) => a.id === sk.attr);
            const total = (attr ? modifier(attr.value) : 0) + sk.value;
            return (
              <li
                key={sk.id}
                className="flex items-center gap-2 border border-edge bg-raised px-3 py-2"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-ink">{sk.name}</p>
                  <p className="text-2xs text-faint">
                    {attr?.abbr ?? sk.attr} {fmtMod(attr?.value ?? 10)} + {sk.value}
                  </p>
                </div>
                <span className="font-display tabular-nums text-gold">
                  {total >= 0 ? `+${total}` : total}
                </span>
                <Button size="sm" variant="ghost" onClick={() => onRollSkill(sk)}>
                  Rolar
                </Button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

function ArsenalPanel({
  character,
  onChange,
}: {
  character: Character;
  onChange: (p: Partial<Character>) => void;
}) {
  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <ListBlock
        title="Talentos"
        empty="Nenhum talento protocolado. A mediocridade também é um destino."
        items={character.talents.map((t) => ({ id: t.id, title: t.name, body: t.desc }))}
      />
      <ListBlock
        title="Fórmulas / Magias"
        empty="Este pecador não recita. Ainda."
        items={character.spells.map((t) => ({
          id: t.id,
          title: `${t.name} · círculo ${t.circle}`,
          body: t.desc,
        }))}
      />
      <AddLine
        label="Novo talento"
        onAdd={(title, body) =>
          onChange({
            talents: [...character.talents, { id: uid("t"), name: title, desc: body }],
          })
        }
      />
      <AddLine
        label="Nova fórmula"
        onAdd={(title, body) =>
          onChange({
            spells: [
              ...character.spells,
              { id: uid("sp"), name: title, circle: 1, desc: body },
            ],
          })
        }
      />
    </div>
  );
}

function InventoryPanel({
  character,
  onChange,
}: {
  character: Character;
  onChange: (p: Partial<Character>) => void;
}) {
  const [name, setName] = useState("");
  return (
    <div>
      <ul className="flex flex-col gap-2">
        {character.inventory.map((it) => (
          <li
            key={it.id}
            className="flex flex-wrap items-center gap-3 border border-edge bg-paper px-4 py-3"
          >
            <div className="min-w-0 flex-1">
              <p className="text-sm text-ink">
                {it.name}{" "}
                {it.equipped ? <Badge className="ml-2">equipado</Badge> : null}
              </p>
              {it.notes ? <p className="text-xs text-muted">{it.notes}</p> : null}
            </div>
            <span className="tabular-nums text-sm text-gold">×{it.qty}</span>
            <Button
              size="sm"
              variant="quiet"
              onClick={() =>
                onChange({
                  inventory: character.inventory.map((x) =>
                    x.id === it.id ? { ...x, equipped: !x.equipped } : x,
                  ),
                })
              }
            >
              {it.equipped ? "Guardar" : "Equipar"}
            </Button>
            <Button
              size="sm"
              variant="quiet"
              onClick={() =>
                onChange({
                  inventory: character.inventory.filter((x) => x.id !== it.id),
                })
              }
            >
              Descartar
            </Button>
          </li>
        ))}
      </ul>
      <form
        className="mt-4 flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim()) return;
          const item: Item = { id: uid("i"), name: name.trim(), qty: 1 };
          onChange({ inventory: [...character.inventory, item] });
          setName("");
        }}
      >
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nome do item a protocolar"
        />
        <Button type="submit">Registrar carga</Button>
      </form>
    </div>
  );
}

function JournalPanel({
  character,
  onAdd,
}: {
  character: Character;
  onAdd: (e: Omit<JournalEntry, "id">) => void;
}) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const sorted = useMemo(
    () => [...character.journal].sort((a, b) => b.at - a.at),
    [character.journal],
  );

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <form
        className="flex flex-col gap-3 border border-edge bg-paper p-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!title.trim() || !body.trim()) {
            toast.error("O diário recusa páginas em branco. Escreva, ou cale-se.");
            return;
          }
          onAdd({ title: title.trim(), body: body.trim(), at: Date.now(), sin: character.sin });
          setTitle("");
          setBody("");
          toast.success("Entrada selada. Ninguém promete que permanecerá secreta.");
        }}
      >
        <h2 className="font-display text-lg text-gold">Nova entrada</h2>
        <Field label="Título">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Corpo">
          <Textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            className="min-h-36"
            placeholder="Escreva como se o Gerente fosse ler — porque ele lerá."
          />
        </Field>
        <Button type="submit">Selar página</Button>
      </form>
      <ul className="flex flex-col gap-4">
        {sorted.length === 0 ? (
          <p className="text-sm text-muted">
            O diário deste pecador ainda é um silêncio bem encadernado.
          </p>
        ) : (
          sorted.map((j) => (
            <li key={j.id} className="border-l-2 border-gold/40 bg-raised px-4 py-3">
              <p className="font-display text-sm text-gold">{j.title}</p>
              <p className="text-2xs text-faint">{formatStamp(j.at)}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{j.body}</p>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}

function ListBlock({
  title,
  empty,
  items,
}: {
  title: string;
  empty: string;
  items: { id: string; title: string; body: string }[];
}) {
  return (
    <div>
      <h2 className="font-display text-lg text-gold">{title}</h2>
      {items.length === 0 ? (
        <p className="mt-3 text-sm text-muted">{empty}</p>
      ) : (
        <ul className="mt-3 flex flex-col gap-2">
          {items.map((it) => (
            <li key={it.id} className="border border-edge bg-paper px-4 py-3">
              <p className="font-display text-sm text-ink">{it.title}</p>
              <p className="mt-1 text-sm text-muted">{it.body}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function AddLine({
  label,
  onAdd,
}: {
  label: string;
  onAdd: (title: string, body: string) => void;
}) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  return (
    <form
      className="flex flex-col gap-2 border border-dashed border-edge p-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim()) return;
        onAdd(title.trim(), body.trim());
        setTitle("");
        setBody("");
      }}
    >
      <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">{label}</p>
      <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Nome" />
      <Input value={body} onChange={(e) => setBody(e.target.value)} placeholder="Cláusula" />
      <Button type="submit" variant="ghost" size="sm">
        Anexar ao dossiê
      </Button>
    </form>
  );
}
