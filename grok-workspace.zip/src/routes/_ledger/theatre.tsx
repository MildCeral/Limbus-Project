import { createFileRoute } from "@tanstack/react-router";
import { Plus, RotateCcw } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/shell/app-shell";
import { MapBoard } from "@/components/theatre/map-board";
import { Portrait, VitalBar } from "@/components/ornament";
import { Badge, Button, Field, Input, NativeSelect } from "@/components/ui";
import { CONDITIONS } from "@/lib/ledger/constants";
import { ENEMY_PORTRAITS } from "@/lib/ledger/seed";
import { combatOrder, currentActor, useLedgerStore } from "@/lib/ledger/store";
import type { Token, TokenKind } from "@/lib/ledger/types";
import { clamp, cn, formatStamp } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/theatre")({
  component: TheatrePage,
});

function TheatrePage() {
  const combat = useLedgerStore((s) => s.combat);
  const nextTurn = useLedgerStore((s) => s.nextTurn);
  const setGrid = useLedgerStore((s) => s.setGrid);
  const setTheatre = useLedgerStore((s) => s.setTheatre);
  const selectToken = useLedgerStore((s) => s.selectToken);
  const updateToken = useLedgerStore((s) => s.updateToken);
  const addToken = useLedgerStore((s) => s.addToken);
  const removeToken = useLedgerStore((s) => s.removeToken);
  const resetCombat = useLedgerStore((s) => s.resetCombat);
  const addCombatLog = useLedgerStore((s) => s.addCombatLog);

  const order = combatOrder(combat);
  const actor = currentActor(combat);
  const selected = combat.tokens.find((t) => t.id === combat.selectedId) ?? null;
  const [name, setName] = useState("Escriba");
  const [kind, setKind] = useState<TokenKind>("enemy");

  return (
    <div>
      <PageHeader
        kicker="Setor de conflito"
        title="Teatro"
        action={
          <Button
            variant="ghost"
            onClick={() => {
              resetCombat();
              toast.message("O palco foi rearmado. Os mortos voltaram ao índice.");
            }}
          >
            <RotateCcw className="size-4" />
            Rearmar encontro
          </Button>
        }
      >
        {combat.name}. Arraste os tokens ou toque uma casa com alguém selecionado para deslocar.
      </PageHeader>

      <div className="mb-4 flex flex-wrap gap-2">
        <Button
          size="sm"
          variant={combat.theatre ? "ghost" : "gold"}
          onClick={() => setTheatre(false)}
        >
          Mapa tático
        </Button>
        <Button
          size="sm"
          variant={combat.theatre ? "gold" : "ghost"}
          onClick={() => setTheatre(true)}
        >
          Teatro da mente
        </Button>
        <Button
          size="sm"
          variant={combat.grid === "square" ? "paper" : "ghost"}
          onClick={() => setGrid("square")}
        >
          Grade quadrada
        </Button>
        <Button
          size="sm"
          variant={combat.grid === "hex" ? "paper" : "ghost"}
          onClick={() => setGrid("hex")}
        >
          Grade hexagonal
        </Button>
        <Button
          size="sm"
          onClick={() => {
            nextTurn();
            toast.message("O relógio avança. Alguém ainda respira.");
          }}
        >
          Avançar o relógio
        </Button>
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_19rem]">
        <div>
          {combat.theatre ? (
            <ul className="grid gap-3 sm:grid-cols-2">
              {combat.tokens.map((t) => (
                <li key={t.id}>
                  <button
                    type="button"
                    onClick={() => selectToken(t.id)}
                    className={cn(
                      "flex w-full gap-3 border bg-paper p-3 text-left",
                      selected?.id === t.id ? "border-gold" : "border-edge",
                      actor?.id === t.id && "ring-1 ring-blood",
                    )}
                  >
                    <TokenFace token={t} />
                    <div className="min-w-0 flex-1">
                      <p className="font-display text-sm text-ink">{t.name}</p>
                      <p className="text-2xs uppercase tracking-wide text-faint">{t.kind}</p>
                      <div className="mt-2">
                        <VitalBar current={t.hp} max={t.hpMax} />
                      </div>
                      <p className="mt-1 tabular-nums text-xs text-muted">
                        PV {t.hp}/{t.hpMax} · init {t.initiative}
                      </p>
                      {t.conditions.length > 0 ? (
                        <p className="mt-1 text-2xs text-blood">{t.conditions.join(" · ")}</p>
                      ) : null}
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <MapBoard />
          )}
        </div>

        <aside className="flex flex-col gap-5">
          <div className="border border-edge bg-paper p-4">
            <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
              Relógio · rodada {combat.round}
            </p>
            <p className="mt-1 font-display text-lg text-ink">
              {actor ? `Turno de ${actor.name}` : "Ninguém no palco"}
            </p>
            <ol className="mt-3 flex flex-col gap-1">
              {order.map((t, i) => (
                <li key={t.id}>
                  <button
                    type="button"
                    onClick={() => selectToken(t.id)}
                    className={cn(
                      "flex h-10 w-full items-center justify-between px-2 text-sm",
                      t.id === actor?.id ? "bg-blood/30 text-ink" : "text-muted hover:bg-raised",
                    )}
                  >
                    <span>
                      {i + 1}. {t.name}
                    </span>
                    <span className="tabular-nums text-gold">{t.initiative}</span>
                  </button>
                </li>
              ))}
            </ol>
          </div>

          {selected ? (
            <TokenEditor
              token={selected}
              onChange={(patch) => updateToken(selected.id, patch)}
              onRemove={() => {
                removeToken(selected.id);
                toast.message("Removido do palco. O índice permanece.");
              }}
              onLog={(text) => addCombatLog(text)}
            />
          ) : (
            <p className="text-sm text-muted">
              Selecione um token. Os mortos e os vivos ocupam o mesmo formulário.
            </p>
          )}

          <form
            className="border border-dashed border-edge p-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!name.trim()) return;
              addToken({
                name: name.trim(),
                kind,
                x: 6,
                y: 4,
                hp: kind === "enemy" ? 16 : 20,
                hpMax: kind === "enemy" ? 16 : 20,
                conditions: [],
                initiative: 8 + Math.floor(Math.random() * 8),
                notes: "",
              });
              toast.success("Uma nova figura entrou em cena. O público não aplaude.");
            }}
          >
            <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
              Convocar figura
            </p>
            <div className="mt-2 flex flex-col gap-2">
              <Input value={name} onChange={(e) => setName(e.target.value)} />
              <NativeSelect
                value={kind}
                onChange={(e) => setKind(e.target.value as TokenKind)}
              >
                <option value="enemy">Inimigo</option>
                <option value="ally">Aliado</option>
                <option value="sinner">Pecador</option>
                <option value="hazard">Perigo</option>
              </NativeSelect>
              <Button type="submit" variant="ghost" size="sm">
                <Plus className="size-4" />
                Protocolar no mapa
              </Button>
            </div>
          </form>

          <div>
            <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
              Ata de combate
            </p>
            <ul className="mt-2 max-h-48 overflow-y-auto text-xs text-muted">
              {combat.log.map((l) => (
                <li key={l.id} className="border-t border-line py-2">
                  <span className="text-faint">{formatStamp(l.at)} · </span>
                  {l.text}
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}

function TokenFace({ token }: { token: Token }) {
  const characters = useLedgerStore((s) => s.characters);
  const src =
    (token.characterId &&
      characters.find((c) => c.id === token.characterId)?.portrait) ||
    ENEMY_PORTRAITS[token.id];
  return (
    <Portrait
      src={src}
      name={token.name}
      sin={token.sin ?? "gloom"}
      className="size-14 shrink-0"
    />
  );
}

function TokenEditor({
  token,
  onChange,
  onRemove,
  onLog,
}: {
  token: Token;
  onChange: (p: Partial<Token>) => void;
  onRemove: () => void;
  onLog: (text: string) => void;
}) {
  return (
    <div className="border border-edge bg-paper p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-display text-lg text-ink">{token.name}</p>
          <Badge tone={token.kind === "enemy" ? "blood" : "gold"}>{token.kind}</Badge>
        </div>
        <p className="font-display text-2xs text-faint">
          {String.fromCharCode(65 + token.x)}
          {token.y + 1}
        </p>
      </div>
      <div className="mt-3">
        <VitalBar current={token.hp} max={token.hpMax} />
        <div className="mt-2 flex gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              const hp = clamp(token.hp - 1, 0, token.hpMax);
              onChange({ hp });
              onLog(`${token.name} sofre 1. PV ${hp}.`);
            }}
          >
            −1 PV
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onChange({ hp: clamp(token.hp + 1, 0, token.hpMax) })}
          >
            +1 PV
          </Button>
          <Field label="Iniciativa" className="flex-1">
            <Input
              className="h-9"
              type="number"
              value={token.initiative}
              onChange={(e) => onChange({ initiative: Number(e.target.value) || 0 })}
            />
          </Field>
        </div>
      </div>
      <p className="mt-3 font-display text-2xs uppercase tracking-stamp text-gold-dim">
        Condições
      </p>
      <div className="mt-2 flex flex-wrap gap-1">
        {CONDITIONS.map((c) => {
          const on = token.conditions.includes(c);
          return (
            <button
              key={c}
              type="button"
              onClick={() =>
                onChange({
                  conditions: on
                    ? token.conditions.filter((x) => x !== c)
                    : [...token.conditions, c],
                })
              }
              className={cn(
                "h-8 border px-2 text-2xs",
                on ? "border-blood bg-blood/30 text-ink" : "border-edge text-muted",
              )}
            >
              {c}
            </button>
          );
        })}
      </div>
      <Field label="Notas de cena" className="mt-3">
        <Input
          value={token.notes}
          onChange={(e) => onChange({ notes: e.target.value })}
        />
      </Field>
      <Button variant="danger" size="sm" className="mt-3 w-full" onClick={onRemove}>
        Retirar de cena
      </Button>
    </div>
  );
}
