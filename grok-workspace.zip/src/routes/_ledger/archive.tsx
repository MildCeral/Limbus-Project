import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/shell/app-shell";
import { Badge, Button, Field, Input, Textarea } from "@/components/ui";
import { useLedgerStore } from "@/lib/ledger/store";
import type { Npc, Place, SessionLog, TimelineEvent } from "@/lib/ledger/types";
import { uid } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/archive")({
  component: ArchivePage,
});

const TABS = ["Visão", "NPCs", "Locais", "Sessões", "Linha do tempo"] as const;
type Tab = (typeof TABS)[number];

function ArchivePage() {
  const campaign = useLedgerStore((s) => s.campaign);
  const updateCampaign = useLedgerStore((s) => s.updateCampaign);
  const addNpc = useLedgerStore((s) => s.addNpc);
  const deleteNpc = useLedgerStore((s) => s.deleteNpc);
  const addPlace = useLedgerStore((s) => s.addPlace);
  const deletePlace = useLedgerStore((s) => s.deletePlace);
  const addSession = useLedgerStore((s) => s.addSession);
  const deleteSession = useLedgerStore((s) => s.deleteSession);
  const addEvent = useLedgerStore((s) => s.addEvent);
  const deleteEvent = useLedgerStore((s) => s.deleteEvent);
  const [tab, setTab] = useState<Tab>("Visão");

  return (
    <div>
      <PageHeader kicker={campaign.code} title={campaign.name}>
        Relatórios internos. O que não estiver escrito aqui não aconteceu — oficialmente.
      </PageHeader>

      <div className="flex gap-1 overflow-x-auto border-b border-line">
        {TABS.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={
              tab === t
                ? "h-11 shrink-0 border-b-2 border-gold px-4 text-sm text-gold"
                : "h-11 shrink-0 px-4 text-sm text-muted hover:text-ink"
            }
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === "Visão" ? (
          <div className="grid gap-4">
            <Field label="Nome da expedição">
              <Input
                value={campaign.name}
                onChange={(e) => updateCampaign({ name: e.target.value })}
              />
            </Field>
            <Field label="Código de arquivo">
              <Input
                value={campaign.code}
                onChange={(e) => updateCampaign({ code: e.target.value })}
              />
            </Field>
            <Field label="Premissa">
              <Textarea
                className="min-h-32"
                value={campaign.premise}
                onChange={(e) => updateCampaign({ premise: e.target.value })}
              />
            </Field>
            <Field label="Notas do Gerente">
              <Textarea
                className="min-h-32"
                value={campaign.notes}
                onChange={(e) => updateCampaign({ notes: e.target.value })}
              />
            </Field>
          </div>
        ) : null}

        {tab === "NPCs" ? (
          <div className="grid gap-4 lg:grid-cols-2">
            {campaign.npcs.map((n) => (
              <article key={n.id} className="border border-edge bg-paper p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h2 className="font-display text-lg text-ink">{n.name}</h2>
                    <p className="text-xs uppercase tracking-wide text-gold">{n.role}</p>
                  </div>
                  <Button size="sm" variant="quiet" onClick={() => deleteNpc(n.id)}>
                    Arquivar
                  </Button>
                </div>
                <p className="mt-2 text-sm text-muted">{n.attitude}</p>
                <p className="mt-3 text-xs uppercase tracking-wide text-blood">Segredo</p>
                <p className="text-sm text-ink">{n.secrets}</p>
                <p className="mt-2 text-sm italic text-faint">{n.notes}</p>
              </article>
            ))}
            <QuickPerson onCreate={addNpc} />
          </div>
        ) : null}

        {tab === "Locais" ? (
          <div className="grid gap-4 lg:grid-cols-2">
            {campaign.places.map((p) => (
              <article key={p.id} className="border border-edge bg-paper p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h2 className="font-display text-lg text-ink">{p.name}</h2>
                    <p className="text-xs text-gold">{p.kind}</p>
                  </div>
                  <Badge tone={p.danger >= 4 ? "blood" : "gold"}>perigo {p.danger}</Badge>
                </div>
                <p className="mt-3 text-sm text-muted">{p.desc}</p>
                <Button
                  size="sm"
                  variant="quiet"
                  className="mt-3"
                  onClick={() => deletePlace(p.id)}
                >
                  Riscar do mapa
                </Button>
              </article>
            ))}
            <QuickPlace onCreate={addPlace} />
          </div>
        ) : null}

        {tab === "Sessões" ? (
          <div className="flex flex-col gap-4">
            {campaign.sessions
              .slice()
              .sort((a, b) => b.number - a.number)
              .map((s) => (
                <article key={s.id} className="border border-edge bg-paper p-4">
                  <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                    Sessão {s.number} · {s.date}
                  </p>
                  <h2 className="font-display text-xl text-ink">{s.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{s.summary}</p>
                  {s.notes ? (
                    <p className="mt-2 text-sm italic text-faint">{s.notes}</p>
                  ) : null}
                  <Button
                    size="sm"
                    variant="quiet"
                    className="mt-3"
                    onClick={() => deleteSession(s.id)}
                  >
                    Expurgar ata
                  </Button>
                </article>
              ))}
            <QuickSession
              nextNumber={
                campaign.sessions.reduce((m, s) => Math.max(m, s.number), 0) + 1
              }
              onCreate={addSession}
            />
          </div>
        ) : null}

        {tab === "Linha do tempo" ? (
          <ol className="relative border-l border-gold/30 pl-5">
            {campaign.timeline.map((e) => (
              <li key={e.id} className="mb-6">
                <span className="absolute -left-1.5 mt-1.5 size-3 rounded-full bg-gold" />
                <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                  {e.at}
                  {e.secret ? " · olhos do gerente" : ""}
                </p>
                <h2 className="font-display text-lg text-ink">{e.title}</h2>
                <p className="mt-1 text-sm text-muted">{e.body}</p>
                <Button size="sm" variant="quiet" onClick={() => deleteEvent(e.id)}>
                  Apagar evento
                </Button>
              </li>
            ))}
            <QuickEvent onCreate={addEvent} />
          </ol>
        ) : null}
      </div>
    </div>
  );
}

function QuickPerson({ onCreate }: { onCreate: (n: Npc) => void }) {
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  return (
    <form
      className="border border-dashed border-edge p-4"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) return;
        onCreate({
          id: uid("npc"),
          name: name.trim(),
          role: role.trim() || "Testemunha",
          attitude: "Indefinida.",
          secrets: "Ainda não catalogado.",
          notes: "",
        });
        setName("");
        setRole("");
        toast.success("Um nome a mais no índice. Que se arrependa.");
      }}
    >
      <p className="font-display text-sm text-gold">Protocolar NPC</p>
      <div className="mt-3 flex flex-col gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" />
        <Input value={role} onChange={(e) => setRole(e.target.value)} placeholder="Função" />
        <Button type="submit" variant="ghost">
          Registrar
        </Button>
      </div>
    </form>
  );
}

function QuickPlace({ onCreate }: { onCreate: (p: Place) => void }) {
  const [name, setName] = useState("");
  return (
    <form
      className="border border-dashed border-edge p-4"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) return;
        onCreate({
          id: uid("loc"),
          name: name.trim(),
          kind: "Local",
          desc: "Ainda sem perícia formal.",
          danger: 2,
        });
        setName("");
        toast.success("O mapa engordou. Os atalhos, não.");
      }}
    >
      <p className="font-display text-sm text-gold">Protocolar local</p>
      <div className="mt-3 flex flex-col gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome do lugar" />
        <Button type="submit" variant="ghost">
          Registrar
        </Button>
      </div>
    </form>
  );
}

function QuickSession({
  nextNumber,
  onCreate,
}: {
  nextNumber: number;
  onCreate: (s: SessionLog) => void;
}) {
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  return (
    <form
      className="border border-dashed border-edge p-4"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim()) return;
        onCreate({
          id: uid("ses"),
          number: nextNumber,
          title: title.trim(),
          date: new Date().toLocaleDateString("pt-BR"),
          summary: summary.trim() || "Ata ainda em branco.",
          notes: "",
        });
        setTitle("");
        setSummary("");
        toast.success("Sessão protocolada. O que aconteceu agora é oficial.");
      }}
    >
      <p className="font-display text-sm text-gold">Nova ata · sessão {nextNumber}</p>
      <div className="mt-3 flex flex-col gap-2">
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Título" />
        <Textarea
          value={summary}
          onChange={(e) => setSummary(e.target.value)}
          placeholder="O que o arquivo deve lembrar"
        />
        <Button type="submit" variant="ghost">
          Selar ata
        </Button>
      </div>
    </form>
  );
}

function QuickEvent({ onCreate }: { onCreate: (e: TimelineEvent) => void }) {
  const [title, setTitle] = useState("");
  const [at, setAt] = useState("");
  return (
    <form
      className="border border-dashed border-edge p-4"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim()) return;
        onCreate({
          id: uid("tl"),
          at: at.trim() || "Data incerta",
          title: title.trim(),
          body: "Evento acrescentado à margem do tempo.",
        });
        setTitle("");
        setAt("");
      }}
    >
      <p className="font-display text-sm text-gold">Acrescentar ao tempo</p>
      <div className="mt-3 flex flex-col gap-2">
        <Input value={at} onChange={(e) => setAt(e.target.value)} placeholder="Quando" />
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="O quê" />
        <Button type="submit" variant="ghost">
          Registrar
        </Button>
      </div>
    </form>
  );
}
