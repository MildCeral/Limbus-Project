import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/shell/app-shell";
import { Badge, Button, Field, Input, NativeSelect, Textarea } from "@/components/ui";
import { useLedgerStore } from "@/lib/ledger/store";
import type { Contract, ContractStatus } from "@/lib/ledger/types";
import { cn, uid } from "@/lib/utils";

export const Route = createFileRoute("/_ledger/contracts")({
  component: ContractsPage,
});

const STATUS: Record<ContractStatus, string> = {
  aberto: "Aberto",
  andamento: "Em curso",
  cumprido: "Cumprido",
  falhou: "Falhou",
  selado: "Selado",
};

function ContractsPage() {
  const contracts = useLedgerStore((s) => s.campaign.contracts);
  const updateContract = useLedgerStore((s) => s.updateContract);
  const addContract = useLedgerStore((s) => s.addContract);
  const deleteContract = useLedgerStore((s) => s.deleteContract);
  const [openId, setOpenId] = useState<string | null>(contracts[0]?.id ?? null);

  return (
    <div>
      <PageHeader kicker="Departamento de obrigações" title="Contratos">
        Missões, ganchos e dívidas. Um contrato aberto é uma ferida. Um selado, uma cicatriz.
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <ul className="flex flex-col gap-3">
          {contracts.map((c) => (
            <li key={c.id}>
              <article
                className={cn(
                  "dossier cursor-pointer p-5",
                  openId === c.id && "border-gold",
                )}
                onClick={() => setOpenId(c.id)}
              >
                <div className="relative z-10 flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                      {c.code} · rank {c.rank}
                    </p>
                    <h2 className="mt-1 font-display text-xl text-ink">{c.title}</h2>
                  </div>
                  <Badge
                    tone={
                      c.status === "falhou" || c.status === "selado"
                        ? "blood"
                        : c.status === "andamento"
                          ? "gold"
                          : "mute"
                    }
                  >
                    {STATUS[c.status]}
                  </Badge>
                </div>
                {openId === c.id ? (
                  <div className="relative z-10 mt-4 space-y-3 text-sm">
                    <p className="text-muted">{c.hook}</p>
                    <p>
                      <span className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                        Termos ·{" "}
                      </span>
                      {c.terms}
                    </p>
                    <p>
                      <span className="font-display text-2xs uppercase tracking-stamp text-gold-dim">
                        Remuneração ·{" "}
                      </span>
                      {c.reward}
                    </p>
                    <div className="flex flex-wrap gap-2 pt-2">
                      {(Object.keys(STATUS) as ContractStatus[]).map((st) => (
                        <Button
                          key={st}
                          size="sm"
                          variant={c.status === st ? "gold" : "ghost"}
                          onClick={(e) => {
                            e.stopPropagation();
                            updateContract(c.id, { status: st });
                            toast.message(`Estado alterado: ${STATUS[st]}.`);
                          }}
                        >
                          {STATUS[st]}
                        </Button>
                      ))}
                      <Button
                        size="sm"
                        variant="danger"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteContract(c.id);
                          toast.message("Contrato rasgado. A dívida, filosoficamente, resta.");
                        }}
                      >
                        Rasgar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="relative z-10 mt-3 line-clamp-2 text-sm text-muted">{c.hook}</p>
                )}
              </article>
            </li>
          ))}
        </ul>
        <NewContract onCreate={addContract} />
      </div>
    </div>
  );
}

function NewContract({ onCreate }: { onCreate: (c: Contract) => void }) {
  const [title, setTitle] = useState("");
  const [hook, setHook] = useState("");
  const [rank, setRank] = useState("Âmbar");
  return (
    <form
      className="h-fit border border-dashed border-edge bg-raised p-4"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim()) {
          toast.error("Um contrato sem título é apenas uma ameaça vaga.");
          return;
        }
        onCreate({
          id: uid("ct"),
          code: `CT-${Math.floor(100 + Math.random() * 800)}-X`,
          title: title.trim(),
          status: "aberto",
          rank,
          hook: hook.trim() || "O gancho ainda não foi iscado.",
          terms: "A Companhia redigirá os termos após a primeira sessão.",
          reward: "A definir. Provavelmente insuficiente.",
          relatedIds: [],
        });
        setTitle("");
        setHook("");
        toast.success("Contrato protocolado. Alguém, em algum lugar, já o assinou.");
      }}
    >
      <h2 className="font-display text-lg text-gold">Redigir contrato</h2>
      <div className="mt-4 flex flex-col gap-3">
        <Field label="Título">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Rank">
          <NativeSelect value={rank} onChange={(e) => setRank(e.target.value)}>
            {["Íris", "Âmbar", "Carmesim", "Obsidiana"].map((r) => (
              <option key={r}>{r}</option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Gancho">
          <Textarea value={hook} onChange={(e) => setHook(e.target.value)} />
        </Field>
        <Button type="submit">Protocolar obrigação</Button>
      </div>
    </form>
  );
}
