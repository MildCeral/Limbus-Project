//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DDoqXdDN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_ledger"],
		preloads: ["/assets/index-CvfssmHZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CvfssmHZ.js"
		} }]
	},
	"/_ledger": {
		filePath: "/workspace/src/routes/_ledger.tsx",
		children: [
			"/_ledger/archive",
			"/_ledger/contracts",
			"/_ledger/dice",
			"/_ledger/protocol",
			"/_ledger/theatre",
			"/_ledger/",
			"/_ledger/dossiers/$id",
			"/_ledger/dossiers/"
		],
		preloads: ["/assets/_ledger-Ooarm-vi.js", "/assets/app-shell-Dl1wehGL.js"]
	},
	"/_ledger/archive": {
		filePath: "/workspace/src/routes/_ledger/archive.tsx",
		children: void 0,
		preloads: ["/assets/archive-C5uYboyE.js", "/assets/store-BN62POIk.js"]
	},
	"/_ledger/contracts": {
		filePath: "/workspace/src/routes/_ledger/contracts.tsx",
		children: void 0,
		preloads: ["/assets/contracts-8fLxddjW.js", "/assets/store-BN62POIk.js"]
	},
	"/_ledger/dice": {
		filePath: "/workspace/src/routes/_ledger/dice.tsx",
		children: void 0,
		preloads: [
			"/assets/dice-DqO9m-p6.js",
			"/assets/store-BN62POIk.js",
			"/assets/rotate-ccw-B3X33C5e.js"
		]
	},
	"/_ledger/protocol": {
		filePath: "/workspace/src/routes/_ledger/protocol.tsx",
		children: void 0,
		preloads: ["/assets/protocol-CjuG3aWY.js", "/assets/store-BN62POIk.js"]
	},
	"/_ledger/theatre": {
		filePath: "/workspace/src/routes/_ledger/theatre.tsx",
		children: void 0,
		preloads: [
			"/assets/theatre-CZCOQlPl.js",
			"/assets/store-BN62POIk.js",
			"/assets/rotate-ccw-B3X33C5e.js"
		]
	},
	"/_ledger/": {
		filePath: "/workspace/src/routes/_ledger/index.tsx",
		children: void 0,
		preloads: ["/assets/_ledger-CilzXIj6.js", "/assets/store-BN62POIk.js"]
	},
	"/_ledger/dossiers/$id": {
		filePath: "/workspace/src/routes/_ledger/dossiers.$id.tsx",
		children: void 0,
		preloads: ["/assets/dossiers._id-DufBIsW7.js", "/assets/store-BN62POIk.js"]
	},
	"/_ledger/dossiers/": {
		filePath: "/workspace/src/routes/_ledger/dossiers.index.tsx",
		children: void 0,
		preloads: ["/assets/dossiers.index-Bss-P1g7.js", "/assets/store-BN62POIk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
