import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { g as ArrowUpRight, i as Swords, m as Dices } from "./_libs/lucide-react.mjs";
import { h as sinMeta } from "./_ssr/router-KbQJS_4J.mjs";
import { c as Portrait, f as buttonVariants, m as cn, t as Badge, u as VitalBar, v as formatStamp, w as useLedgerStore } from "./_ssr/store-DMDieGwW.mjs";
import { n as PageHeader } from "./_ssr/app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_ledger-TrHOsLQe.js
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	aberto: "Aberto",
	andamento: "Em curso",
	cumprido: "Cumprido",
	falhou: "Falhou",
	selado: "Selado"
};
function ArchiveHome() {
	const designation = useLedgerStore((s) => s.designation);
	const characters = useLedgerStore((s) => s.characters);
	const campaign = useLedgerStore((s) => s.campaign);
	const rolls = useLedgerStore((s) => s.rolls);
	const combat = useLedgerStore((s) => s.combat);
	const openContracts = campaign.contracts.filter((c) => c.status === "aberto" || c.status === "andamento");
	const greet = designation.role === "gerente" ? `Gerente ${designation.name || "sem nome"}` : `Pecador ${designation.name || "sem nome"}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			kicker: campaign.code,
			title: "Arquivo central",
			children: [
				"Bem-vindo de volta, ",
				greet,
				". A expedição segue. A tinta ainda não secou."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "enter enter-d1 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Pecadores",
					value: String(characters.length),
					hint: "dossiês abertos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Contratos",
					value: String(openContracts.length),
					hint: "ainda não selados"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Sessões",
					value: String(campaign.sessions.length),
					hint: "no caderno"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Teatro",
					value: `R${combat.round}`,
					hint: combat.name
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-6 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "enter enter-d2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg tracking-display text-gold",
							children: "Expedição ativa"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/archive",
							className: "text-xs uppercase tracking-wide text-muted hover:text-gold",
							children: "Abrir campanha"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "dossier p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
									children: campaign.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 font-display text-xl text-ink",
									children: campaign.name
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "stamp shrink-0",
									children: "Em curso"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "relative z-10 mt-4 text-sm leading-relaxed text-muted",
								children: campaign.premise
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 mt-5 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/theatre",
									className: cn(buttonVariants()),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, {
										className: "size-4",
										strokeWidth: 1.5
									}), "Entrar no teatro"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/dice",
									className: cn(buttonVariants({ variant: "ghost" })),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dices, {
										className: "size-4",
										strokeWidth: 1.5
									}), "Invocar o dado"]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-8 mb-3 font-display text-lg tracking-display text-gold",
						children: "Pecadores catalogados"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-3 sm:grid-cols-2",
						children: characters.map((c) => {
							const sin = sinMeta(c.sin);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/dossiers/$id",
								params: { id: c.id },
								className: "flex gap-3 border border-edge bg-paper p-3 transition-colors hover:border-gold-dim",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
										src: c.portrait,
										name: c.name,
										sin: c.sin,
										className: "size-16 shrink-0"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate font-display text-sm text-ink",
												children: c.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs text-muted",
												children: c.designation
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-2xs uppercase tracking-wide",
												style: { color: sin.hue },
												children: [
													sin.name,
													" · rank ",
													c.sinRank
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalBar, {
													current: c.hp,
													max: c.hpMax
												})
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 shrink-0 text-faint" })
								]
							}) }, c.id);
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "enter enter-d3 flex flex-col gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg tracking-display text-gold",
						children: "Contratos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contracts",
						className: "text-xs uppercase tracking-wide text-muted hover:text-gold",
						children: "Ver todos"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: openContracts.slice(0, 3).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-edge bg-raised px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xs text-faint",
									children: c.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: c.status === "andamento" ? "blood" : "gold",
									children: STATUS[c.status]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink",
								children: c.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 line-clamp-2 text-xs text-muted",
								children: c.hook
							})
						]
					}, c.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg tracking-display text-gold",
						children: "Últimas rolagens"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dice",
						className: "text-xs uppercase tracking-wide text-muted hover:text-gold",
						children: "Mesa de dados"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: rolls.slice(0, 5).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 border border-edge bg-raised px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-ink",
								children: r.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-2xs text-faint",
								children: [r.secret ? "Olhos do Gerente · " : "", formatStamp(r.at)]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg tabular-nums text-gold",
							children: r.total
						})]
					}, r.id))
				})] })]
			})]
		})
	] });
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-edge bg-paper px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl tabular-nums text-ink",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: hint
			})
		]
	});
}
//#endregion
export { ArchiveHome as component };
