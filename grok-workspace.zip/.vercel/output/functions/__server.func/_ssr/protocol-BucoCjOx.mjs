import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as APP_NAME, d as NAME_OPTIONS, o as APP_SLOGAN, r as APP_COMPANY } from "./router-KbQJS_4J.mjs";
import { i as Field, n as Button, o as Input, t as Badge, w as useLedgerStore } from "./store-DMDieGwW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PageHeader } from "./app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/protocol-BucoCjOx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DESIGN_PROMPT = `Dark gothic tabletop RPG interface inspired by Limbus Company, official dystopian corporation documents, aged digital paper, blood-red wax seals, faded gold foil serif lettering, oxidized metal corners, torn ledger edges, subtle runes, deep blacks (#0c0908), blood red (#a32626), faded gold (#c4a46a), cold greys, cinematic lighting, character dossier UI mockup with stamps and classification bars, cinematic, literary horror, no cute cartoon, no bright neon --ar 16:9 --stylize 180`;
function ProtocolPage() {
	const designation = useLedgerStore((s) => s.designation);
	const seal = useLedgerStore((s) => s.sealDesignation);
	const exportJson = useLedgerStore((s) => s.exportJson);
	const importJson = useLedgerStore((s) => s.importJson);
	const resetDemo = useLedgerStore((s) => s.resetDemo);
	const fileRef = (0, import_react.useRef)(null);
	function download() {
		const blob = new Blob([exportJson()], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "infernal-ledger.json";
		a.click();
		URL.revokeObjectURL(url);
		toast.success("O arquivo foi extraído. Trate-o como confidencial.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Circular interna LEDGER-VII",
				title: "Protocolo",
				children: "Documento de identidade do produto. Destinado a Gerentes, pecadores e à posteridade que ainda souber ler."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "dossier space-y-8 p-5 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
								n: "01",
								children: "Nome e slogan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-gold",
								children: APP_NAME
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: APP_COMPANY
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 italic text-ink",
								children: APP_SLOGAN
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-2",
								children: NAME_OPTIONS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "border border-edge bg-void/40 px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-sm text-ink",
										children: n.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: n.slogan
									})]
								}, n.name))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-faint",
								children: "Adotado: a primeira opção. As demais permanecem como nomes de departamentos."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
							n: "02",
							children: "Pitch"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: "THE INFERNAL LEDGER é a mesa e o palco. Um aplicativo de RPG de mesa que se disfarça de sistema interno de uma companhia maldita: dossiês de pecadores, contratos selados a cera, dados que caem como carimbos, um teatro tático onde o mapa é um formulário e o combate, um processo. Serve ao iniciante que precisa de uma ficha que o ensine, e ao veterano que quer gerir uma campanha inteira sem sair da atmosfera. Offline por natureza. Compartilhável por arquivo. Feio de tão belo — como um cartório depois do incêndio."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
								n: "03",
								children: "Funcionalidades"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-sm text-gold",
								children: "MVP (nesta edição)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 list-disc space-y-1 pl-5 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Dossiês completos (atributos, perícias, talentos, magias, traumas, pecados, inventário, diário)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Sistemas Ledger, D&D 5e e genérico/homebrew" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Rolagem d4–d100, vantagem, histórico carimbado, rolagens secretas" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Combate tático com grade quadrada ou hexagonal, tokens, iniciativa, condições" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Teatro da mente e modo mapa" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Campanha: NPCs, locais, sessões, linha do tempo, contratos" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Persistência local, exportação e importação do arquivo" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Instalável como PWA (Android, iOS, desktop)" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-sm text-gold",
								children: "Futuro (anexos)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 list-disc space-y-1 pl-5 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Sincronização entre dispositivos com contas" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Mesa compartilhada em tempo real (voz + cursor do Gerente)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Aplicativos nativos (Capacitor / React Native) sobre o mesmo núcleo" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Névoa de guerra, iluminação e mapas desenhados" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Compêndio pesquisável e importação de JSON de sistemas" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Assistente literário para ganchos e NPCs (opt-in)" })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
							n: "04",
							children: "Estrutura de telas"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
							className: "mt-2 list-decimal space-y-1 pl-5 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Portão — selar designação (Gerente / Pecador)" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Arquivo — painel da expedição" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Dossiês — estante e ficha-dossiê" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Dados — tribunal de Fortuna" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Teatro — mapa tático e relógio de turnos" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Campanha — NPCs, locais, sessões, tempo" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Contratos — obrigações e ganchos" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Protocolo — este documento, exportar, resetar" })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
							n: "05",
							children: "Arquitetura"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: "Núcleo web em React + TanStack Start, estado local com Zustand e persistência em localStorage (offline-first). A mesma base vira PWA instalável em Android e iOS. Expansão nativa: Capacitor envolve este webview; um futuro aplicativo nativo reutiliza o modelo de dados (JSON versionado). Sincronização: CRDT ou servidor de arquivos por mesa, nunca no caminho crítico da sessão. Combate e dados correm no cliente. Sem conta obrigatória nesta edição — o arquivo é o pecador."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
								n: "06",
								children: "Prompt visual"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-2 overflow-x-auto border border-edge bg-void p-3 text-xs leading-relaxed text-muted whitespace-pre-wrap",
								children: DESIGN_PROMPT
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								className: "mt-2",
								onClick: () => {
									navigator.clipboard.writeText(DESIGN_PROMPT);
									toast.success("Prompt copiado. Que os geradores sofram com estilo.");
								},
								children: "Copiar prompt"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative z-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampTitle, {
							n: "07",
							children: "Microcopy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 space-y-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
									k: "Primário",
									v: "Selar designação · Invocar o dado · Avançar o relógio · Protocolar obrigação"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
									k: "Vazio",
									v: "Nenhum pecador catalogado. A Companhia espera."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
									k: "Erro",
									v: "O arquivo recusou-se a abrir. Talvez não fosse para você lê-lo."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
									k: "Crítico",
									v: "Falha crítica. A Companhia anota. A Companhia não esquece."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
									k: "Confirmação",
									v: "Este ato não pode ser desfeito. A tinta já secou?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
									k: "Exportar",
									v: "O arquivo foi extraído. Trate-o como confidencial."
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 border border-edge bg-paper p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg text-gold",
						children: "Custódia do arquivo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"Designação atual:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ink",
								children: designation.sealed ? `${designation.role === "gerente" ? "Gerente" : "Pecador"} ${designation.name}` : "não selada"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Reassinar o livro",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								defaultValue: designation.name,
								onBlur: (e) => {
									const n = e.target.value.trim();
									if (n.length >= 2) seal(n, designation.role);
								}
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col justify-end gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => seal(designation.name || "Anônimo", designation.role === "gerente" ? "pecador" : "gerente"),
								children: "Alternar Gerente / Pecador"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: download,
								children: "Exportar arquivo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => fileRef.current?.click(),
								children: "Importar arquivo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => {
									resetDemo();
									toast.message("Os arquivos de demonstração foram restaurados. Suas anotações, não.");
								},
								children: "Restaurar expedição-demo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: "application/json",
								className: "hidden",
								onChange: async (e) => {
									const file = e.target.files?.[0];
									if (!file) return;
									const text = await file.text();
									const res = importJson(text);
									if (res.ok) toast.success("Lacre reconhecido. O arquivo foi absorvido.");
									else toast.error(res.error);
									e.target.value = "";
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-faint",
						children: "A Companhia não se responsabiliza por distorções resultantes da leitura."
					})
				]
			})
		]
	});
}
function StampTitle({ n, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: n }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg tracking-display text-ink",
			children
		})]
	});
}
function CopyRow({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "text-muted",
		children: v
	})] });
}
//#endregion
export { ProtocolPage as component };
