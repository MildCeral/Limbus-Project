import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { f as SINS, h as sinMeta, p as SYSTEMS } from "./router-KbQJS_4J.mjs";
import { c as Portrait, i as Field, l as Textarea, m as cn, n as Button, o as Input, s as NativeSelect, t as Badge, u as VitalBar, w as useLedgerStore, y as makeBlankCharacter } from "./store-DMDieGwW.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PageHeader } from "./app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dossiers.index-B6Yk9aae.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
function DialogContent({ className, title, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-void/80 data-[state=open]:animate-in" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 max-h-[min(90dvh,720px)] w-[min(calc(100%-1.5rem),32rem)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto border border-edge bg-surface p-5 shadow-paper", wide && "w-[min(calc(100%-1.5rem),40rem)]", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-lg tracking-display text-gold",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "flex size-11 items-center justify-center text-muted transition-colors hover:text-ink",
				"aria-label": "Fechar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}), children]
	})] });
}
function DossiersPage() {
	const characters = useLedgerStore((s) => s.characters);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Setor de pessoal",
			title: "Dossiês",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(true),
				children: "Abrir novo dossiê"
			}),
			children: "Cada pecador é um arquivo. Cada arquivo, uma dívida. Trate as margens com respeito."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewDossier, { onDone: () => setOpen(false) })
		}),
		characters.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Nenhum pecador catalogado. A Companhia espera."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
			children: characters.map((c) => {
				const sin = sinMeta(c.sin);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "enter",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dossiers/$id",
						params: { id: c.id },
						className: "dossier block overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							src: c.portrait,
							name: c.name,
							sin: c.sin,
							className: "h-48 w-full"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
										children: c.designation
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-xl text-ink",
										children: c.name
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: c.classification.split("/")[0]?.trim() })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm italic text-muted",
									children: c.epithet
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										style: { color: sin.hue },
										children: [
											sin.latin,
											" · rank ",
											c.sinRank
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums text-faint",
										children: [
											"PV ",
											c.hp,
											"/",
											c.hpMax
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalBar, {
										current: c.hp,
										max: c.hpMax
									})
								})
							]
						})]
					})
				}, c.id);
			})
		})
	] });
}
function NewDossier({ onDone }) {
	const add = useLedgerStore((s) => s.addCharacter);
	const [system, setSystem] = (0, import_react.useState)("ledger");
	const [name, setName] = (0, import_react.useState)("");
	const [designation, setDesignation] = (0, import_react.useState)("Pecador nº ");
	const [epithet, setEpithet] = (0, import_react.useState)("");
	const [sin, setSin] = (0, import_react.useState)("pride");
	const [notes, setNotes] = (0, import_react.useState)("");
	function submit() {
		if (name.trim().length < 2) {
			toast.error("Um dossiê sem nome é apenas papel. A Companhia recusa.");
			return;
		}
		const c = makeBlankCharacter(system);
		c.name = name.trim();
		c.designation = designation.trim() || "Pecador nº —";
		c.epithet = epithet.trim();
		c.sin = sin;
		c.notes = notes.trim();
		c.sins = [{
			id: `${c.id}-sin`,
			sin,
			rank: 1,
			desc: "O primeiro carimbo ainda está úmido."
		}];
		add(c);
		toast.success("Dossiê protocolado. Que o pecador mereça a tinta.");
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
		title: "Protocolar pecador",
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nome civil ou escolhido",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Helena Voss"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Designação",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: designation,
							onChange: (e) => setDesignation(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Epíteto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: epithet,
							onChange: (e) => setEpithet(e.target.value),
							placeholder: "A que leu demais"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Sistema de regras",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
						value: system,
						onChange: (e) => setSystem(e.target.value),
						children: SYSTEMS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.id,
							children: s.name
						}, s.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Pecado dominante",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: SINS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSin(s.id),
							className: cn("h-11 border text-xs", sin === s.id ? "border-gold bg-paper text-gold" : "border-edge text-muted"),
							children: s.name
						}, s.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Observação inicial",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "O Gerente anota o que os pecadores omitem."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: submit,
					className: "w-full",
					children: "Selar dossiê"
				})
			]
		})
	});
}
//#endregion
export { DossiersPage as component };
