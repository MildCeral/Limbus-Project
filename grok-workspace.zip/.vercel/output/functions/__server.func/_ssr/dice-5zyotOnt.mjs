import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as Eye, p as EyeOff, s as RotateCcw } from "../_libs/lucide-react.mjs";
import { c as DICE_PRESETS } from "./router-KbQJS_4J.mjs";
import { d as WaxSeal, i as Field, m as cn, n as Button, o as Input, s as NativeSelect, t as Badge, v as formatStamp, w as useLedgerStore, x as parseFormula } from "./store-DMDieGwW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PageHeader } from "./app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dice-5zyotOnt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DicePage() {
	const rolls = useLedgerStore((s) => s.rolls);
	const characters = useLedgerStore((s) => s.characters);
	const designation = useLedgerStore((s) => s.designation);
	const recordRoll = useLedgerStore((s) => s.recordRoll);
	const clearRolls = useLedgerStore((s) => s.clearRolls);
	const [formula, setFormula] = (0, import_react.useState)("1d20");
	const [label, setLabel] = (0, import_react.useState)("");
	const [mod, setMod] = (0, import_react.useState)(0);
	const [secret, setSecret] = (0, import_react.useState)(false);
	const [adv, setAdv] = (0, import_react.useState)("normal");
	const [who, setWho] = (0, import_react.useState)("");
	const [spinning, setSpinning] = (0, import_react.useState)(false);
	const [face, setFace] = (0, import_react.useState)(null);
	const lastId = (0, import_react.useRef)(null);
	const latest = rolls[0];
	(0, import_react.useEffect)(() => {
		if (!latest || latest.id === lastId.current) return;
		lastId.current = latest.id;
	}, [latest]);
	function compose() {
		const parsed = parseFormula(formula);
		if (!parsed) return formula;
		const next = {
			...parsed,
			modifier: parsed.modifier + mod
		};
		const base = `${next.count}d${next.sides}`;
		if (next.modifier === 0) return base;
		return next.modifier > 0 ? `${base}+${next.modifier}` : `${base}${next.modifier}`;
	}
	function invoke(raw) {
		if (spinning) return;
		const input = raw ?? compose();
		if (!parseFormula(input.split("[")[0] ?? input)) {
			toast.error("O dado não reconhece essa liturgia. Use NdX+M.");
			return;
		}
		setSpinning(true);
		const sides = parseFormula(input)?.sides ?? 20;
		const start = performance.now();
		let raf = 0;
		const tick = (now) => {
			setFace(1 + Math.floor(Math.random() * sides));
			if (now - start < 720) raf = requestAnimationFrame(tick);
			else {
				const whoName = characters.find((c) => c.id === who)?.name;
				const roll = recordRoll(input, {
					label: label.trim() || (whoName ? `${whoName} · rolagem` : "Rolagem avulsa"),
					secret,
					characterId: who || void 0,
					advantage: adv
				});
				setSpinning(false);
				if (roll) {
					setFace(roll.total);
					if (roll.secret) toast.message("O carimbo secreto foi aplicado. Só o Gerente deveria ver.");
					else if (roll.total === 1 && roll.sides === 20) toast.error("Falha crítica. A Companhia anota. A Companhia não esquece.");
					else if (roll.total >= 20 && roll.sides === 20 && roll.dice.includes(20)) toast.success("Vinte. Até o arquivo hesita.");
				}
			}
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Tribunal de Fortuna",
		title: "Mesa de dados",
		children: "Os dados da Companhia não são justos. São apenas honestos — o que é pior."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,1fr)_20rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "dossier p-5 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("grid size-40 place-items-center border-2 border-gold/50 bg-void shadow-seal", spinning && "opacity-80"),
						children: spinning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaxSeal, {
							letter: "?",
							className: "size-20",
							pulse: true
						}) : face !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "stamp-slam font-display text-6xl tabular-nums text-gold",
							children: latest?.secret && designation.role !== "gerente" ? "—" : face
						}, latest?.id ?? "face") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-sm tracking-stamp text-faint",
							children: "AGUARDE O SELO"
						})
					}), latest && !spinning ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-center text-sm text-muted",
						children: [
							latest.formula,
							" → [",
							latest.dice.join(", "),
							"]",
							latest.modifier ? ` ${latest.modifier > 0 ? "+" : ""}${latest.modifier}` : ""
						]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-wrap justify-center gap-2",
					children: DICE_PRESETS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: formula === `1d${n}` ? "gold" : "ghost",
						size: "sm",
						onClick: () => {
							setFormula(`1d${n}`);
							setAdv("normal");
						},
						children: ["d", n]
					}, n))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Fórmula",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: formula,
								onChange: (e) => setFormula(e.target.value),
								placeholder: "2d6+3"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Modificador extra",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: mod,
								onChange: (e) => setMod(Number(e.target.value) || 0)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Rótulo / intenção",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: label,
								onChange: (e) => setLabel(e.target.value),
								placeholder: "Ataque, tesouro, mentira..."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pecador",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
								value: who,
								onChange: (e) => setWho(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— avulso —"
								}), characters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [[
						"normal",
						"adv",
						"dis"
					].map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: adv === a ? "gold" : "ghost",
						onClick: () => setAdv(a),
						children: a === "normal" ? "Normal" : a === "adv" ? "Vantagem" : "Desvantagem"
					}, a)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: secret ? "danger" : "ghost",
						onClick: () => setSecret((v) => !v),
						children: [secret ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }), secret ? "Olhos do Gerente" : "Rolagem aberta"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					size: "lg",
					onClick: () => invoke(),
					disabled: spinning,
					children: spinning ? "O dado ainda gira..." : "Invocar o dado"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg text-gold",
				children: "Carimbos"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "quiet",
				onClick: () => {
					clearRolls();
					toast.message("O histórico foi raspado. A memória, não.");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "Raspar"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex max-h-[32rem] flex-col gap-2 overflow-y-auto",
			children: rolls.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nenhuma rolagem. Fortuna ainda não foi insultada hoje."
			}) : rolls.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border border-edge bg-paper px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-ink",
							children: r.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-2xs text-faint",
							children: [
								formatStamp(r.at),
								" · ",
								r.formula
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl tabular-nums text-gold",
						children: r.total
					})]
				}), r.secret ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "blood",
					className: "mt-1",
					children: "secreto"
				}) : null]
			}, r.id))
		})] })]
	})] });
}
//#endregion
export { DicePage as component };
