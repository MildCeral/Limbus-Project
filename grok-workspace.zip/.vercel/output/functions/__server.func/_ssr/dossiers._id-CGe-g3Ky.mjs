import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as ArrowLeft, m as Dices, r as Trash2 } from "../_libs/lucide-react.mjs";
import { h as sinMeta, n as Route } from "./router-KbQJS_4J.mjs";
import { C as uid, S as skillCheckFormula, _ as fmtMod, a as FileRule, b as modifier, c as Portrait, i as Field, l as Textarea, n as Button, o as Input, p as clamp, t as Badge, u as VitalBar, v as formatStamp, w as useLedgerStore } from "./store-DMDieGwW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dossiers._id-CGe-g3Ky.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	"Identidade",
	"Corpo",
	"Arsenal",
	"Carga",
	"Diário"
];
function DossierDetail() {
	const { id } = Route.useParams();
	const character = useLedgerStore((s) => s.characters.find((c) => c.id === id));
	const patch = useLedgerStore((s) => s.patchCharacter);
	const remove = useLedgerStore((s) => s.deleteCharacter);
	const addJournal = useLedgerStore((s) => s.addJournal);
	const recordRoll = useLedgerStore((s) => s.recordRoll);
	const navigate = useNavigate();
	const [tab, setTab] = (0, import_react.useState)("Identidade");
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	if (!character) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl text-gold",
				children: "Dossiê extraviado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "O arquivo não reconhece este número. Talvez nunca tenha existido."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dossiers",
				className: "mt-6 inline-flex h-11 items-center text-gold",
				children: "Voltar à estante"
			})
		]
	});
	const sin = sinMeta(character.sin);
	function update(partial) {
		patch(character.id, (c) => ({
			...c,
			...partial
		}));
	}
	function rollSkill(sk) {
		const attr = character.attributes.find((a) => a.id === sk.attr);
		const mod = (attr ? modifier(attr.value) : 0) + sk.value;
		const roll = recordRoll(skillCheckFormula(mod), {
			label: `${character.name} · ${sk.name}`,
			characterId: character.id
		});
		if (roll) toast.success(`O dado caiu em ${roll.total}. A tinta registra.`);
	}
	function rollAttr(abbr, value) {
		const roll = recordRoll(skillCheckFormula(modifier(value)), {
			label: `${character.name} · ${abbr}`,
			characterId: character.id
		});
		if (roll) toast.success(`${abbr}: ${roll.total}.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/dossiers",
			className: "mb-4 inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Estante de dossiês"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
			className: "dossier watermark overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 grid gap-0 lg:grid-cols-[220px_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					src: character.portrait,
					name: character.name,
					sin: character.sin,
					className: "aspect-square w-full lg:min-h-full"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-5 sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
									children: [
										character.designation,
										" · ",
										character.classification
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-1 font-display text-3xl tracking-display text-ink",
									children: character.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 italic text-muted",
									children: character.epithet
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "stamp",
								children: sin.latin
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalEdit, {
								label: "Pontos de vida",
								current: character.hp,
								max: character.hpMax,
								kind: "hp",
								onChange: (hp, hpMax) => update({
									hp,
									hpMax
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalEdit, {
								label: "Sanidade / SP",
								current: character.sp,
								max: character.spMax,
								kind: "sp",
								onChange: (sp, spMax) => update({
									sp,
									spMax
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs uppercase tracking-wide",
							style: { color: sin.hue },
							children: [
								"Pecado ",
								sin.name,
								" · nível ",
								character.sinRank
							]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex gap-1 overflow-x-auto border-b border-line",
			children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(t),
				className: tab === t ? "h-11 shrink-0 border-b-2 border-gold px-4 text-sm text-gold" : "h-11 shrink-0 px-4 text-sm text-muted hover:text-ink",
				children: t
			}, t))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6",
			children: [
				tab === "Identidade" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityForm, {
					character,
					onChange: update
				}) : null,
				tab === "Corpo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyPanel, {
					character,
					onChange: update,
					onRollAttr: rollAttr,
					onRollSkill: rollSkill
				}) : null,
				tab === "Arsenal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArsenalPanel, {
					character,
					onChange: update
				}) : null,
				tab === "Carga" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InventoryPanel, {
					character,
					onChange: update
				}) : null,
				tab === "Diário" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalPanel, {
					character,
					onAdd: (e) => addJournal(character.id, e)
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 flex flex-wrap items-center gap-3 border-t border-line pt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/dice",
				className: "inline-flex h-11 items-center gap-2 border border-edge px-4 text-sm hover:border-gold-dim",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dices, { className: "size-4" }), "Rolagens deste pecador"]
			}), confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: () => {
					remove(character.id);
					toast.message("O dossiê foi reduzido a cinzas. A dívida permanece.");
					navigate({ to: "/dossiers" });
				},
				children: "Confirmar incineração"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "quiet",
				onClick: () => setConfirm(false),
				children: "A tinta ainda pode secar"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				onClick: () => setConfirm(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Incinerar dossiê"]
			})]
		})
	] });
}
function VitalEdit({ label, current, max, kind, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-center justify-between text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "tabular-nums text-ink",
				children: [
					current,
					"/",
					max
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalBar, {
			current,
			max,
			kind
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => onChange(clamp(current - 1, 0, max), max),
					children: "−1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => onChange(clamp(current + 1, 0, max), max),
					children: "+1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-9 w-20",
					type: "number",
					value: max,
					onChange: (e) => {
						const n = Number(e.target.value) || 0;
						onChange(clamp(current, 0, n), n);
					},
					"aria-label": `${label} máximo`
				})
			]
		})
	] });
}
function IdentityForm({ character, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nome",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: character.name,
					onChange: (e) => onChange({ name: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Designação",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: character.designation,
					onChange: (e) => onChange({ designation: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Epíteto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: character.epithet,
					onChange: (e) => onChange({ epithet: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Classificação",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: character.classification,
					onChange: (e) => onChange({ classification: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nível de pecado",
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					min: 1,
					max: 7,
					value: character.sinRank,
					onChange: (e) => onChange({ sinRank: clamp(Number(e.target.value) || 1, 1, 7) })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notas do Gerente",
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: character.notes,
					onChange: (e) => onChange({ notes: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileRule, { label: "traumas" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-3",
						children: character.traumas.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border border-edge bg-paper px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm text-gold",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: t.desc
							})]
						}, t.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-3",
						children: character.sins.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border border-blood/40 bg-blood-dim/20 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-sm text-blood",
								children: [
									sinMeta(s.sin).name,
									" · rank ",
									s.rank
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: s.desc
							})]
						}, s.id))
					})
				]
			})
		]
	});
}
function BodyPanel({ character, onChange, onRollAttr, onRollSkill }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg text-gold",
			children: "Atributos"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: character.attributes.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border border-edge bg-paper p-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
						children: a.abbr
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl tabular-nums",
						children: a.value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: fmtMod(a.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-faint",
						children: a.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								onClick: () => onChange({ attributes: character.attributes.map((x) => x.id === a.id ? {
									...x,
									value: clamp(x.value - 1, 1, 20)
								} : x) }),
								children: "−"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => onRollAttr(a.abbr, a.value),
								children: "d20"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								onClick: () => onChange({ attributes: character.attributes.map((x) => x.id === a.id ? {
									...x,
									value: clamp(x.value + 1, 1, 20)
								} : x) }),
								children: "+"
							})
						]
					})
				]
			}, a.id))
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg text-gold",
			children: "Perícias"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 flex flex-col gap-1",
			children: character.skills.map((sk) => {
				const attr = character.attributes.find((a) => a.id === sk.attr);
				const total = (attr ? modifier(attr.value) : 0) + sk.value;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 border border-edge bg-raised px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink",
								children: sk.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-2xs text-faint",
								children: [
									attr?.abbr ?? sk.attr,
									" ",
									fmtMod(attr?.value ?? 10),
									" + ",
									sk.value
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display tabular-nums text-gold",
							children: total >= 0 ? `+${total}` : total
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => onRollSkill(sk),
							children: "Rolar"
						})
					]
				}, sk.id);
			})
		})] })]
	});
}
function ArsenalPanel({ character, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
				title: "Talentos",
				empty: "Nenhum talento protocolado. A mediocridade também é um destino.",
				items: character.talents.map((t) => ({
					id: t.id,
					title: t.name,
					body: t.desc
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
				title: "Fórmulas / Magias",
				empty: "Este pecador não recita. Ainda.",
				items: character.spells.map((t) => ({
					id: t.id,
					title: `${t.name} · círculo ${t.circle}`,
					body: t.desc
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddLine, {
				label: "Novo talento",
				onAdd: (title, body) => onChange({ talents: [...character.talents, {
					id: uid("t"),
					name: title,
					desc: body
				}] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddLine, {
				label: "Nova fórmula",
				onAdd: (title, body) => onChange({ spells: [...character.spells, {
					id: uid("sp"),
					name: title,
					circle: 1,
					desc: body
				}] })
			})
		]
	});
}
function InventoryPanel({ character, onChange }) {
	const [name, setName] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: character.inventory.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex flex-wrap items-center gap-3 border border-edge bg-paper px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-ink",
						children: [
							it.name,
							" ",
							it.equipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								className: "ml-2",
								children: "equipado"
							}) : null
						]
					}), it.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: it.notes
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums text-sm text-gold",
					children: ["×", it.qty]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "quiet",
					onClick: () => onChange({ inventory: character.inventory.map((x) => x.id === it.id ? {
						...x,
						equipped: !x.equipped
					} : x) }),
					children: it.equipped ? "Guardar" : "Equipar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "quiet",
					onClick: () => onChange({ inventory: character.inventory.filter((x) => x.id !== it.id) }),
					children: "Descartar"
				})
			]
		}, it.id))
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-4 flex flex-col gap-2 sm:flex-row",
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return;
			const item = {
				id: uid("i"),
				name: name.trim(),
				qty: 1
			};
			onChange({ inventory: [...character.inventory, item] });
			setName("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: name,
			onChange: (e) => setName(e.target.value),
			placeholder: "Nome do item a protocolar"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "submit",
			children: "Registrar carga"
		})]
	})] });
}
function JournalPanel({ character, onAdd }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const sorted = (0, import_react.useMemo)(() => [...character.journal].sort((a, b) => b.at - a.at), [character.journal]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-3 border border-edge bg-paper p-4",
			onSubmit: (e) => {
				e.preventDefault();
				if (!title.trim() || !body.trim()) {
					toast.error("O diário recusa páginas em branco. Escreva, ou cale-se.");
					return;
				}
				onAdd({
					title: title.trim(),
					body: body.trim(),
					at: Date.now(),
					sin: character.sin
				});
				setTitle("");
				setBody("");
				toast.success("Entrada selada. Ninguém promete que permanecerá secreta.");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg text-gold",
					children: "Nova entrada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Título",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Corpo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: body,
						onChange: (e) => setBody(e.target.value),
						className: "min-h-36",
						placeholder: "Escreva como se o Gerente fosse ler — porque ele lerá."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Selar página"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-4",
			children: sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "O diário deste pecador ainda é um silêncio bem encadernado."
			}) : sorted.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-l-2 border-gold/40 bg-raised px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm text-gold",
						children: j.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xs text-faint",
						children: formatStamp(j.at)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: j.body
					})
				]
			}, j.id))
		})]
	});
}
function ListBlock({ title, empty, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-lg text-gold",
		children: title
	}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-3 text-sm text-muted",
		children: empty
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 flex flex-col gap-2",
		children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "border border-edge bg-paper px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm text-ink",
				children: it.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: it.body
			})]
		}, it.id))
	})] });
}
function AddLine({ label, onAdd }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-2 border border-dashed border-edge p-3",
		onSubmit: (e) => {
			e.preventDefault();
			if (!title.trim()) return;
			onAdd(title.trim(), body.trim());
			setTitle("");
			setBody("");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: title,
				onChange: (e) => setTitle(e.target.value),
				placeholder: "Nome"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: body,
				onChange: (e) => setBody(e.target.value),
				placeholder: "Cláusula"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "ghost",
				size: "sm",
				children: "Anexar ao dossiê"
			})
		]
	});
}
//#endregion
export { DossierDetail as component };
