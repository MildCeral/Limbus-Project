import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as uid, i as Field, l as Textarea, n as Button, o as Input, t as Badge, w as useLedgerStore } from "./store-DMDieGwW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PageHeader } from "./app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/archive-BWfVsRZF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	"Visão",
	"NPCs",
	"Locais",
	"Sessões",
	"Linha do tempo"
];
function ArchivePage() {
	const campaign = useLedgerStore((s) => s.campaign);
	const updateCampaign = useLedgerStore((s) => s.updateCampaign);
	const addNpc = useLedgerStore((s) => s.addNpc);
	const deleteNpc = useLedgerStore((s) => s.deleteNpc);
	const addPlace = useLedgerStore((s) => s.addPlace);
	const deletePlace = useLedgerStore((s) => s.deletePlace);
	const addSession = useLedgerStore((s) => s.addSession);
	const deleteSession = useLedgerStore((s) => s.deleteSession);
	const addEvent = useLedgerStore((s) => s.addEvent);
	const deleteEvent = useLedgerStore((s) => s.deleteEvent);
	const [tab, setTab] = (0, import_react.useState)("Visão");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: campaign.code,
			title: campaign.name,
			children: "Relatórios internos. O que não estiver escrito aqui não aconteceu — oficialmente."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-1 overflow-x-auto border-b border-line",
			children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(t),
				className: tab === t ? "h-11 shrink-0 border-b-2 border-gold px-4 text-sm text-gold" : "h-11 shrink-0 px-4 text-sm text-muted hover:text-ink",
				children: t
			}, t))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6",
			children: [
				tab === "Visão" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nome da expedição",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: campaign.name,
								onChange: (e) => updateCampaign({ name: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Código de arquivo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: campaign.code,
								onChange: (e) => updateCampaign({ code: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Premissa",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								className: "min-h-32",
								value: campaign.premise,
								onChange: (e) => updateCampaign({ premise: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Notas do Gerente",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								className: "min-h-32",
								value: campaign.notes,
								onChange: (e) => updateCampaign({ notes: e.target.value })
							})
						})
					]
				}) : null,
				tab === "NPCs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [campaign.npcs.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-edge bg-paper p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg text-ink",
									children: n.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-wide text-gold",
									children: n.role
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "quiet",
									onClick: () => deleteNpc(n.id),
									children: "Arquivar"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: n.attitude
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs uppercase tracking-wide text-blood",
								children: "Segredo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink",
								children: n.secrets
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm italic text-faint",
								children: n.notes
							})
						]
					}, n.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickPerson, { onCreate: addNpc })]
				}) : null,
				tab === "Locais" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [campaign.places.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-edge bg-paper p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg text-ink",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-gold",
									children: p.kind
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: p.danger >= 4 ? "blood" : "gold",
									children: ["perigo ", p.danger]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted",
								children: p.desc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								className: "mt-3",
								onClick: () => deletePlace(p.id),
								children: "Riscar do mapa"
							})
						]
					}, p.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickPlace, { onCreate: addPlace })]
				}) : null,
				tab === "Sessões" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4",
					children: [campaign.sessions.slice().sort((a, b) => b.number - a.number).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-edge bg-paper p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
								children: [
									"Sessão ",
									s.number,
									" · ",
									s.date
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl text-ink",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: s.summary
							}),
							s.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm italic text-faint",
								children: s.notes
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								className: "mt-3",
								onClick: () => deleteSession(s.id),
								children: "Expurgar ata"
							})
						]
					}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSession, {
						nextNumber: campaign.sessions.reduce((m, s) => Math.max(m, s.number), 0) + 1,
						onCreate: addSession
					})]
				}) : null,
				tab === "Linha do tempo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "relative border-l border-gold/30 pl-5",
					children: [campaign.timeline.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "mb-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -left-1.5 mt-1.5 size-3 rounded-full bg-gold" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
								children: [e.at, e.secret ? " · olhos do gerente" : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg text-ink",
								children: e.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: e.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								onClick: () => deleteEvent(e.id),
								children: "Apagar evento"
							})
						]
					}, e.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickEvent, { onCreate: addEvent })]
				}) : null
			]
		})
	] });
}
function QuickPerson({ onCreate }) {
	const [name, setName] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "border border-dashed border-edge p-4",
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return;
			onCreate({
				id: uid("npc"),
				name: name.trim(),
				role: role.trim() || "Testemunha",
				attitude: "Indefinida.",
				secrets: "Ainda não catalogado.",
				notes: ""
			});
			setName("");
			setRole("");
			toast.success("Um nome a mais no índice. Que se arrependa.");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Protocolar NPC"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value),
					placeholder: "Nome"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: role,
					onChange: (e) => setRole(e.target.value),
					placeholder: "Função"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "ghost",
					children: "Registrar"
				})
			]
		})]
	});
}
function QuickPlace({ onCreate }) {
	const [name, setName] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "border border-dashed border-edge p-4",
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return;
			onCreate({
				id: uid("loc"),
				name: name.trim(),
				kind: "Local",
				desc: "Ainda sem perícia formal.",
				danger: 2
			});
			setName("");
			toast.success("O mapa engordou. Os atalhos, não.");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Protocolar local"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: name,
				onChange: (e) => setName(e.target.value),
				placeholder: "Nome do lugar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "ghost",
				children: "Registrar"
			})]
		})]
	});
}
function QuickSession({ nextNumber, onCreate }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [summary, setSummary] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "border border-dashed border-edge p-4",
		onSubmit: (e) => {
			e.preventDefault();
			if (!title.trim()) return;
			onCreate({
				id: uid("ses"),
				number: nextNumber,
				title: title.trim(),
				date: (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR"),
				summary: summary.trim() || "Ata ainda em branco.",
				notes: ""
			});
			setTitle("");
			setSummary("");
			toast.success("Sessão protocolada. O que aconteceu agora é oficial.");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-display text-sm text-gold",
			children: ["Nova ata · sessão ", nextNumber]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "Título"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: summary,
					onChange: (e) => setSummary(e.target.value),
					placeholder: "O que o arquivo deve lembrar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "ghost",
					children: "Selar ata"
				})
			]
		})]
	});
}
function QuickEvent({ onCreate }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [at, setAt] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "border border-dashed border-edge p-4",
		onSubmit: (e) => {
			e.preventDefault();
			if (!title.trim()) return;
			onCreate({
				id: uid("tl"),
				at: at.trim() || "Data incerta",
				title: title.trim(),
				body: "Evento acrescentado à margem do tempo."
			});
			setTitle("");
			setAt("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Acrescentar ao tempo"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: at,
					onChange: (e) => setAt(e.target.value),
					placeholder: "Quando"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "O quê"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "ghost",
					children: "Registrar"
				})
			]
		})]
	});
}
//#endregion
export { ArchivePage as component };
