import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as uid, i as Field, l as Textarea, m as cn, n as Button, o as Input, s as NativeSelect, t as Badge, w as useLedgerStore } from "./store-DMDieGwW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PageHeader } from "./app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contracts-D_ot_2nG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	aberto: "Aberto",
	andamento: "Em curso",
	cumprido: "Cumprido",
	falhou: "Falhou",
	selado: "Selado"
};
function ContractsPage() {
	const contracts = useLedgerStore((s) => s.campaign.contracts);
	const updateContract = useLedgerStore((s) => s.updateContract);
	const addContract = useLedgerStore((s) => s.addContract);
	const deleteContract = useLedgerStore((s) => s.deleteContract);
	const [openId, setOpenId] = (0, import_react.useState)(contracts[0]?.id ?? null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Departamento de obrigações",
		title: "Contratos",
		children: "Missões, ganchos e dívidas. Um contrato aberto é uma ferida. Um selado, uma cicatriz."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: contracts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: cn("dossier cursor-pointer p-5", openId === c.id && "border-gold"),
				onClick: () => setOpenId(c.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
						children: [
							c.code,
							" · rank ",
							c.rank
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-xl text-ink",
						children: c.title
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: c.status === "falhou" || c.status === "selado" ? "blood" : c.status === "andamento" ? "gold" : "mute",
						children: STATUS[c.status]
					})]
				}), openId === c.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 mt-4 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: c.hook
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
							children: ["Termos ·", " "]
						}), c.terms] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
							children: ["Remuneração ·", " "]
						}), c.reward] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2 pt-2",
							children: [Object.keys(STATUS).map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: c.status === st ? "gold" : "ghost",
								onClick: (e) => {
									e.stopPropagation();
									updateContract(c.id, { status: st });
									toast.message(`Estado alterado: ${STATUS[st]}.`);
								},
								children: STATUS[st]
							}, st)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "danger",
								onClick: (e) => {
									e.stopPropagation();
									deleteContract(c.id);
									toast.message("Contrato rasgado. A dívida, filosoficamente, resta.");
								},
								children: "Rasgar"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "relative z-10 mt-3 line-clamp-2 text-sm text-muted",
					children: c.hook
				})]
			}) }, c.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewContract, { onCreate: addContract })]
	})] });
}
function NewContract({ onCreate }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [hook, setHook] = (0, import_react.useState)("");
	const [rank, setRank] = (0, import_react.useState)("Âmbar");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "h-fit border border-dashed border-edge bg-raised p-4",
		onSubmit: (e) => {
			e.preventDefault();
			if (!title.trim()) {
				toast.error("Um contrato sem título é apenas uma ameaça vaga.");
				return;
			}
			onCreate({
				id: uid("ct"),
				code: `CT-${Math.floor(100 + Math.random() * 800)}-X`,
				title: title.trim(),
				status: "aberto",
				rank,
				hook: hook.trim() || "O gancho ainda não foi iscado.",
				terms: "A Companhia redigirá os termos após a primeira sessão.",
				reward: "A definir. Provavelmente insuficiente.",
				relatedIds: []
			});
			setTitle("");
			setHook("");
			toast.success("Contrato protocolado. Alguém, em algum lugar, já o assinou.");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg text-gold",
			children: "Redigir contrato"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Título",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Rank",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
						value: rank,
						onChange: (e) => setRank(e.target.value),
						children: [
							"Íris",
							"Âmbar",
							"Carmesim",
							"Obsidiana"
						].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Gancho",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: hook,
						onChange: (e) => setHook(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Protocolar obrigação"
				})
			]
		})]
	});
}
//#endregion
export { ContractsPage as component };
