import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Plus, s as RotateCcw } from "../_libs/lucide-react.mjs";
import { h as sinMeta, s as CONDITIONS } from "./router-KbQJS_4J.mjs";
import { c as Portrait, g as currentActor, h as combatOrder, i as Field, m as cn, n as Button, o as Input, p as clamp, r as ENEMY_PORTRAITS, s as NativeSelect, t as Badge, u as VitalBar, v as formatStamp, w as useLedgerStore } from "./store-DMDieGwW.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PageHeader } from "./app-shell-k8h-JkJg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/theatre-DWuKmstv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CELL = 44;
function MapBoard() {
	const combat = useLedgerStore((s) => s.combat);
	const characters = useLedgerStore((s) => s.characters);
	const selectToken = useLedgerStore((s) => s.selectToken);
	const moveToken = useLedgerStore((s) => s.moveToken);
	const actor = currentActor(combat);
	const boardRef = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(null);
	const width = combat.grid === "hex" ? combat.cols * CELL + CELL / 2 : combat.cols * CELL;
	const height = combat.grid === "hex" ? combat.rows * CELL * .86 + CELL * .14 : combat.rows * CELL;
	function cellOrigin(x, y) {
		if (combat.grid === "hex") {
			const ox = y % 2 === 1 ? CELL / 2 : 0;
			return {
				left: x * CELL + ox,
				top: y * CELL * .86
			};
		}
		return {
			left: x * CELL,
			top: y * CELL
		};
	}
	function pointToCell(clientX, clientY) {
		const rect = boardRef.current?.getBoundingClientRect();
		if (!rect) return null;
		const px = clientX - rect.left;
		const py = clientY - rect.top;
		if (combat.grid === "hex") {
			const y = Math.max(0, Math.min(combat.rows - 1, Math.floor(py / (CELL * .86))));
			const ox = y % 2 === 1 ? CELL / 2 : 0;
			return {
				x: Math.max(0, Math.min(combat.cols - 1, Math.floor((px - ox) / CELL))),
				y
			};
		}
		return {
			x: Math.max(0, Math.min(combat.cols - 1, Math.floor(px / CELL))),
			y: Math.max(0, Math.min(combat.rows - 1, Math.floor(py / CELL)))
		};
	}
	function portraitFor(t) {
		if (t.characterId) return characters.find((c) => c.id === t.characterId)?.portrait;
		return ENEMY_PORTRAITS[t.id];
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-auto border border-edge bg-void",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: boardRef,
			className: "relative touch-none select-none",
			style: {
				width,
				height,
				minWidth: width,
				minHeight: height
			},
			onPointerUp: (e) => {
				if (!drag.current) return;
				const cell = pointToCell(e.clientX, e.clientY);
				if (cell && drag.current.moved) moveToken(drag.current.id, cell.x, cell.y);
				drag.current = null;
			},
			children: [Array.from({ length: combat.rows * combat.cols }, (_, i) => {
				const x = i % combat.cols;
				const y = Math.floor(i / combat.cols);
				const origin = cellOrigin(x, y);
				const occupied = combat.tokens.some((t) => t.x === x && t.y === y);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Casa ${String.fromCharCode(65 + x)}${y + 1}`,
					className: cn("absolute border border-gold/12 bg-paper/30 hover:bg-gold/10", combat.grid === "hex" && "clip-hex", occupied && "bg-transparent"),
					style: {
						left: origin.left,
						top: origin.top,
						width: CELL,
						height: CELL
					},
					onClick: () => {
						if (combat.selectedId) moveToken(combat.selectedId, x, y);
					}
				}, `${x}-${y}`);
			}), combat.tokens.map((t) => {
				const origin = cellOrigin(t.x, t.y);
				const src = portraitFor(t);
				const active = actor?.id === t.id;
				const selected = combat.selectedId === t.id;
				const sin = t.sin ? sinMeta(t.sin) : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("absolute z-10 flex size-11 items-center justify-center overflow-hidden border-2 bg-raised", selected ? "border-gold" : "border-edge", active && "ring-2 ring-blood", t.kind === "hazard" && "border-dashed"),
					style: {
						left: origin.left + 1,
						top: origin.top + 1,
						boxShadow: sin ? `0 0 0 1px ${sin.hue}` : void 0
					},
					onPointerDown: (e) => {
						e.currentTarget.setPointerCapture(e.pointerId);
						drag.current = {
							id: t.id,
							moved: false
						};
						selectToken(t.id);
					},
					onPointerMove: () => {
						if (drag.current?.id === t.id) drag.current.moved = true;
					},
					children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
						src,
						name: t.name,
						sin: t.sin ?? "gloom",
						className: "size-full"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xs text-gold",
						children: t.name.slice(0, 2).toUpperCase()
					})
				}, t.id);
			})]
		})
	});
}
function TheatrePage() {
	const combat = useLedgerStore((s) => s.combat);
	const nextTurn = useLedgerStore((s) => s.nextTurn);
	const setGrid = useLedgerStore((s) => s.setGrid);
	const setTheatre = useLedgerStore((s) => s.setTheatre);
	const selectToken = useLedgerStore((s) => s.selectToken);
	const updateToken = useLedgerStore((s) => s.updateToken);
	const addToken = useLedgerStore((s) => s.addToken);
	const removeToken = useLedgerStore((s) => s.removeToken);
	const resetCombat = useLedgerStore((s) => s.resetCombat);
	const addCombatLog = useLedgerStore((s) => s.addCombatLog);
	const order = combatOrder(combat);
	const actor = currentActor(combat);
	const selected = combat.tokens.find((t) => t.id === combat.selectedId) ?? null;
	const [name, setName] = (0, import_react.useState)("Escriba");
	const [kind, setKind] = (0, import_react.useState)("enemy");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			kicker: "Setor de conflito",
			title: "Teatro",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				onClick: () => {
					resetCombat();
					toast.message("O palco foi rearmado. Os mortos voltaram ao índice.");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Rearmar encontro"]
			}),
			children: [combat.name, ". Arraste os tokens ou toque uma casa com alguém selecionado para deslocar."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: combat.theatre ? "ghost" : "gold",
					onClick: () => setTheatre(false),
					children: "Mapa tático"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: combat.theatre ? "gold" : "ghost",
					onClick: () => setTheatre(true),
					children: "Teatro da mente"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: combat.grid === "square" ? "paper" : "ghost",
					onClick: () => setGrid("square"),
					children: "Grade quadrada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: combat.grid === "hex" ? "paper" : "ghost",
					onClick: () => setGrid("hex"),
					children: "Grade hexagonal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => {
						nextTurn();
						toast.message("O relógio avança. Alguém ainda respira.");
					},
					children: "Avançar o relógio"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 xl:grid-cols-[minmax(0,1fr)_19rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: combat.theatre ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2",
				children: combat.tokens.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => selectToken(t.id),
					className: cn("flex w-full gap-3 border bg-paper p-3 text-left", selected?.id === t.id ? "border-gold" : "border-edge", actor?.id === t.id && "ring-1 ring-blood"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenFace, { token: t }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm text-ink",
								children: t.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xs uppercase tracking-wide text-faint",
								children: t.kind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalBar, {
									current: t.hp,
									max: t.hpMax
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 tabular-nums text-xs text-muted",
								children: [
									"PV ",
									t.hp,
									"/",
									t.hpMax,
									" · init ",
									t.initiative
								]
							}),
							t.conditions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-2xs text-blood",
								children: t.conditions.join(" · ")
							}) : null
						]
					})]
				}) }, t.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapBoard, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border border-edge bg-paper p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
								children: ["Relógio · rodada ", combat.round]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-lg text-ink",
								children: actor ? `Turno de ${actor.name}` : "Ninguém no palco"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-3 flex flex-col gap-1",
								children: order.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => selectToken(t.id),
									className: cn("flex h-10 w-full items-center justify-between px-2 text-sm", t.id === actor?.id ? "bg-blood/30 text-ink" : "text-muted hover:bg-raised"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										i + 1,
										". ",
										t.name
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums text-gold",
										children: t.initiative
									})]
								}) }, t.id))
							})
						]
					}),
					selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenEditor, {
						token: selected,
						onChange: (patch) => updateToken(selected.id, patch),
						onRemove: () => {
							removeToken(selected.id);
							toast.message("Removido do palco. O índice permanece.");
						},
						onLog: (text) => addCombatLog(text)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Selecione um token. Os mortos e os vivos ocupam o mesmo formulário."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "border border-dashed border-edge p-3",
						onSubmit: (e) => {
							e.preventDefault();
							if (!name.trim()) return;
							addToken({
								name: name.trim(),
								kind,
								x: 6,
								y: 4,
								hp: kind === "enemy" ? 16 : 20,
								hpMax: kind === "enemy" ? 16 : 20,
								conditions: [],
								initiative: 8 + Math.floor(Math.random() * 8),
								notes: ""
							});
							toast.success("Uma nova figura entrou em cena. O público não aplaude.");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
							children: "Convocar figura"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: name,
									onChange: (e) => setName(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
									value: kind,
									onChange: (e) => setKind(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "enemy",
											children: "Inimigo"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "ally",
											children: "Aliado"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "sinner",
											children: "Pecador"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "hazard",
											children: "Perigo"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									variant: "ghost",
									size: "sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Protocolar no mapa"]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
						children: "Ata de combate"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 max-h-48 overflow-y-auto text-xs text-muted",
						children: combat.log.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-t border-line py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-faint",
								children: [formatStamp(l.at), " · "]
							}), l.text]
						}, l.id))
					})] })
				]
			})]
		})
	] });
}
function TokenFace({ token }) {
	const characters = useLedgerStore((s) => s.characters);
	const src = token.characterId && characters.find((c) => c.id === token.characterId)?.portrait || ENEMY_PORTRAITS[token.id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
		src,
		name: token.name,
		sin: token.sin ?? "gloom",
		className: "size-14 shrink-0"
	});
}
function TokenEditor({ token, onChange, onRemove, onLog }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-edge bg-paper p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-ink",
					children: token.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: token.kind === "enemy" ? "blood" : "gold",
					children: token.kind
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-2xs text-faint",
					children: [String.fromCharCode(65 + token.x), token.y + 1]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalBar, {
					current: token.hp,
					max: token.hpMax
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => {
								const hp = clamp(token.hp - 1, 0, token.hpMax);
								onChange({ hp });
								onLog(`${token.name} sofre 1. PV ${hp}.`);
							},
							children: "−1 PV"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => onChange({ hp: clamp(token.hp + 1, 0, token.hpMax) }),
							children: "+1 PV"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Iniciativa",
							className: "flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "h-9",
								type: "number",
								value: token.initiative,
								onChange: (e) => onChange({ initiative: Number(e.target.value) || 0 })
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-2xs uppercase tracking-stamp text-gold-dim",
				children: "Condições"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1",
				children: CONDITIONS.map((c) => {
					const on = token.conditions.includes(c);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onChange({ conditions: on ? token.conditions.filter((x) => x !== c) : [...token.conditions, c] }),
						className: cn("h-8 border px-2 text-2xs", on ? "border-blood bg-blood/30 text-ink" : "border-edge text-muted"),
						children: c
					}, c);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notas de cena",
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: token.notes,
					onChange: (e) => onChange({ notes: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				size: "sm",
				className: "mt-3 w-full",
				onClick: onRemove,
				children: "Retirar de cena"
			})
		]
	});
}
//#endregion
export { TheatrePage as component };
