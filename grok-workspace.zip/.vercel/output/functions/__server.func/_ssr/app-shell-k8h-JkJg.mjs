import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ScrollText, d as FilePenLine, h as BookMarked, i as Swords, l as Menu, m as Dices, o as Scale, t as X, u as Landmark } from "../_libs/lucide-react.mjs";
import { a as APP_NAME, i as APP_FILE, o as APP_SLOGAN, r as APP_COMPANY } from "./router-KbQJS_4J.mjs";
import { a as FileRule, d as WaxSeal, i as Field, m as cn, n as Button, o as Input, w as useLedgerStore } from "./store-DMDieGwW.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-k8h-JkJg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Gate() {
	const seal = useLedgerStore((s) => s.sealDesignation);
	const [name, setName] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("gerente");
	function submit(e) {
		e.preventDefault();
		const trimmed = name.trim();
		if (trimmed.length < 2) {
			toast.error("A Companhia recusa anônimos. Assine o livro.");
			return;
		}
		seal(trimmed, role);
		toast.success(role === "gerente" ? "Designação selada. Os pecadores aguardam suas ordens." : "Designação selada. Seu dossiê já estava à sua espera.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-void/95 px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "dossier w-full max-w-md p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaxSeal, {
						letter: "L",
						pulse: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "stamp",
						children: "Acesso interno"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 font-display text-2xs uppercase tracking-stamp text-gold-dim",
					children: APP_COMPANY
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-2xl tracking-display text-ink",
					children: APP_NAME
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm italic text-muted",
					children: APP_SLOGAN
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileRule, { label: "identifique-se" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nome no livro",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								autoFocus: true,
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "Como o arquivo deve chamá-lo",
								maxLength: 40
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
							children: "Função"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
								selected: role === "gerente",
								onSelect: () => setRole("gerente"),
								title: "Gerente",
								body: "Mestre da expedição. Vê o que os pecadores não devem."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
								selected: role === "pecador",
								onSelect: () => setRole("pecador"),
								title: "Pecador",
								body: "Contratado. Carrega o dossiê e a dívida."
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "mt-2 w-full",
							children: "Selar designação"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-xs text-faint",
							children: "A tinta, uma vez seca, ainda pode ser raspada no Protocolo."
						})
					]
				})
			]
		})
	});
}
function RoleCard({ selected, onSelect, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onSelect,
		className: selected ? "border border-gold bg-paper p-3 text-left" : "border border-edge bg-void p-3 text-left hover:border-gold-dim",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted",
			children: body
		})]
	});
}
var NAV = [
	{
		to: "/",
		label: "Arquivo",
		icon: Landmark
	},
	{
		to: "/dossiers",
		label: "Dossiês",
		icon: BookMarked
	},
	{
		to: "/dice",
		label: "Dados",
		icon: Dices
	},
	{
		to: "/theatre",
		label: "Teatro",
		icon: Swords
	},
	{
		to: "/archive",
		label: "Campanha",
		icon: ScrollText
	},
	{
		to: "/contracts",
		label: "Contratos",
		icon: FilePenLine
	},
	{
		to: "/protocol",
		label: "Protocolo",
		icon: Scale
	}
];
function AppShell({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [more, setMore] = (0, import_react.useState)(false);
	const designation = useLedgerStore((s) => s.designation);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		const unsub = useLedgerStore.persist.onFinishHydration(() => setReady(true));
		useLedgerStore.persist.rehydrate();
		if (useLedgerStore.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-5 bg-void text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaxSeal, {
			letter: "L",
			pulse: true,
			className: "size-16"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xs uppercase tracking-stamp text-gold",
			children: "Deslacrando arquivos"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-void text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { className: "!bg-surface !text-ink !border-edge !font-sans !rounded-none" }
			}),
			!designation.sealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gate, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:grid lg:grid-cols-[16.5rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "sticky top-0 hidden h-dvh flex-col border-r border-line bg-surface/80 px-5 py-6 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaxSeal, {
								letter: "L",
								className: "size-12 shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xs uppercase tracking-stamp text-gold",
								children: APP_COMPANY
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm leading-tight tracking-wide text-ink",
								children: APP_NAME
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-relaxed text-muted",
							children: APP_SLOGAN
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule my-5" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-1 flex-col gap-1",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								...item,
								active: isActive(pathname, item.to)
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t border-line pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xs uppercase tracking-stamp text-faint",
								children: APP_FILE
							}), designation.sealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-ink",
								children: [
									designation.role === "gerente" ? "Gerente" : "Pecador",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: designation.name
									})
								]
							}) : null]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-dvh flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "flex items-center justify-between gap-3 border-b border-line bg-surface/70 px-4 py-3 lg:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaxSeal, {
									letter: "L",
									className: "size-10"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xs tracking-wide",
									children: "LEDGER"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex size-11 items-center justify-center text-ink",
								"aria-label": more ? "Fechar menu" : "Abrir menu",
								onClick: () => setMore((v) => !v),
								children: more ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							})]
						}),
						more ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-b border-line bg-surface px-3 py-3 lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "grid grid-cols-2 gap-1",
								children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									...item,
									active: isActive(pathname, item.to),
									onClick: () => setMore(false)
								}, item.to))
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
							className: "relative flex-1 px-4 py-5 pb-24 sm:px-6 lg:px-10 lg:py-8 lg:pb-10",
							children
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "grid grid-cols-5",
					children: [NAV.slice(0, 4).map((item) => {
						const Icon = item.icon;
						const active = isActive(pathname, item.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-16 flex-col items-center justify-center gap-1 text-2xs uppercase tracking-wide", active ? "text-gold" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.5
							}), item.label]
						}) }, item.to);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMore((v) => !v),
						className: cn("flex h-16 w-full flex-col items-center justify-center gap-1 text-2xs uppercase tracking-wide", more ? "text-gold" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
							className: "size-5",
							strokeWidth: 1.5
						}), "Mais"]
					}) })]
				})
			})
		]
	});
}
function isActive(path, to) {
	if (to === "/") return path === "/";
	return path === to || path.startsWith(`${to}/`);
}
function NavLink({ to, label, icon: Icon, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		onClick,
		className: cn("flex h-11 items-center gap-3 px-3 text-sm transition-colors duration-150", active ? "bg-paper text-gold" : "text-muted hover:bg-raised hover:text-ink"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4 shrink-0",
			strokeWidth: 1.5
		}), label]
	});
}
function PageHeader({ kicker, title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "enter mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-2xl tracking-display text-ink sm:text-3xl",
				children: title
			}),
			children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 max-w-2xl text-sm text-muted",
				children
			}) : null
		] }), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0",
			children: action
		}) : null]
	});
}
//#endregion
export { PageHeader as n, AppShell as t };
