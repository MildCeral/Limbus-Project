import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { h as sinMeta, l as DND_SKILLS, m as attrsFor, u as LEDGER_SKILLS } from "./router-KbQJS_4J.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-DMDieGwW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-3)}`;
}
function formatStamp(ts) {
	const d = new Date(ts);
	const pad = (n) => String(n).padStart(2, "0");
	return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} · ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function modifier(value) {
	return Math.floor((value - 10) / 2);
}
function fmtMod(value) {
	const m = modifier(value);
	return m >= 0 ? `+${m}` : `${m}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function WaxSeal({ letter = "L", className, pulse }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative grid size-14 place-items-center rounded-full bg-seal text-ink shadow-seal", pulse && "animate-[pulse-seal_2.4s_ease-in-out_infinite]", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-1 rounded-full border border-gold/30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-2.5 rounded-full border border-gold/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg tracking-display",
				children: letter
			})
		]
	});
}
function Portrait({ src, name, sin, className }) {
	const [ok, setOk] = (0, import_react.useState)(Boolean(src));
	const meta = sinMeta(sin);
	const initial = name.trim().charAt(0).toUpperCase() || "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden border border-edge bg-void", className),
		children: [ok && src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "size-full object-cover object-top",
			onError: () => setOk(false)
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-full place-items-center font-display text-3xl",
			style: {
				color: meta.hue,
				background: "var(--color-raised)"
			},
			children: initial
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute right-1 bottom-1 size-2.5 rounded-full border border-void",
			style: { background: meta.hue },
			title: meta.name
		})]
	});
}
function FileRule({ label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule flex-1" }),
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-2xs uppercase tracking-stamp text-faint",
				children: label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule flex-1" })
		]
	});
}
function VitalBar({ current, max, kind = "hp" }) {
	const pct = max <= 0 ? 0 : Math.max(0, Math.min(100, current / max * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("hp-track", kind === "sp" && "sp-track"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${pct}%` } })
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-sans text-sm font-medium tracking-wide transition-[color,background-color,border-color,transform,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-blood text-ink hover:bg-blood-dim",
			gold: "bg-gold text-void hover:bg-gold-dim",
			ghost: "border border-edge bg-transparent text-ink hover:bg-raised hover:border-gold-dim",
			paper: "border border-edge bg-paper text-ink hover:bg-raised",
			danger: "border border-blood/50 bg-blood-dim/40 text-ink hover:bg-blood",
			quiet: "text-muted hover:text-ink hover:bg-raised"
		},
		size: {
			sm: "h-9 px-3 text-xs",
			md: "h-11 px-4",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Field({ label, hint, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("flex flex-col gap-1.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-2xs uppercase tracking-stamp text-gold-dim",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-faint",
				children: hint
			}) : null
		]
	});
}
var fieldClass = "h-11 w-full border border-edge bg-void px-3 text-sm text-ink outline-none transition-colors duration-150 placeholder:text-faint focus:border-gold";
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(fieldClass, className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(fieldClass, "h-auto min-h-24 py-2.5 leading-relaxed", className),
		...props
	});
}
function NativeSelect({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(fieldClass, "pr-8", className),
		...props,
		children
	});
}
function Badge({ children, tone = "gold", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center border px-2 py-0.5 font-display text-2xs uppercase tracking-wide", {
			gold: "border-gold/40 text-gold",
			blood: "border-blood/50 text-blood",
			mute: "border-edge text-muted",
			gloom: "border-sin-gloom/50 text-sin-gloom"
		}[tone], className),
		children
	});
}
function parseFormula(input) {
	const m = input.trim().toLowerCase().replace(/\s/g, "").match(/^(\d*)d(\d+)([+-]\d+)?$/);
	if (!m) return null;
	const count = m[1] ? Number.parseInt(m[1], 10) : 1;
	const sides = Number.parseInt(m[2], 10);
	const modifier = m[3] ? Number.parseInt(m[3], 10) : 0;
	if (!Number.isFinite(count) || !Number.isFinite(sides)) return null;
	if (count < 1 || count > 40 || sides < 2 || sides > 1e3) return null;
	if (Math.abs(modifier) > 999) return null;
	return {
		count,
		sides,
		modifier
	};
}
function formulaString(p) {
	const base = `${p.count}d${p.sides}`;
	if (p.modifier === 0) return base;
	return p.modifier > 0 ? `${base}+${p.modifier}` : `${base}${p.modifier}`;
}
function rollDie(sides) {
	return 1 + Math.floor(Math.random() * sides);
}
function executeRoll(input, advantage = "normal") {
	const parsed = parseFormula(input);
	if (!parsed) return null;
	if (advantage !== "normal" && parsed.count === 1) {
		const a = rollDie(parsed.sides);
		const b = rollDie(parsed.sides);
		const kept = advantage === "adv" ? Math.max(a, b) : Math.min(a, b);
		return {
			formula: `${formulaString(parsed)} [${advantage === "adv" ? "vantagem" : "desvantagem"}]`,
			dice: [a, b],
			sides: parsed.sides,
			modifier: parsed.modifier,
			total: kept + parsed.modifier
		};
	}
	const dice = Array.from({ length: parsed.count }, () => rollDie(parsed.sides));
	const sum = dice.reduce((acc, n) => acc + n, 0);
	return {
		formula: formulaString(parsed),
		dice,
		sides: parsed.sides,
		modifier: parsed.modifier,
		total: sum + parsed.modifier
	};
}
function skillCheckFormula(mod) {
	return mod >= 0 ? `1d20+${mod}` : `1d20${mod}`;
}
var now = Date.UTC(2026, 8, 12, 21, 40);
function attr(id, name, abbr, value) {
	return {
		id,
		name,
		abbr,
		value
	};
}
function skill(id, name, attrId, value) {
	return {
		id,
		name,
		attr: attrId,
		value
	};
}
var HELENA = {
	id: "helena-voss",
	name: "Helena Voss",
	designation: "Pecadora nº 01",
	epithet: "A que leu o arquivo até o fim",
	system: "ledger",
	sin: "pride",
	sinRank: 4,
	classification: "CONFIDENCIAL / EX-I",
	hp: 22,
	hpMax: 28,
	sp: 16,
	spMax: 24,
	portrait: "/portraits/helena.jpg",
	attributes: [
		attr("body", "Corpo", "COR", 9),
		attr("reason", "Razão", "RAZ", 17),
		attr("will", "Vontade", "VON", 15),
		attr("instinct", "Instinto", "INS", 11),
		attr("presence", "Presença", "PRE", 12),
		attr("fortune", "Fortuna", "FOR", 8)
	],
	skills: [
		skill("s1", "Arquivo", "reason", 6),
		skill("s2", "Ocultismo", "will", 5),
		skill("s3", "Observação", "instinct", 3),
		skill("s4", "Persuasão", "presence", 2),
		skill("s5", "Medicina", "reason", 3)
	],
	talents: [{
		id: "t1",
		name: "Memória de Cartório",
		desc: "Uma vez por sessão, declare como verdadeiro um detalhe já escrito em qualquer dossiê aberto. O mundo hesita, depois concorda."
	}, {
		id: "t2",
		name: "Margem Anotada",
		desc: "Quando falha um teste de Razão, pode gastar 2 SP para reler o resultado como um 10 natural."
	}],
	spells: [{
		id: "sp1",
		name: "Redigir o Nome Verdadeiro",
		circle: 2,
		desc: "Escreve o nome oculto de um alvo. O próximo ataque contra ele ignora cobertura e orgulho."
	}],
	traumas: [{
		id: "tr1",
		name: "A Última Página em Branco",
		desc: "Helena não consegue encerrar um relato. Deixar um mistério sem nota a faz perder 1 SP por hora."
	}],
	sins: [{
		id: "si1",
		sin: "pride",
		rank: 4,
		desc: "Acredita que o arquivo é mais verdadeiro do que as pessoas que ele descreve."
	}],
	inventory: [
		{
			id: "i1",
			name: "Caneta-faca de osso",
			qty: 1,
			equipped: true,
			notes: "Escreve e corta com a mesma tinta."
		},
		{
			id: "i2",
			name: "Dossiê selado LCD-XII",
			qty: 1,
			notes: "Ainda não autorizado. Ela já leu."
		},
		{
			id: "i3",
			name: "Pó de arquivo",
			qty: 3,
			notes: "Cega distorções feitas de papel."
		}
	],
	journal: [{
		id: "j1",
		title: "Sobre o Ramo",
		at: now - 2592e5,
		sin: "pride",
		body: "O artefato não é uma planta. É uma correção. O Distrito 12 está sendo reescrito à mão, e a caligrafia não é humana. Solicitei autorização para anotar à margem. O Gerente recusou. Anotei mesmo assim."
	}, {
		id: "j2",
		title: "A pecadora nº 03",
		at: now - 864e5,
		sin: "gloom",
		body: "Inês ainda fala como se o contrato fosse uma cruzada. Eu invejo a clareza. Invejo, e catalogo a inveja, e sigo."
	}],
	notes: "Não dorme. Recita cláusulas para adormecer. Recusa ser chamada de heroína — prefere 'funcionária'."
};
var INES = {
	id: "ines-quixote",
	name: "Inês Quixote",
	designation: "Pecadora nº 03",
	epithet: "A cavaleira de um sonho já falido",
	system: "ledger",
	sin: "lust",
	sinRank: 3,
	classification: "INTERNO / EX-III",
	hp: 31,
	hpMax: 34,
	sp: 18,
	spMax: 20,
	portrait: "/portraits/ines.jpg",
	attributes: [
		attr("body", "Corpo", "COR", 13),
		attr("reason", "Razão", "RAZ", 10),
		attr("will", "Vontade", "VON", 14),
		attr("instinct", "Instinto", "INS", 11),
		attr("presence", "Presença", "PRE", 16),
		attr("fortune", "Fortuna", "FOR", 12)
	],
	skills: [
		skill("s1", "Persuasão", "presence", 5),
		skill("s2", "Atletismo", "body", 3),
		skill("s3", "Violência", "body", 3),
		skill("s4", "Intuição", "will", 4),
		skill("s5", "Ofício", "reason", 1)
	],
	talents: [{
		id: "t1",
		name: "Juramento Recitado",
		desc: "Quando declara um ideal em voz alta, aliados a 6m ganham +2 no próximo teste. Se o ideal for mentira, ela perde 3 SP."
	}],
	spells: [{
		id: "sp1",
		name: "Lança do Capítulo Perdido",
		circle: 1,
		desc: "Uma lança de luz desbotada. Causa 1d8 + Presença, e brilha como se ainda houvesse honra no mundo."
	}],
	traumas: [{
		id: "tr1",
		name: "Aventura Obrigatória",
		desc: "Recusar um pedido de ajuda visível exige um teste de Vontade. Falha: ela vai mesmo assim."
	}],
	sins: [{
		id: "si1",
		sin: "lust",
		rank: 3,
		desc: "Fome de glória. Não de corpos — de um final em que alguém ainda a aplaude."
	}],
	inventory: [
		{
			id: "i1",
			name: "Lança quebrada (remendada)",
			qty: 1,
			equipped: true,
			notes: "O conserto é um laço amarelo."
		},
		{
			id: "i2",
			name: "Manual de cavalaria, 3ª edição",
			qty: 1,
			notes: "Todas as páginas de 'retirada' foram rasgadas."
		},
		{
			id: "i3",
			name: "Rações de teatro",
			qty: 4
		}
	],
	journal: [{
		id: "j1",
		title: "Ao meu senhor inexistente",
		at: now - 1728e5,
		sin: "lust",
		body: "Hoje a chuva no beco parecia uma ovação. Helena diz que é só água. Eu sei. Ainda assim curvei a cabeça, como se o público invisível merecesse o gesto."
	}],
	notes: "Sorriso honesto demais para o Setor. O Gerente a considera 'utilizável'."
};
var CAIO = {
	id: "caio-thorn",
	name: "Caio Thorn",
	designation: "Pecador nº 07",
	epithet: "O cão que ainda late contra a chuva",
	system: "dnd5e",
	sin: "wrath",
	sinRank: 5,
	classification: "RESTRITO / EX-VII",
	hp: 38,
	hpMax: 44,
	sp: 10,
	spMax: 16,
	portrait: "/portraits/caio.jpg",
	attributes: [
		attr("str", "Força", "FOR", 16),
		attr("dex", "Destreza", "DES", 14),
		attr("con", "Constituição", "CON", 15),
		attr("int", "Inteligência", "INT", 8),
		attr("wis", "Sabedoria", "SAB", 12),
		attr("cha", "Carisma", "CAR", 10)
	],
	skills: [
		skill("s1", "Atletismo", "str", 5),
		skill("s2", "Intimidação", "cha", 4),
		skill("s3", "Percepção", "wis", 3),
		skill("s4", "Sobrevivência", "wis", 2),
		skill("s5", "Furtividade", "dex", 2)
	],
	talents: [{
		id: "t1",
		name: "Tempestade Contida",
		desc: "Quando reduz um inimigo a 0, pode imediatamente se mover metade do deslocamento sem provocar."
	}, {
		id: "t2",
		name: "Ferida que Lembra",
		desc: "Vantagem em testes contra o mesmo tipo de criatura que o marcou na sessão anterior."
	}],
	spells: [],
	traumas: [{
		id: "tr1",
		name: "A Casa na Colina",
		desc: "Trovão e portas batendo o obrigam a um teste de Sabedoria ou ele ataca o ruído."
	}],
	sins: [{
		id: "si1",
		sin: "wrath",
		rank: 5,
		desc: "A raiva não é explosão — é clima. Uma estação que se recusa a passar."
	}],
	inventory: [
		{
			id: "i1",
			name: "Machado curto 'Cathy'",
			qty: 1,
			equipped: true,
			notes: "O nome não é explicado. Não pergunte."
		},
		{
			id: "i2",
			name: "Casaco pesado, rasgado",
			qty: 1,
			equipped: true
		},
		{
			id: "i3",
			name: "Frasco de uísque barato",
			qty: 2,
			notes: "Serve como combustível e como desculpa."
		}
	],
	journal: [{
		id: "j1",
		title: "Não é um diário",
		at: now - 216e5,
		sin: "wrath",
		body: "A Companhia quer que eu escreva. Então está escrito: a chuva deste distrito tem gosto de ferrugem. O Rei de Papel cheira a biblioteca molhada. Vou quebrá-lo."
	}],
	notes: "Ficha em D&D 5e a pedido do próprio pecador. 'Não falo o dialeto da Companhia.'"
};
var MIRA = {
	id: "mira-k",
	name: "Mira K.",
	designation: "Pecadora nº 12",
	epithet: "A que só retrata o fim",
	system: "ledger",
	sin: "gloom",
	sinRank: 4,
	classification: "CONFIDENCIAL / EX-XII",
	hp: 24,
	hpMax: 26,
	sp: 22,
	spMax: 26,
	portrait: "/portraits/mira.jpg",
	attributes: [
		attr("body", "Corpo", "COR", 10),
		attr("reason", "Razão", "RAZ", 13),
		attr("will", "Vontade", "VON", 16),
		attr("instinct", "Instinto", "INS", 14),
		attr("presence", "Presença", "PRE", 8),
		attr("fortune", "Fortuna", "FOR", 11)
	],
	skills: [
		skill("s1", "Ofício", "reason", 6),
		skill("s2", "Ocultismo", "will", 4),
		skill("s3", "Observação", "instinct", 5),
		skill("s4", "Furtividade", "instinct", 3),
		skill("s5", "Intuição", "will", 3)
	],
	talents: [{
		id: "t1",
		name: "Retrato Antecipado",
		desc: "Gasta um turno pintando o destino de um alvo. No próximo acerto contra ele, causa dano extra igual ao círculo da obra (1d6 por rank de pecado)."
	}],
	spells: [{
		id: "sp1",
		name: "Verniz de Ausência",
		circle: 2,
		desc: "Uma figura pintada desaparece do olhar casual por 10 minutos. Magia e cães ainda a veem."
	}, {
		id: "sp2",
		name: "Tinta que Lembra Sangue",
		circle: 1,
		desc: "Conjurar exige um corte raso. Cura 1d4 ou marca um inimigo como 'já morto no quadro'."
	}],
	traumas: [{
		id: "tr1",
		name: "Nada Terminado",
		desc: "Obras inacabadas a puxam. Sair de uma cena sem 'fechar a composição' custa 2 SP."
	}],
	sins: [{
		id: "si1",
		sin: "gloom",
		rank: 4,
		desc: "A beleza, para Mira, só existe no instante em que algo deixa de poder ser salvo."
	}],
	inventory: [
		{
			id: "i1",
			name: "Estojo de pigmentos proibidos",
			qty: 1,
			equipped: true,
			notes: "Um tubo está lacrado com cera da Companhia."
		},
		{
			id: "i2",
			name: "Tela dobrável, 40cm",
			qty: 1
		},
		{
			id: "i3",
			name: "Lâmina de espátula",
			qty: 1,
			equipped: true
		}
	],
	journal: [{
		id: "j1",
		title: "Estudo em vermelho desbotado",
		at: now - 3456e5,
		sin: "gloom",
		body: "Pintei o Gerente sem o rosto. Ele aprovou o quadro. Disse que estava 'preciso'. Não sei se foi elogio ou confissão."
	}, {
		id: "j2",
		title: "O Rei",
		at: now - 72e5,
		sin: "gloom",
		body: "Ele é feito de índices. Se eu pintar o sumário errado, talvez o corpo dele se perca entre os capítulos."
	}],
	notes: "Fala pouco. Quando fala, parece estar legendando um quadro que só ela vê."
};
function seedCampaign() {
	return {
		id: "ramo-dourado",
		code: "LCD-XII-441",
		name: "Expedição do Ramo Dourado",
		premise: "A Companhia despachou quatro pecadores ao Distrito 12 para recuperar um artefato literário — o Ramo Dourado — que passou a reescrever ruas, nomes e dívidas. A chuva local tem gosto de tinta. Os habitantes começam a falar em versos que não escolheram.",
		notes: "Tom da mesa: gótico burocrático. Recompense anotações no diário. Punir a omissão, não o fracasso. O Rei de Papel não pode ser morto até que alguém o catalogue corretamente.",
		npcs: [
			{
				id: "npc-faustian",
				name: "Gerente Faustian",
				role: "Handler da expedição",
				attitude: "Cortês, inumano, pontual.",
				secrets: "Já esteve no Distrito 12. Parte de seu nome foi reescrita; o sorriso é o que restou.",
				notes: "Comunica-se por carimbos e telefonemas que cheiram a ozônio.",
				locationId: "loc-sede"
			},
			{
				id: "npc-biblio",
				name: "O Bibliotecário Cego",
				role: "Guardião da Biblioteca de Cinzas",
				attitude: "Hospitalar com quem sussurra.",
				secrets: "Não é cego. Recusa-se a ver para não ser indexado pelo Rei.",
				notes: "Aceita pagamentos em histórias verdadeiras, nunca em ouro.",
				locationId: "loc-biblio"
			},
			{
				id: "npc-glass",
				name: "Madame Glass",
				role: "Proprietária do cabaré O Último Ato",
				attitude: "Encantadora, venenosa, útil.",
				secrets: "Seu verdadeiro contrato é com o próprio Ramo. Cada número no palco é uma cláusula.",
				notes: "Conhece o nome de batismo de Caio. Não usa.",
				locationId: "loc-cabare"
			},
			{
				id: "npc-rei",
				name: "O Rei de Papel",
				role: "Distorção maior / antagonista",
				attitude: "Majestoso, entediado, faminto por índices.",
				secrets: "Foi um arquivista da Companhia. Pediu para ser esquecido. O pedido foi protocolado tarde demais.",
				notes: "Fraco contra catalogação correta e fogo. Forte contra omissão e metáforas vagas.",
				locationId: "loc-biblio"
			}
		],
		places: [
			{
				id: "loc-sede",
				name: "Sede Subterrânea",
				kind: "Q.G. da Companhia",
				danger: 1,
				desc: "Corredores de concreto úmido, selos de cera nas portas, um relógio que atrasa só para pecadores. O cheiro é de papel-carbono e sangue seco."
			},
			{
				id: "loc-biblio",
				name: "Biblioteca de Cinzas",
				kind: "Ruína literária",
				danger: 4,
				desc: "Prateleiras até o teto negro. Livros que se abrem sozinhos. Cinza fina cobre o chão como neve. O Rei anda entre os corredores como um sumário."
			},
			{
				id: "loc-cabare",
				name: "Cabaré O Último Ato",
				kind: "Estabelecimento noturno",
				danger: 2,
				desc: "Palco vermelho desbotado, espelhos que recusam certos rostos, orquestra de três músicos que nunca piscam. Madame Glass serve absinto com cláusulas no fundo da taça."
			},
			{
				id: "loc-beco",
				name: "Beco da Chuva Eterna",
				kind: "Via pública distorcida",
				danger: 3,
				desc: "A água não encharca — anota. Quem atravessa depressa demais deixa um parágrafo para trás."
			}
		],
		sessions: [{
			id: "ses-1",
			number: 1,
			title: "A Abertura do Dossiê",
			date: "04.09.2026",
			summary: "Os quatro pecadores foram apresentados, selados e despachados. Helena violou o lacre do dossiê no trem. Inês saudou o condutor como se ele fosse um rei. Caio dormiu. Mira desenhou a janela até ela deixar de ser uma janela.",
			notes: "Gancho: o bilhete do trem estava escrito na caligrafia do Rei."
		}, {
			id: "ses-2",
			number: 2,
			title: "Chuva no Beco",
			date: "11.09.2026",
			summary: "Primeiro contato com uma distorção menor (Escriba Rasgado). Combate na chuva. O Bibliotecário Cego ofereceu abrigo em troca de uma história verdadeira — Caio recusou; Mira pagou com um retrato.",
			notes: "Iniciativa longa. Teatro da mente no começo, mapa no beco."
		}],
		contracts: [
			{
				id: "c-ramo",
				code: "CT-441-A",
				title: "Recuperar o Ramo Dourado",
				status: "andamento",
				rank: "Carmesim",
				hook: "O artefato está 'enraizado' na Biblioteca de Cinzas. Cortá-lo exige um nome verdadeiro.",
				terms: "Trazer o Ramo intacto. Não publicar versos obtidos no Distrito. Sobrevivência: opcional.",
				reward: "Remissão parcial de um pecado (rank −1) e 400 cinzas de arquivo.",
				relatedIds: [
					"helena-voss",
					"ines-quixote",
					"caio-thorn",
					"mira-k"
				]
			},
			{
				id: "c-cat",
				code: "CT-441-B",
				title: "Catalogar três distorções",
				status: "aberto",
				rank: "Âmbar",
				hook: "O Setor de Arquivo recusa combate sem formulário. Cada distorção nomeada enfraquece o Rei.",
				terms: "Nome, origem provável e um retrato ou amostra. Mentir no formulário alimenta o Rei.",
				reward: "Acesso ao Anexo Proibido por uma sessão.",
				relatedIds: ["helena-voss", "mira-k"]
			},
			{
				id: "c-livro",
				code: "CT-441-C",
				title: "Extrair o Livro-Vivo",
				status: "aberto",
				rank: "Íris",
				hook: "Uma testemunha no cabaré está se tornando texto. Madame Glass finge não notar.",
				terms: "Extrair com vida. Se virar capítulo, arquivar mesmo assim.",
				reward: "Um favor de Madame Glass — e ela cobra juros em memórias.",
				relatedIds: ["ines-quixote"]
			},
			{
				id: "c-selado",
				code: "CT-118-Z",
				title: "Não mencionar o Gerente anterior",
				status: "selado",
				rank: "Obsidiana",
				hook: "Cláusula herdada. O dossiê existe, mas a capa está em branco.",
				terms: "Silêncio. Qualquer pecador que ler este contrato já o violou.",
				reward: "Nenhuma. A recompensa é continuar existindo no índice.",
				relatedIds: []
			}
		],
		timeline: [
			{
				id: "tl1",
				at: "Há 40 anos",
				title: "Fundação oficiosa da Companhia",
				body: "Um cartório que passou a aceitar dívidas que o Estado recusava. O primeiro pecador assinou com sangue porque a tinta havia acabado."
			},
			{
				id: "tl2",
				at: "Há 11 anos",
				title: "Incidente do Arquivista",
				body: "Um funcionário pediu para ser apagado. O pedido entrou na fila. Quando foi processado, ele já era o Rei de Papel.",
				secret: true
			},
			{
				id: "tl3",
				at: "04.09.2026",
				title: "Expedição XII despachada",
				body: "Quatro pecadores, um dossiê, nenhum regresso garantido."
			},
			{
				id: "tl4",
				at: "11.09.2026",
				title: "Primeira distorção catalogada",
				body: "Escriba Rasgado — origem: formulários não assinados. Destino: cinzas."
			},
			{
				id: "tl5",
				at: "Próxima sessão",
				title: "O Último Ato",
				body: "Madame Glass convidou a expedição para um número especial. O convite está escrito no verso de um atestado de óbito em branco."
			}
		]
	};
}
function seedCombat() {
	return {
		name: "Biblioteca de Cinzas — Corredor do Índice",
		grid: "square",
		theatre: false,
		cols: 12,
		rows: 9,
		turnIndex: 0,
		round: 1,
		selectedId: null,
		log: [{
			id: "l1",
			at: now,
			text: "O Rei de Papel abre o próprio peito como um livro. 'Estão atrasados para o empréstimo.'"
		}],
		tokens: [
			{
				id: "tok-helena",
				name: "Helena",
				kind: "sinner",
				x: 1,
				y: 4,
				hp: 22,
				hpMax: 28,
				initiative: 14,
				characterId: "helena-voss",
				conditions: [],
				notes: "",
				sin: "pride"
			},
			{
				id: "tok-ines",
				name: "Inês",
				kind: "sinner",
				x: 2,
				y: 6,
				hp: 31,
				hpMax: 34,
				initiative: 16,
				characterId: "ines-quixote",
				conditions: [],
				notes: "",
				sin: "lust"
			},
			{
				id: "tok-caio",
				name: "Caio",
				kind: "sinner",
				x: 2,
				y: 2,
				hp: 38,
				hpMax: 44,
				initiative: 12,
				characterId: "caio-thorn",
				conditions: ["Sangrando"],
				notes: "Corte raso no ombro — tinta, não sangue.",
				sin: "wrath"
			},
			{
				id: "tok-mira",
				name: "Mira",
				kind: "sinner",
				x: 0,
				y: 3,
				hp: 24,
				hpMax: 26,
				initiative: 15,
				characterId: "mira-k",
				conditions: ["Concentrando"],
				notes: "Pinta o Rei no verso de um formulário.",
				sin: "gloom"
			},
			{
				id: "tok-rei",
				name: "Rei de Papel",
				kind: "enemy",
				x: 9,
				y: 4,
				hp: 72,
				hpMax: 72,
				initiative: 13,
				conditions: [],
				notes: "Distorção maior. Fraco a catalogação e fogo.",
				sin: "pride"
			},
			{
				id: "tok-esc1",
				name: "Escriba Rasgado",
				kind: "enemy",
				x: 7,
				y: 2,
				hp: 18,
				hpMax: 22,
				initiative: 11,
				conditions: [],
				notes: "Minion. Tenta indexar pecadores."
			},
			{
				id: "tok-esc2",
				name: "Escriba Rasgado",
				kind: "enemy",
				x: 8,
				y: 6,
				hp: 14,
				hpMax: 22,
				initiative: 9,
				conditions: ["Amedrontado"],
				notes: "Recua se um dossiê for aberto contra ele."
			},
			{
				id: "tok-haz",
				name: "Prateleira Instável",
				kind: "hazard",
				x: 5,
				y: 4,
				hp: 8,
				hpMax: 8,
				initiative: 0,
				conditions: [],
				notes: "Quem termina o turno adjacente: 1d6 de impacto (livros)."
			}
		]
	};
}
function seedLedger() {
	return {
		version: 1,
		designation: {
			name: "",
			role: "gerente",
			sealed: false
		},
		characters: [
			HELENA,
			INES,
			CAIO,
			MIRA
		],
		campaign: seedCampaign(),
		combat: seedCombat(),
		rolls: [
			{
				id: "r1",
				formula: "1d20+6",
				dice: [14],
				sides: 20,
				modifier: 6,
				total: 20,
				label: "Helena · Arquivo (catalogar distorção)",
				secret: false,
				at: now - 36e5,
				characterId: "helena-voss"
			},
			{
				id: "r2",
				formula: "1d20+5 [vantagem]",
				dice: [9, 17],
				sides: 20,
				modifier: 5,
				total: 22,
				label: "Inês · Persuasão (convencer o Bibliotecário)",
				secret: false,
				at: now - 24e5,
				characterId: "ines-quixote"
			},
			{
				id: "r3",
				formula: "2d6+4",
				dice: [6, 3],
				sides: 6,
				modifier: 4,
				total: 13,
				label: "Caio · Machado 'Cathy'",
				secret: false,
				at: now - 18e5,
				characterId: "caio-thorn"
			},
			{
				id: "r4",
				formula: "1d20",
				dice: [3],
				sides: 20,
				modifier: 0,
				total: 3,
				label: "Olhos do Gerente · intenção do Rei",
				secret: true,
				at: now - 6e5
			}
		]
	};
}
var ENEMY_PORTRAITS = {
	"tok-rei": "/portraits/rei-papel.jpg",
	"tok-esc1": "/portraits/escriba.jpg",
	"tok-esc2": "/portraits/escriba.jpg"
};
function sortedTokens(tokens) {
	return [...tokens].sort((a, b) => b.initiative - a.initiative || a.name.localeCompare(b.name, "pt"));
}
function dataOf(s) {
	return {
		version: 1,
		designation: s.designation,
		characters: s.characters,
		campaign: s.campaign,
		rolls: s.rolls,
		combat: s.combat
	};
}
var useLedgerStore = create()(persist((set, get) => ({
	...seedLedger(),
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	sealDesignation: (name, role) => set({ designation: {
		name: name.trim(),
		role,
		sealed: true
	} }),
	addCharacter: (c) => set({ characters: [...get().characters, c] }),
	updateCharacter: (id, patch) => set({ characters: get().characters.map((c) => c.id === id ? {
		...c,
		...patch
	} : c) }),
	deleteCharacter: (id) => set({
		characters: get().characters.filter((c) => c.id !== id),
		combat: {
			...get().combat,
			tokens: get().combat.tokens.filter((t) => t.characterId !== id)
		}
	}),
	patchCharacter: (id, fn) => set({ characters: get().characters.map((c) => c.id === id ? fn(c) : c) }),
	addJournal: (characterId, entry) => set({ characters: get().characters.map((c) => c.id === characterId ? {
		...c,
		journal: [{
			...entry,
			id: uid("j")
		}, ...c.journal]
	} : c) }),
	updateCampaign: (patch) => set({ campaign: {
		...get().campaign,
		...patch
	} }),
	addNpc: (n) => set({ campaign: {
		...get().campaign,
		npcs: [n, ...get().campaign.npcs]
	} }),
	updateNpc: (id, patch) => set({ campaign: {
		...get().campaign,
		npcs: get().campaign.npcs.map((n) => n.id === id ? {
			...n,
			...patch
		} : n)
	} }),
	deleteNpc: (id) => set({ campaign: {
		...get().campaign,
		npcs: get().campaign.npcs.filter((n) => n.id !== id)
	} }),
	addPlace: (p) => set({ campaign: {
		...get().campaign,
		places: [p, ...get().campaign.places]
	} }),
	updatePlace: (id, patch) => set({ campaign: {
		...get().campaign,
		places: get().campaign.places.map((p) => p.id === id ? {
			...p,
			...patch
		} : p)
	} }),
	deletePlace: (id) => set({ campaign: {
		...get().campaign,
		places: get().campaign.places.filter((p) => p.id !== id)
	} }),
	addSession: (s) => set({ campaign: {
		...get().campaign,
		sessions: [s, ...get().campaign.sessions]
	} }),
	updateSession: (id, patch) => set({ campaign: {
		...get().campaign,
		sessions: get().campaign.sessions.map((s) => s.id === id ? {
			...s,
			...patch
		} : s)
	} }),
	deleteSession: (id) => set({ campaign: {
		...get().campaign,
		sessions: get().campaign.sessions.filter((s) => s.id !== id)
	} }),
	addContract: (c) => set({ campaign: {
		...get().campaign,
		contracts: [c, ...get().campaign.contracts]
	} }),
	updateContract: (id, patch) => set({ campaign: {
		...get().campaign,
		contracts: get().campaign.contracts.map((c) => c.id === id ? {
			...c,
			...patch
		} : c)
	} }),
	deleteContract: (id) => set({ campaign: {
		...get().campaign,
		contracts: get().campaign.contracts.filter((c) => c.id !== id)
	} }),
	addEvent: (e) => set({ campaign: {
		...get().campaign,
		timeline: [e, ...get().campaign.timeline]
	} }),
	deleteEvent: (id) => set({ campaign: {
		...get().campaign,
		timeline: get().campaign.timeline.filter((e) => e.id !== id)
	} }),
	recordRoll: (input, opts) => {
		const result = executeRoll(input, opts?.advantage ?? "normal");
		if (!result) return null;
		const roll = {
			id: uid("r"),
			formula: result.formula,
			dice: result.dice,
			sides: result.sides,
			modifier: result.modifier,
			total: result.total,
			label: opts?.label?.trim() || "Rolagem avulsa",
			secret: Boolean(opts?.secret),
			at: Date.now(),
			characterId: opts?.characterId
		};
		set({ rolls: [roll, ...get().rolls].slice(0, 80) });
		return roll;
	},
	clearRolls: () => set({ rolls: [] }),
	selectToken: (id) => set({ combat: {
		...get().combat,
		selectedId: id
	} }),
	moveToken: (id, x, y) => {
		const combat = get().combat;
		const token = combat.tokens.find((t) => t.id === id);
		if (!token) return;
		const nx = Math.max(0, Math.min(combat.cols - 1, x));
		const ny = Math.max(0, Math.min(combat.rows - 1, y));
		if (nx === token.x && ny === token.y) return;
		set({ combat: {
			...combat,
			tokens: combat.tokens.map((t) => t.id === id ? {
				...t,
				x: nx,
				y: ny
			} : t),
			log: [{
				id: uid("l"),
				at: Date.now(),
				text: `${token.name} desloca-se para ${String.fromCharCode(65 + nx)}${ny + 1}.`
			}, ...combat.log].slice(0, 40)
		} });
	},
	updateToken: (id, patch) => set({ combat: {
		...get().combat,
		tokens: get().combat.tokens.map((t) => t.id === id ? {
			...t,
			...patch
		} : t)
	} }),
	addToken: (t) => set({ combat: {
		...get().combat,
		tokens: [...get().combat.tokens, {
			...t,
			id: uid("tok")
		}]
	} }),
	removeToken: (id) => {
		const combat = get().combat;
		const next = combat.tokens.filter((t) => t.id !== id);
		const sorted = sortedTokens(next.filter((t) => t.kind !== "hazard"));
		const turnIndex = Math.min(combat.turnIndex, Math.max(0, sorted.length - 1));
		set({ combat: {
			...combat,
			tokens: next,
			selectedId: combat.selectedId === id ? null : combat.selectedId,
			turnIndex
		} });
	},
	nextTurn: () => {
		const combat = get().combat;
		const order = sortedTokens(combat.tokens.filter((t) => t.kind !== "hazard"));
		if (order.length === 0) return;
		const nextIndex = (combat.turnIndex + 1) % order.length;
		const round = nextIndex === 0 ? combat.round + 1 : combat.round;
		const current = order[nextIndex];
		set({ combat: {
			...combat,
			turnIndex: nextIndex,
			round,
			log: [{
				id: uid("l"),
				at: Date.now(),
				text: `Turno de ${current.name}. Relógio: rodada ${round}.`
			}, ...combat.log].slice(0, 40)
		} });
	},
	setGrid: (grid) => set({ combat: {
		...get().combat,
		grid
	} }),
	setTheatre: (theatre) => set({ combat: {
		...get().combat,
		theatre
	} }),
	addCombatLog: (text) => set({ combat: {
		...get().combat,
		log: [{
			id: uid("l"),
			at: Date.now(),
			text
		}, ...get().combat.log].slice(0, 40)
	} }),
	resetCombat: () => set({ combat: seedCombat() }),
	exportJson: () => JSON.stringify(dataOf(get()), null, 2),
	importJson: (raw) => {
		try {
			const parsed = JSON.parse(raw);
			if (!parsed || typeof parsed !== "object") return {
				ok: false,
				error: "O lacre não reconhece este formato."
			};
			const base = seedLedger();
			set({
				designation: parsed.designation ?? base.designation,
				characters: parsed.characters ?? base.characters,
				campaign: parsed.campaign ?? base.campaign,
				rolls: parsed.rolls ?? [],
				combat: parsed.combat ?? base.combat
			});
			return { ok: true };
		} catch {
			return {
				ok: false,
				error: "O arquivo recusou-se a abrir. Talvez não fosse para você lê-lo."
			};
		}
	},
	resetDemo: () => {
		const current = get().designation;
		const fresh = seedLedger();
		set({
			...fresh,
			designation: current.sealed ? current : fresh.designation
		});
	}
}), {
	name: "infernal-ledger-v1",
	version: 1,
	skipHydration: true,
	partialize: (s) => ({
		version: s.version,
		designation: s.designation,
		characters: s.characters,
		campaign: s.campaign,
		rolls: s.rolls,
		combat: s.combat
	})
}));
function combatOrder(combat) {
	return sortedTokens(combat.tokens.filter((t) => t.kind !== "hazard"));
}
function currentActor(combat) {
	const order = combatOrder(combat);
	if (order.length === 0) return null;
	return order[combat.turnIndex % order.length] ?? null;
}
function makeBlankCharacter(system = "ledger") {
	const attributes = attrsFor(system);
	const skillSrc = system === "dnd5e" ? DND_SKILLS : LEDGER_SKILLS;
	return {
		id: uid("pc"),
		name: "",
		designation: "Pecador nº —",
		epithet: "",
		system,
		sin: "gloom",
		sinRank: 1,
		classification: "INTERNO",
		hp: 20,
		hpMax: 20,
		sp: 16,
		spMax: 16,
		portrait: "",
		attributes,
		skills: skillSrc.slice(0, 6).map((s, i) => ({
			id: uid("sk"),
			name: s.name,
			attr: s.attr,
			value: i === 0 ? 3 : 1
		})),
		talents: [],
		spells: [],
		traumas: [],
		sins: [],
		inventory: [],
		journal: [],
		notes: ""
	};
}
//#endregion
export { uid as C, skillCheckFormula as S, fmtMod as _, FileRule as a, modifier as b, Portrait as c, WaxSeal as d, buttonVariants as f, currentActor as g, combatOrder as h, Field as i, Textarea as l, cn as m, Button as n, Input as o, clamp as p, ENEMY_PORTRAITS as r, NativeSelect as s, Badge as t, VitalBar as u, formatStamp as v, useLedgerStore as w, parseFormula as x, makeBlankCharacter as y };
